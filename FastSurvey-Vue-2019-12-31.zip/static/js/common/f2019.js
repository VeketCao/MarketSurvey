/**
 * Created by keyuan on 2019/1/18.
 */

function scrollHader(customscrollTop){
    if(customscrollTop==null){
        customscrollTop = 5;
    }
    $(window).scroll( function() {
        resetHader(customscrollTop);
    });
    resetHader(customscrollTop);
}

function resetHader(customscrollTop){
    var scrollTop = $(window).scrollTop();
    if(scrollTop>=customscrollTop){
        $("#header2019").addClass("headScr");
    }else{
        $("#header2019").removeClass("headScr");
    }
}


// var _hmt = _hmt || [];
// (function() {
//     var hm = document.createElement("script");
//     hm.src = "../../../hm.baidu.com/hm.js-dca3db1fcd7f962a4c8d93ac26ff28fb"/*tpa=https://hm.baidu.com/hm.js?dca3db1fcd7f962a4c8d93ac26ff28fb*/;
//     var s = document.getElementsByTagName("script")[0];
//     s.parentNode.insertBefore(hm, s);
// })();
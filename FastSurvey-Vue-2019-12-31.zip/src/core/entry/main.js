import '../../css/base'
import App from '../module/App/App'
import router from '../module/Route/Route'
import 'iview/dist/styles/iview.css';
import iView from 'iview';
Vue.use(iView);

import SliderVerificationCode from 'slider-verification-code';
import 'slider-verification-code/lib/slider-verification-code.css';
Vue.use(SliderVerificationCode);

/*import SlideVerify from 'vue-monoplasty-slide-verify';
Vue.use(SlideVerify);*/

//注册组件
import '../components/main'
window.Bus = new Vue();

new Vue({
    el:'#app',
    router,
    render: h => h(App)
})

import '../../css/lottery.css'
import Lottery from '../module/Lottery/Lottery.vue'

new Vue({
    el:'#app', 
    render: h => h(Lottery)
})

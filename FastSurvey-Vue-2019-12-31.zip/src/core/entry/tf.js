import '../../css/base'
import App from '../module/App/App'
import router from '../module/TouFang/Route'
import 'iview/dist/styles/iview.css';
import iView from 'iview';
Vue.use(iView);
//注册组件
import '../components/main'
window.Bus = new Vue();

//分享配置
import axios from 'axios';
import * as wxShare from '../util/wxshare'
axios.get(`https://www.fastwj.net/fastSurvey/wechat/getData?url=${encodeURIComponent(window.location.href)}`).then(res => res.data).then((rtn)=>{
    if(rtn.code===0){
        wxShare.wxChatShare(rtn.data)
    }
})

new Vue({
    el:'#app',
    router,
    render: h => h(App)
})

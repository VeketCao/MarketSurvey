<template>
  <div class="lottery wall">
      <div class="btn-bar-top">
          <div class="btn" @click="recordHandle">
             <span >获奖者名单</span>
          </div>
      </div>
      <div id="main_3d" class="3d-qiu">
          <canvas id="myCanvas" width="1100" height="660"></canvas>
      </div>
      <div class="btn-bar-bottom-left">
          <div class="value" >
                <div class="value-select self-scroll" v-if="showShapeDrop">
                    <ul>
                        <li @click="selShapeClick('Sphere')">Sphere</li>
                        <li @click="selShapeClick('hcylinder')">hcylinder</li>
                        <li @click="selShapeClick('vcylinder')">vcylinder</li>
                    </ul>
                </div>
                <div class="value-show" @click="shapeClick">
                    {{shape}}
                </div>
          </div>
          <div class="value" >
                <div class="value-select self-scroll" v-if="showLevelDrop">
                    <ul>
                        <li @click="selLevelClick('一等奖')">一等奖</li>
                        <li @click="selLevelClick('二等奖')">二等奖</li>
                        <li @click="selLevelClick('三等奖')">三等奖</li>
                        <li @click="selLevelClick('四等奖')">四等奖</li>
                        <li @click="selLevelClick('五等奖')">五等奖</li>
                        <li @click="selLevelClick('六等奖')">六等奖</li>
                    </ul>
                </div>
                <div class="value-show" @click="levelClick">
                    {{level}}
                </div>
          </div>
          <div class="value">
                <div class="value-select self-scroll" v-if="showNumDrop">
                    <ul>
                        <li v-for="num in 200" @click="selNumClick(num)"> {{num}}</li>
                    </ul>
                </div>
                <div class="value-show" @click="countClick">
                    {{selected}}
                </div>
          </div>
      </div>
      <div class="btn-bar-bottom-right">
          <div class="btn"  @click="toggleHandle">
             <span>{{running?'停止':'开始'}}</span>
          </div>
          <div class="btn" >
             <span @click="restHandle">重置</span>
          </div>
      </div>
      <div class="pop-record" v-if="showRecord">
         <div class="pop-top">
             <div class="close-icon" @click="closeHandle"></div> 
         </div>
         <div class="middle">
            <div class="lottery-record-list">
                <div class="swiper-container">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="scroll-area-item-list self-scroll">
                                <div class="row" v-for="i in rowNum" :key="i">
                                    <div class="col" v-for="(it,index) in recordList[i-1]" :key="index">
                                        <div class="item">
                                            <div class="record">
                                                <div class="wrap">
                                                    <div class="image">
                                                        <img :src="userImg">
                                                    </div>
                                                    <div class="name">
                                                        {{it.name}}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
  </div>
</template>

<script>
   import '../../lib/tagcanvas.js'
   import api from '../../api/lottery.js'
   export default {
       name: "Lottery",
       data() {
           return {
              showShapeDrop:false,
              showLevelDrop:false,
              showNumDrop:false,
              showRecord:false,
              selected: 10,
              running: false,
              choosed:JSON.parse(localStorage.getItem('choosed')) || {},
              userImg:'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif?imageView2/1/w/80/h/80',
              recordList:[],
              rowNum:1,
              level:'一等奖',
              shape:'Sphere',//Sphere,hcylinder,vcylinder 
           }
       },
       mounted(){
           window.onresize = () => {
            return (() => { 
                this.initCanvase()
            })()}
            this.initCanvase()
       },
       methods:{
           selShapeClick(v){
                this.showShapeDrop = false
                this.shape = v
                this.initCanvase()
           },
           shapeClick(){
               this.showShapeDrop = !this.showShapeDrop
           },
           selLevelClick(v){
                this.showLevelDrop = false
                this.level = v
           },
           levelClick(){
               this.showLevelDrop = !this.showLevelDrop
           },
           selNumClick(num){
                this.showNumDrop = false
                this.selected = num
           },
           countClick(){
               this.showNumDrop = !this.showNumDrop
           },
           closeHandle(){
               this.showRecord = false
           },
           recordHandle(){
               this.showRecord = true
           },
           restHandle(){
               this.shape = 'Sphere'
               this.initCanvase()
               localStorage.clear()
               this.recordList = []
           },
           initCanvase(){
               let canvas = document.getElementById('myCanvas');
                canvas.innerHTML = this.createHTML();
                canvas.width = document.body.offsetWidth;
                canvas.height = document.body.offsetHeight;
                TagCanvas.Start('myCanvas', '', {
                    shape: this.shape,
                    textColour: "#ff99ff",
                    initial: this.speed(),
                    dragControl: 1,
                    textHeight: 15,
                    centreImage: !0,
                    imageAlign: !0,
                    wheelZoom: !1,
                });
           },
           speed(){
               return [0.1 * Math.random() + 0.01, -(0.1 * Math.random() + 0.01)];
           },
           lottery(count){
                var ret = api.getAllUsers().filter((m, index)=>{
                    m.index = index;
                    return !this.choosed[this.getKey(m)];
                }).map((m)=>{
                    return Object.assign({ score: Math.random()}, m);
                }).sort((a, b)=>{
                    return a.score - b.score;
                }).slice(0, count).map((m)=>{ 
                    return m;
                });
                console.log('this.choosed',this.choosed)
                localStorage.setItem('choosed', JSON.stringify(this.choosed));
                return ret;
           },
           buildRecordList(items){
               let result=[];
               
               for(let r=1;r<=this.rowNum;r++){
                   let tp = []
                   items.forEach((it,index)=>{
                        if(Math.ceil((index+1)/5)===r){
                            tp.push(it)
                        }
                    })
                    result.push(tp)
               }
               
               return result
           },
           toggleHandle(){ 
               if(this.running){
                    TagCanvas.SetSpeed('myCanvas', this.speed());
                    var ret = this.lottery(this.selected);
                    console.log('ret',ret)
                    this.recordList = []
                    if (ret.length !== 0) {
                        TagCanvas.Reload('myCanvas');
                        setTimeout(()=>{
                            this.rowNum = Math.ceil(ret.length/5)
                            this.showRecord = true
                            this.recordList = this.buildRecordList(ret)
                        }, 300);
                     }
                } else {
                    TagCanvas.SetSpeed('myCanvas', [3, 1]);
                }
               this.running = !this.running;
           },
           getKey(item){
                return item.phone;
           },
           createHTML(){
               let html = [ '<ul>' ];
               api.getAllUsers().forEach((item, index)=>{
                   let imgUrl = item.img || this.userImg;
                   html.push('<li><a><img style="border-radius: 50%;" width="60" height="60" src="'+ imgUrl +'">' + item.name + '</a></li>');
               }) 
               html.push('</ul>');
               return html.join('');
           }
       }
   }
</script>

<style lang="less" scoped>
   .lottery{
       width: 100%;
       height: 100%;
       position: relative;
       min-width: 1100px;
       &.wall{
            width: 100%;
            height: 100%;
            background-image: url(../../../img/lottery/bg.png);
            overflow: hidden;
            background-color: #121936;
            background-size: 100% 100%;
            background-position: center center;
            background-repeat: no-repeat;
        }
       .3d-qiu{
           position: relative;
           z-index:1000;
           width: 100%;
           height: 100%;
       }
       .btn-bar-top{
            position: absolute;
            top: 10px;
            right: 20px;
            text-align: center;
            z-index: 100;
            -moz-user-select: none;
            -webkit-user-select: none;
            -ms-user-select: none;
            user-select: none;
       }
       .btn-bar-bottom-left{
           position: absolute;
            bottom: 30px;
            left: 20px;
            text-align: center;
            z-index: 100;
            -moz-user-select: none;
            -webkit-user-select: none;
            -ms-user-select: none;
            user-select: none;
            .value{
                display: inline-block;
                position: relative;
                -webkit-box-flex: 1;
                width: 160px;
                height: 48px;
                flex: 1;
                margin: 5px 10px;
                line-height: 40px;
                font-size: 16px;
                @keyframes dropDy {
                    from{height: 0;}
                    to{height: 150px;}
                }
                .value-select{
                    position: absolute;
                    left: 0;
                    bottom: 100%;
                    min-width: 100%;
                    max-height: 200px;
                    line-height: 40px;
                    padding: 10px 0;
                    background: rgba(0,0,0,.5);
                    overflow-y: auto;
                    color: #fff;
                    animation: dropDy 0.5s;
                    animation-fill-mode:forwards;
                    ul li {
                         font-size: 20px;
                    }
                    ul li:hover{
                       background: rgba(0, 0, 0, 0.2);
                    }
                }
                .value-show{
                    position: relative;
                    color: #fff;
                    line-height: 48px;
                    border-radius: 4px;
                    border-style: solid;
                    border-width: 1px;
                    font-size: 24px;
                    border-color: rgb(255, 255, 255);
                    background-color: rgba(0, 0, 0, 0.2);
                    box-shadow: rgb(255, 200, 0) 0px 0px 8px 0px;
                }
            }
       }
       .btn-bar-bottom-right{
            position: absolute;
            bottom: 20px;
            right: 20px;
            text-align: center;
            z-index: 100;
            -moz-user-select: none;
            -webkit-user-select: none;
            -ms-user-select: none;
            user-select: none; 
       }
   }
</style>

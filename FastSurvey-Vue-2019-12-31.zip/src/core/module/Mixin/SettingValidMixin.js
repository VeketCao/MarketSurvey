import api from '@/api/main'
export default {
    data(){
        return{
            authModal:false,
            authMsg:'',
            pass:'',
            setting:{
                isTimeSet:false,//是否开启时间限制
                startTime:'',//开始时间
                endTime:'',//结束时间
                isPassSet:true,//是否开启密码设置
                passType:'phonePass',//密码设置类型，单个密码，短信密码
                answerPass:'',//单个密码
                limitNum:1,//答题次数限制
            },
            phoneNum:'',
            shortCode:'',
            wait:120,
            disableBtn:false,
            codeBtnSp:'发送手机验证码',
            timer:null,
            requestId:'',
            imgValid:false,
            showYzmBox:false,
            imgCode:'',
            imgRequestId:'',
            imgSrc:'',
            imgYzmBtnDis:true,
        }
    },
    methods:{
        phonePassValid(){
            if(this.phoneNum===''){
                this.$Message.warning({ content: '手机号不能为空', duration: 3 })
                return
            }
            if(this.shortCode===''){
                this.$Message.warning({ content: '验证码不能为空', duration: 3 })
                return
            }
            if(this.requestId===''){
                this.$Message.warning({ content: '验证码无效', duration: 3 })
                return
            }
            let param = {phone:this.phoneNum,msgCode:this.shortCode,requestId:this.requestId}
            api.loginByPhoneCode(param).then((rtn)=>{
                console.log('loginByPhoneCode',param)
                if(rtn.code===0){
                    this.authModal = false
                    sessionStorage.setItem('auth','1')
                    sessionStorage.setItem('answerPhone',this.phoneNum)
                }else{
                    this.$Message.error({ content: rtn.msg, duration: 3 })
                }
            })
        },
        imgCodeChange(){
            if(this.imgCode.length === 4){
                this.imgYzmBtnDis = false
            }else{
                this.imgYzmBtnDis = true
            }
        },
        getCaptcha(){
            api.getCaptcha().then((rtn)=>{
                if(rtn.code===0){
                    this.imgSrc=rtn.data.imageUrl
                    this.imgRequestId = rtn.data.imageRequestId
                }
            })
        },
        imgValidHandle(){
            api.checkCaptcha({imgRequestId:this.imgRequestId,imgCode:this.imgCode}).then((rtn)=>{
                console.log(rtn)
                if(rtn.code===0){
                    this.showYzmBox = false
                    this.imgValid = true
                    this.getPhoneCodeClick()
                }else{
                    this.getCaptcha()
                    this.$Message.warning({ content: rtn.msg, duration: 3 })
                }
            })
        },
        timerStart(){
            if(this.wait===0){
                this.codeBtnSp = '发送手机验证码'
                this.wait = 300;
                this.disableBtn = false;
                this.imgValid =  false;
            }else{
                this.codeBtnSp = `${this.wait}秒后点击重新发`
                this.wait=this.wait-1
                this.disableBtn = true;
                this.timer = setTimeout(()=>{this.timerStart()},1000);
            }
        },
        checkMobil(){
            let testPhone=/^[1][3,4,5,7,8][0-9]{9}$/;
            if(this.phoneNum===''){
                this.$Message.warning({ content: '手机号不能为空', duration: 3 })
                return false
            }
            if (!testPhone.exec(this.phoneNum)) {
                this.$Message.warning({ content: '手机号不正确', duration: 3 })
                return false
            }else return true
        },
        getPhoneCodeClick(){
            if(!this.checkMobil()) return
            if(!this.imgValid){
                this.showYzmBox = true
                this.getCaptcha()
                return
            }
            this.disableBtn = true
            this.timerStart()
            api.getPhoneCode({phoneNum:this.phoneNum,imgRequestId:this.imgRequestId,imgCode:this.imgCode}).then((rtn) => {
                if(rtn.code===0){
                    this.$Message.success({ content: '短信验证码已成功发送至您手机,请查收。', duration: 3 })
                    this.requestId = rtn.requestId
                }else{
                    this.$Message.warning({ content: rtn.msg, duration: 3 })
                }
            })
        },
        singlePassValid(){
            if(this.pass===this.setting.answerPass){
                this.authModal = false
                sessionStorage.setItem('auth','1')
            }else{
                this.$Message.warning({ content: `答题密码不正确，请重新输入`, duration: 3 })
            }
        },
        authDeal(){
            let auth = sessionStorage.getItem('auth')
            if(auth && auth==='1') return
            if(this.setting.isTimeSet && (Date.now() < (new Date(this.setting.startTime)).valueOf() || Date.now() > (new Date(this.setting.endTime)).valueOf() )){
                this.authModal = true
                this.authMsg = `请在${this.setting.startTime}~${this.setting.endTime}时间内答题！`
                return
            }
            if(this.setting.isPassSet){
                this.authMsg = ''
                this.authModal = true
            }
        }
    }
}
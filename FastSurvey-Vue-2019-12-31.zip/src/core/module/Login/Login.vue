<template>
    <div class="fullpage-wrapper">
        <login-header></login-header>
        <div class="fullpage-main"></div>
        <div class="validate-box">
            <fieldset class="validate-wrapper" >
                <h1 class="validate-caption">Fast问卷登录</h1>
                <ul v-if="!phoneLogin">
                    <li>
                        <label  class="icon user-icon"></label>
                        <input v-model="username" placeholder="用户名/手机号" class="validate-input user-name" type="text"/>
                    </li>
                    <li>
                        <label class="icon password-icon"></label>
                        <input v-model="password" placeholder="请输入登录密码" class="validate-input"  type="password" @keyup.enter="submitHandle"/>
                    </li>
                </ul>
                <ul v-if="phoneLogin">
                    <li>
                        <label  class="icon mobile-icon"></label>
                        <input v-model="phoneNum" placeholder="手机号" class="validate-input user-name" type="text"/>
                    </li>
                    <li >
                        <input class="validate-input" v-model="shortCode" placeholder="手机验证码"/>
                        <Button style="position: absolute;left: 220px;top:8px" @click="getPhoneCodeClick" :disabled="disableBtn"><span>{{codeBtnSp}}</span></Button>
                    </li>
                </ul>
                <div class="remember-box">
                    <a class="phone-login pull-left" @click="changeLogin" v-if="!phoneLogin"><span>手机短信登录</span></a>
                    <a class="phone-login pull-left" @click="changeLogin" v-if="phoneLogin"><span>用户名密码登录</span></a>
                    <a class="get-back pull-right" href="/main.html#/reset" ><span>忘记用户名/密码？</span></a>
                </div>
            </fieldset>
            <fieldset class="submit-wrapper" style="text-align: center; margin-top: 20px;" >
                <Button class="submit-button" @click="submitHandle">登录</Button>
                <a class="register-now" title="只需２０秒，就可完成注册" href="/main.html#/register">立即注册</a>
                <div class="third-party-login">
                    <div class="third-party-txt">
                        <em class="word" style="color: #888888">第三方登录</em>
                    </div>
                    <div class="penguin-box">
                        <span class="box-item">
                            <a class="icon penguin-icon" @click="QQClick"></a>
                            <p>QQ登录</p>
                            <!--<span id="qqLoginBtn"></span>-->
                        </span>
                        <span class="box-item">
                            <a class="icon wxpenguin-icon" @click="weiXinClick"></a>
                            <p>微信登录</p>
                        </span>
                    </div>
                </div>
            </fieldset>
        </div>
        <div class="footer">
            <a href="http://www.beian.miit.gov.cn" target="_blank" style="color: #f1f1f1">备案号“粤ICP备17049237号-2”</a>
        </div>
        <Modal v-model="showEwModal" class-name="vertical-center-modal" width="480px" title="微信登录" :footer-hide="true">
            <!--<div id="loginCode" ref="loginCodeDiv" class="ewm-div"></div>-->
            <iframe :src="iframeLink" height="400px" style="margin-left: 70px"></iframe>
        </Modal>
        <Modal v-model="showYzmBox" class-name="vertical-center-modal yzm-box" title="机器验证"  width="350px" :footer-hide="true">
            <template v-if="showYzmBox">
                <h2 class="yzm-header">机器验证</h2>
                <div class="yzm-img"><img style="height: 60px;cursor: pointer" :src="imgSrc" @click="getCaptcha"></div>
                <div class="yzm-ipt">
                    <Input v-model="imgCode" placeholder="请输入上方验证码" style="width: 200px" @on-change="imgCodeChange"></Input>
                </div>
                <div class="yzm-btn">
                    <Button @click="imgValidHandle" :disabled="imgYzmBtnDis">验证</Button>
                </div>
            </template>
        </Modal>
    </div>
</template>

<script>
    import LoginHeader from './LoginHeader/main'
    import api from '@/api/main'
    import QRCode from 'qrcodejs2'

    export default {
        name: 'Login',
        components:{
            LoginHeader
        },
        data(){
            return{
                showEwModal:false,
                iframeLink:`${api.getBaseURl()}third/login/wechat`,
                phoneLogin:false,
                username:'',
                password:'',
                phoneNum:'',
                shortCode:'',
                wait:120,
                disableBtn:false,
                codeBtnSp:'发送手机验证码',
                timer:null,
                requestId:'',
                imgValid:false,
                showYzmBox:false,
                imgCode:'',
                imgRequestId:'',
                imgSrc:'',
                imgYzmBtnDis:true
            }
        },
        mounted(){
            //this.bindQRCode('http://localhost:3003/main.html#/login')
        },
        methods:{
            QQClick(){
                window.open(`${api.getBaseURl()}third/login/qq`,"_self")
            },
            weiXinClick(){
                this.showEwModal= true
               // api.wxLogin()
               // window.open(`${api.getBaseURl()}third/login/wechat`,"_self")
            },
            imgCodeChange(){
                if(this.imgCode.length === 4){
                    this.imgYzmBtnDis = false
                }else{
                    this.imgYzmBtnDis = true
                }
            },
            getCaptcha(){
                api.getCaptcha().then((rtn)=>{
                    if(rtn.code===0){
                        this.imgSrc=rtn.data.imageUrl
                        this.imgRequestId = rtn.data.imageRequestId
                    }
                })
            },
            imgValidHandle(){
                api.checkCaptcha({imgRequestId:this.imgRequestId,imgCode:this.imgCode}).then((rtn)=>{
                    if(rtn.code===0){
                        this.showYzmBox = false
                        this.imgValid = true
                        this.getPhoneCodeClick()
                    }else{
                        this.getCaptcha()
                        this.$Message.warning({ content: rtn.msg, duration: 3 })
                    }
                })
            },
            bindQRCode: function (v) {
                new QRCode(this.$refs.loginCodeDiv, {
                    text: v,
                    width: 260,
                    height: 260,
                    colorDark: "#333333", //二维码颜色
                    colorLight: "#ffffff", //二维码背景色
                    correctLevel: QRCode.CorrectLevel.L//容错率，L/M/H
                })
            },
            timerStart(){
                if(this.wait===0){
                    this.codeBtnSp = '发送手机验证码'
                    this.wait = 300;
                    this.disableBtn = false;
                    this.imgValid =  false;
                }else{
                    this.codeBtnSp = `${this.wait}秒后点击重新发`
                    this.wait=this.wait-1
                    this.disableBtn = true;
                    this.timer = setTimeout(()=>{this.timerStart()},1000);
                }
            },
            checkMobil(){
                let testPhone=/^[1][3,4,5,7,8][0-9]{9}$/;
                if(this.phoneNum===''){
                    this.$Message.warning({ content: '手机号不能为空', duration: 3 })
                    return false
                }
                if (!testPhone.exec(this.phoneNum)) {
                    this.$Message.warning({ content: '手机号不正确', duration: 3 })
                    return false
                }else return true
            },
            getPhoneCodeClick(){
                if(!this.checkMobil()) return
                if(!this.imgValid){
                    this.showYzmBox = true
                    this.getCaptcha()
                    return
                }
                this.disableBtn = true
                this.timerStart()
                api.getPhoneCode({phoneNum:this.phoneNum,imgRequestId:this.imgRequestId,imgCode:this.imgCode}).then((rtn) => {
                    if(rtn.code===0){
                        this.$Message.success({ content: '短信验证码已成功发送至您手机,请查收。', duration: 3 })
                        this.requestId = rtn.requestId
                    }else{
                        this.$Message.warning({ content: rtn.msg, duration: 3 })
                    }
                })
            },
            changeLogin(){
                this.phoneLogin = !this.phoneLogin
                this.codeBtnSp = '发送手机验证码'
                this.wait=120
                clearTimeout(this.timer);
            },
            submitHandle(){
                if(this.phoneLogin){
                    if(this.phoneNum===''){
                        this.$Message.warning({ content: '手机号不能为空', duration: 3 })
                        return
                    }
                    if(this.shortCode===''){
                        this.$Message.warning({ content: '验证码不能为空', duration: 3 })
                        return
                    }
                    if(this.requestId===''){
                        this.$Message.warning({ content: '验证码无效', duration: 3 })
                        return
                    }
                    let param = {phone:this.phoneNum,msgCode:this.shortCode,requestId:this.requestId}
                    api.loginByPhoneCode(param).then((rtn)=>{
                        if(rtn.code===0){ 
                            AppUtil.loginTo()
                        }else{
                            this.$Message.error({ content: rtn.msg, duration: 3 })
                        }
                    })
                }else{
                    if(this.username===''){
                        this.$Message.warning({ content: '用户名不能为空', duration: 3 })
                        return;
                    }
                    if(this.password===''){
                        this.$Message.warning({ content: '密码不能为空', duration: 3 })
                        return;
                    }
                    let userInfo = {username:this.username,password:this.password}
                    api.login(userInfo).then((rtn)=>{
                        if(rtn.code===0){
                            AppUtil.loginTo()
                        }else{
                            this.$Message.error({ content: rtn.msg, duration: 3 })
                        }
                    })
                }
            }
        }
    }
</script>
<style lang="less" scoped>
    .footer{
        position: fixed;
        z-index: 100000;
        left: 50%;
        bottom: 10px;
        margin-left: -85px;
    }
    .ewm-div{
        width: 280px;
        height: 280px;
        border: 1px solid #e1e7f2;
        padding: 10px 10px;
        margin: 40px 0px 40px 95px;
    }
    .fullpage-wrapper{
        position: relative;
        width: 100%;
        height: 100%;
        .fullpage-main{
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            z-index: 1;
            background-image: url(../../../img/login_bk.jpg);
            background-repeat: no-repeat;
            background-size: cover;
            filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='//image.wjx.com/images/newimg/register-login/bacg.jpg',sizingMethod='scale');
            background-position: center center;
        }
        .validate-box{
            width: 480px;
            position: fixed;
            top: 50%;
            left: 50%;
            margin-top: -260px;
            margin-left: -240px;
            z-index: 2;
            border-radius: 14px;
            background-color: #fff;
            fieldset{
                border: 0px solid #c0c0c0;
                margin: 0;
                padding: 0;
            }
            .validate-wrapper{
                padding: 0 50px;
                .validate-input{
                    margin-right: 0;
                    width: 228px;
                    padding-right: 130px;
                    padding-left: 20px;
                }
                .get-code-btn{
                    position: absolute;
                    top:9px;
                    left: 210px;
                    color: #f7941d;
                    border-radius: 100px;
                    background-color: #fff;
                    border-color: #f7941d;
                }
                .disable-btn{
                    cursor: default;
                    color: #9d9d9d;
                    border-color: #9d9d9d;
                }
                .validate-caption{
                    font-size: 24px;
                    line-height: 24px;
                    font-weight: bold;
                    color: #fa9111;
                    padding: 40px 0;
                    text-align: left;
                }
                ul li{
                    position: relative;
                    width: 100%;
                    margin-bottom: 16px
                }
                .icon{
                    width: 20px;
                    height: 20px;
                    position: absolute;
                    left: 16px;
                    top: 12px;
                }
                .user-icon{
                    background: url(//image.wjx.com/images/register-login/user.png) no-repeat center;
                }
                .password-icon{
                    background: url(//image.wjx.com/images/register-login/password.png) no-repeat center;
                }
                .mobile-icon{
                    background: url(//image.wjx.com/images/register-login/phone.png) no-repeat center;
                }
                .validate-input{
                    width: 100%;
                    height: 46px;
                    line-height: 1.4;
                    font-size: 14px;
                    padding: 10px 0 10px 46px;
                   /* border-radius: 100px;*/
                    border: 1px solid #e6e6e6;
                    background: #fff !important;
                }
                .validate-input:hover{
                    border-color: #fa9111;
                }
                .remember-box{
                    overflow: hidden;
                    font-size: 14px;
                    margin: 26px 0px 17px 10px;
                    .automatic-box {
                        color: #666666;
                    }
                    .pull-left {
                        float: left !important;
                    }
                    .get-back {
                        color: #666666;
                        text-decoration: underline;
                    }
                    .pull-right {
                        float: right !important;
                    }
                    .phone-login{
                        color: #ff6700;
                        border: 0 none;
                        height: auto;
                        line-height: normal;
                        margin: 0;
                    }
                }
            }
            .submit-wrapper {
                padding: 0 50px;
                .submit-button{
                    width: 100% !important;
                    height: 46px !important;
                    font-size: 20px !important;
                   /* border-radius: 100px !important;*/
                    background-color: #fa911e;
                    border: none !important;
                    color:#fff;
                }
                .submit-button:hover{
                    border-color: #fa9111;
                }
                .register-now{
                    font-size: 18px;
                    color: #fa911e;
                    margin: 16px 0 26px;
                    display: block;
                }
                .third-party-login{
                    min-height: 120px;
                    width: 100%;
                    .third-party-txt{
                        font-size: 14px;
                        color: #cccccc;
                        margin-bottom: 5px;
                        border-top: 1px solid #cccccc;
                        .word{
                            position: relative;
                            top: -11px;
                            font-style: normal;
                            padding: 0 6px;
                            background-color: #fff;
                        }
                    }
                    .penguin-box{
                        .box-item{
                            display: inline-block;
                            margin-right: 20px;
                            .wxpenguin-icon{
                                width: 56px;
                                height: 56px;
                                background: url(//image.wjx.com/images/register-login/weixin-nor.png) no-repeat center;
                            }
                            .wxpenguin-icon:hover {
                                background: url(//image.wjx.com/images/register-login/weixin.png) no-repeat center;
                            }
                            .penguin-icon{
                                width: 56px;
                                height: 56px;
                                margin-right: 0;
                                background: url(//image.wjx.com/images/register-login/qq.png) no-repeat center;
                            }
                            .penguin-icon:hover {
                                background: url(//image.wjx.com/images/register-login/qq-hover.png) no-repeat center;
                            }
                        }
                    }
                }
            }

        }
    }
</style>
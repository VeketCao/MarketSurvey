<template>
    <header class="header">
        <div class="logo">
            <img src="../../../../img/logo_text.png" class="img-logo">
        </div>
        <ul class="header-entry fl">
            <li><a href="./index.htm">首页</a></li>
            <li><a href="./buy2.jsp.htm">购买咨询</a></li>
            <li><a href="./introduction.jsp.htm">功能介绍</a></li>
        </ul>
    </header>
</template>

<script>
    import api from '@/api/main'
    export default {
        name: "LoginHeader",
        //props:['data'],
        data(){
            return{

            }
        },
        methods:{

        }
    }
</script>

<style scoped lang="less">
    .header {
        position: fixed;
        z-index: 203;
        top: 0;
        left: 0;
        display: -webkit-box;
        display: -webkit-flex;
        display: -moz-box;
        display: -ms-flexbox;
        display: flex;
        align-items: center;
        width: 100%;
        min-width: 600px;
        height: 105px;
        background-color: rgba(0, 0, 0, 0);
        .header-entry {
            display: -webkit-box;
            display: -webkit-flex;
            display: -moz-box;
            display: -ms-flexbox;
            display: flex;
            height: 50px;
            margin-left: 30px;
            font-family:Microsoft YaHei;
            font-size: 20px;
            color: #fff;
            li {
                height: 50px;
                margin-right: 30px;
                line-height: 50px;
                cursor: pointer;
                a {
                    color: #fff;
                }
                a:hover {
                    color: #00A5FF;
                }
            }

        }
        .logo{
            margin: 0 35px;
            .img-logo{
                width: 158px;
                //height: 30px;
            }
            .sp-logo{
                position: absolute;
                top:15px;
                left: 70px;
                color: #fff;
                font-size: 16px;
            }
        }
    }

</style>
<template>
    <div class="preview">
        <!--<div class="tool-bar">
            <div>
                电脑预览
            </div>
        </div>-->
        <div class="content">
            <div class="box beauty-scroll-bar">
                <div class="page" v-if="pageConfig">
                    <div class="header-title">
                        <div class="t-name">{{pageConfig.title || ''}}</div>
                        <div class="t-des">{{pageConfig.desc || ''}}</div>
                    </div>
                    <div class="item-list">
                        <template v-for="(it,index) in pageConfigPage.items">
                            <component :is="it.name" :data="it" :key="it.key" mode="edit"></component>
                        </template>
                    </div>
                </div>
                <div class="footer-btn">
                    <Button type="primary" @click="commitHandle" :loading="loading" v-if="pageNum==0">提交</Button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import api from '@/api/main'

    export default {
        name: "Preview",
        data(){
            return{
                pageNum:0,
                curIndex:0,
                loading:false,
                pageConfig:null,
                pageConfigPage:null
            }
        },
        mounted() {
            this.pageConfig = JSON.parse(localStorage.getItem('pageConfig'))
            console.log('Preview',this.pageConfig)
            this.buildPageConfigPage()
            Bus.$on('PaginationEvent',this.pageEventHandle)
        },
        methods:{
            pageEventHandle(num){
                console.log('pageConfig',this.pageConfig)
                console.log('pageConfigPage',this.pageConfigPage)
                this.pageConfigPage.items = []
                for(let j=this.curIndex;j<this.pageConfig.items.length;j++){
                    if(!(j==this.pageConfig.items.length-1 && this.pageConfig.items[j].name=='Pagination')){
                        this.pageConfigPage.items.push(this.pageConfig.items[j])
                        this.curIndex = j+1;
                        if(this.pageConfig.items[j].name=='Pagination'){
                            this.pageNum = this.pageConfig.items[j].opts.pageNum
                            break
                        }else {
                            this.pageNum = 0
                        }
                    }
                }
            },
            buildPageConfigPage(){
                this.pageConfigPage={
                    items:[],
                    opts:this.pageConfig.opts
                };
                for(let i=0;i<this.pageConfig.items.length;i++){
                    if(!((i==0||i==this.pageConfig.items.length-1) && this.pageConfig.items[i].name=='Pagination')){
                        this.pageConfigPage.items.push(this.pageConfig.items[i])
                        this.curIndex = i+1;
                        if(this.pageConfig.items[i].name=='Pagination'){
                            this.pageNum = this.pageConfig.items[i].opts.pageNum
                            break
                        }else {
                            this.pageNum = 0
                        }
                    }
                }
            },
            check(){
                let rtn = true;
                this.pageConfig.items.forEach((it)=>{
                    if(it.opts.require && _.isEmpty(it.opts.answer)){
                        rtn = false;
                        this.$Message.warning({ content: `第${it.opts.seq}题必答，请答完题再提交`, duration: 3 })
                    }
                })
                return rtn
            },
            commitHandle(){
                this.$Message.success({ content: '预览页面不能提交', duration: 3 })
                console.log(JSON.stringify(this.pageConfig))
                return;
                /*if(!this.check()) return;
                this.loading = true;
                api.saveSurveyAnswer(this.pageConfig).then((rtn)=>{
                    this.loading = false;
                    if(rtn.code==0){
                        this.$Message.success({ content: '提交成功', duration: 3 })
                    }else{
                        this.$Message.error({ content: rtn.msg, duration: 3 })
                    }
                })*/
            }
        },
        beforeDestroy() {
            Bus.$off('PaginationEvent',this.pageEventHandle)
        }
    }
</script>

<style lang="less" scoped>
    .preview{
        background-color: #F3F6FA;
        background-image: url(../../../img/bg@2x.jpg);
        background-repeat: repeat-x;
        background-size: 1px 300px;
        overflow-y: auto;
        .tool-bar{
            position: fixed;
            top:0;
            z-index: 1;
            height: 70px;
            width: 100%;
            left: 0;
            background-color: #fff;
            box-shadow: 0px 1px 0px 0px rgba(232,232,232,1);
        }
        .content{
            width: 920px;
            background: url(../../../img/bk@2x.jpg) no-repeat top center;
            background-size: 910px 144px;
            padding-top: 120px;
            margin: 0 auto;
            min-height: 1000px;
            overflow-y: auto;
            .box{
                background: white;
                width: 920px;
                height: 800px;
                margin: 0 auto;
                box-shadow: 0px 1px 6px 0px rgba(205,220,245,1);
                overflow-y: auto;
                .page{
                    min-height: 600px;
                    .header-title{
                        width: 100%;
                        height: 100%;
                        margin-top: 30px;
                        .t-name{
                            text-align: center;
                            font-size: 24px;
                            font-weight: bold;
                            vertical-align: middle;
                            padding: 20px 0;
                            line-height: 30px;
                        }
                        .t-des{
                            height: 100%;
                            color: #555555;
                            text-align: left;
                            font-size: 14px;
                            padding: 0px 150px;
                            border: 0;
                            word-wrap: break-word;
                        }
                    }
                    .item-list{
                        width: 100%;
                        padding: 0px 49px;
                    }
                }
            }
            .footer-btn{
                width: 100%;
                height: 100px;
                text-align: center;
            }
        }
    }
</style>
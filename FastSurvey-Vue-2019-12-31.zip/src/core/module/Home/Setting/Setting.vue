<template>
    <div class="setting">
        <div class="title-bar">
            <span class="header-sp">《{{titleName}}》问卷答题权限设置</span>
        </div>
        <div class="time-section">
            <Row style="margin-bottom: 10px">
                <Col span="2" style="margin-top: 0px;width: 100px"> <strong>时间设置</strong> </Col>
                <Col span="6">
                    <i-switch size="large" v-model="setting.isTimeSet">
                        <span slot="open">开启</span>
                        <span slot="close">关闭</span>
                    </i-switch>
                </Col>
            </Row>
            <div v-if="setting.isTimeSet" >
                <Row class="r-item">
                    <Col span="2" style="margin-top: 5px;width: 100px">开始时间</Col>
                    <Col span="6"><DatePicker  :options="optionsStart" type="date" v-model="setting.startTime" @on-change="onStartTimeChange"></DatePicker></Col>
                </Row>
                <Row class="r-item">
                    <Col span="2" style="margin-top: 5px;width: 100px">结束时间</Col>
                    <Col span="6"><DatePicker :options="optionsEnd" type="date" v-model="setting.endTime" @on-change="onEndTimeChange"></DatePicker></Col>
                </Row>
            </div>
        </div>
        <div class="pass-section">
            <Row>
                <Col span="2" style="margin-top: 0px;width: 100px"> <strong>密码设置</strong> </Col>
                <Col span="6">
                    <i-switch size="large" v-model="setting.isPassSet">
                        <span slot="open">开启</span>
                        <span slot="close">关闭</span>
                    </i-switch>
                </Col>
            </Row>
            <div v-if="setting.isPassSet" class="pass-set-item">
                <RadioGroup v-model="setting.passType" vertical  >
                    <Radio label="singlePass">
                        <Icon type="social-apple"></Icon>
                        <span>单个密码</span>
                        <Input v-if="setting.passType==='singlePass'" placeholder="答题密码" type="password" v-model="setting.answerPass" style="margin-left: 20px"></Input>
                    </Radio>
                    <Radio label="phonePass">
                        <Icon type="social-android"></Icon>
                        <span>短信密码</span>
                    </Radio>
                </RadioGroup>
            </div>
        </div>
        <div class="limit-section">
            <Row>
                <Col span="2" style="margin-top: 5px;width: 100px"><strong>答题次数限制</strong></Col>
                <Col span="12" >
                    <Input-number v-model="setting.limitNum" :min="1" :max="1000000" ></Input-number>
                    <span>(同一个IP答题次数,默认同一个IP只能答一次)</span>
                </Col>
            </Row>
        </div>
        <div class="save-section">
            <Button type="primary" @click="saveHandle">保存设置</Button>
        </div>
    </div>
</template>

<script>
    import api from '@/api/main'
    export default {
        name: "Setting",
        data(){
            return{
                optionsStart: {
                    disabledDate (date) {
                        return date && date.valueOf() < Date.now() - 86400000
                    }
                },
                optionsEnd: {
                    disabledDate (date) {
                        return date && date.valueOf() < Date.now() - 86400000
                    }
                },
                titleName:localStorage.getItem('title_name'),
                setting:{
                    isTimeSet:false,
                    startTime:'',
                    endTime:'',
                    isPassSet:false,
                    passType:'singlePass',
                    answerPass:'',
                    limitNum:1,
                }
            }
        },
        mounted(){
            this.querySetting()
        },
        methods:{
            querySetting(){
                api.getSettingBySurveyId({surveyId:this.$route.query.surveyId}).then((rtn)=>{
                    if(rtn.code===0){
                        console.log('getSettingBySurveyId',rtn)
                        this.setting = rtn.data
                    }else{
                        this.$Message.warning({ content: rtn.msg, duration: 3 })
                    }
                })
            },
            onStartTimeChange(startTime,type){
                this.optionsEnd = {
                    disabledDate (endTime) {
                        return endTime  &&  (endTime.valueOf() < new Date(startTime) - 86400000)
                    }
                }
            },
            onEndTimeChange(endTime,type){
                this.optionsStart = {
                    disabledDate (startTime) {
                        return startTime && ((startTime.valueOf() > new Date(endTime) - 86400000) || startTime < Date.now() - 86400000)
                    }
                }
            },
            saveHandle(){
                let p={
                    surveyId:this.$route.query.surveyId,
                    isTimeSet:this.setting.isTimeSet,
                    startTime:this.setting.startTime,
                    endTime:this.setting.endTime,
                    isPassSet:this.setting.isPassSet,
                    passType:this.setting.passType,
                    answerPass:this.setting.answerPass,
                    limitNum:this.setting.limitNum,
                }
                api.setSetting(p).then((rtn)=>{
                    if(rtn.code===0){
                        this.$Message.success({ content: `保存成功`, duration: 3 })
                        window.location.href='./main.html#/home/mine'
                    }else{
                        this.$Message.warning({ content: rtn.msg, duration: 3 })
                    }
                })
            }
        }
    }
</script>
<style lang="less">
    .pass-set-item .ivu-radio-group{
        margin: 5px 0px;
    }
    .pass-set-item .ivu-radio-group-vertical .ivu-radio-wrapper{
       margin: 15px 0px;
    }
</style>
<style lang="less" scoped>
.setting{
    position: relative;
    height: 100%;
    min-width: 860px;
    .title-bar{
        display: inline-block;
        padding: 20px 20px;
        height: 60px;
        width: 100%;
        box-sizing: border-box;
        box-shadow: 0px 3px 8px 0px rgba(224, 229, 236, 0.4);
        .header-sp{
            font-size: 16px;
        }
    }
    .time-section{
        margin: 30px 50px;
        .r-item{
            margin: 15px 0px;
        }
    }
    .pass-section{
        margin: 20px 50px 0px;
        .r-item{
            margin: 15px 0px;
        }
    }
    .limit-section{
        margin: 20px 50px;
    }
    .save-section{
        margin: 40px 50px;
    }
}
</style>
<template>
    <div class="header-bar">
        <a class="logo fl">
            <img src="../../../../img/logo.png" class="img-logo">
            <span class="sp-logo">Fast问卷</span>
        </a>
        <div class="user-info fr">
            <div class="user-img" v-clickoutside="closeDropBox">
                <img :src="userImg" class="user-avatar" @click="showDropBox">
                <div class="drop-info" v-if="showDrop">
                    <Row class="row-item">
                        <Col span="10">用户名:</Col>
                        <Col span="12">{{username}}</Col>
                    </Row>
                    <Row class="row-item">
                        <Col span="10">账号ID:</Col>
                        <Col span="12">{{userId}}</Col>
                    </Row>
                    <Row class="row-item">
                        <Col span="10">手机号:</Col>
                        <Col span="12">{{mobile}}</Col>
                    </Row>
                    <Row class="row-item">
                        <Col span="10">邮箱地址:</Col>
                        <Col span="12">{{email}}</Col>
                    </Row>
                    <Row class="row-item">
                        <Col span="10">微信：</Col>
                        <Col span="12">{{wx}}</Col>
                    </Row>
                </div>
            </div>
            <Dropdown style="margin: 8px 0px 0px 3px" trigger="click" @on-click="clickHandle">
                <span class="user-sp" >
                    {{username}}
                    <Icon type="ios-arrow-down"></Icon>
                </span>
                <DropdownMenu slot="list">
                    <DropdownItem name="logout">退出</DropdownItem>
                </DropdownMenu>
            </Dropdown>
        </div>
        <Modal title="手机号绑定" v-model="authModal" class-name="vertical-center-modal" :mask-closable="false" :footer-hide="true">
            <div>
                <Row style="margin: 15px 100px">
                    <Col span="24"><Input v-model="phoneNum" placeholder="手机号" size="large"></Input></Col>
                </Row>
                <Row style="margin: 25px 100px">
                    <Col span="24">
                        <Input v-model="shortCode" placeholder="手机验证码" size="large"></Input>
                        <Button size="small" style="position: absolute;left: 160px;top:5px" :disabled="disableBtn"  @click="getPhoneCodeClick">{{codeBtnSp}}</Button>
                    </Col>
                </Row>
                <Row style="margin: 25px 100px">
                    <Col span="12"><Button type="primary" @click="phoneBanding">绑定</Button></Col>
                </Row>
            </div>
        </Modal>
        <Modal v-model="showYzmBox" class-name="vertical-center-modal dtyz-box" title="机器验证"  width="350px" :footer-hide="true">
            <template v-if="showYzmBox">
                <h2 class="yzm-header">机器验证</h2>
                <div class="yzm-img"><img style="height: 60px;cursor: pointer" :src="imgSrc" @click="getCaptcha"></div>
                <div class="yzm-ipt">
                    <Input v-model="imgCode" placeholder="请输入上方验证码" style="width: 200px" @on-change="imgCodeChange"></Input>
                </div>
                <div class="yzm-btn">
                    <Button @click="imgValidHandle" :disabled="imgYzmBtnDis">验证</Button>
                </div>
            </template>
        </Modal>
    </div>
</template>

<script>
    import api from '@/api/main'
    import SettingValidMixin from "../../Mixin/SettingValidMixin";
    export default {
        name: "HeaderBar",
        mixins:[
            SettingValidMixin
        ],
        data(){
            return{
                username:'',
                userImg:'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif?imageView2/1/w/80/h/80',
                userId:'',
                showDrop:false,
                mobile:'',
                email:'',
                wx:''
            }
        },
        mounted() {
            api.getUserInfo().then((rtn)=>{
                console.log('getUserInfo',rtn)
                if(rtn.code===0){
                    this.username = rtn.data.name
                    this.userId = rtn.data.userId
                    this.mobile = rtn.data.mobile || ''
                    this.email = rtn.data.email || ''
                    this.wx = rtn.data.wechatUuid || ''

                    if(!_.isEmpty( rtn.data.picture)){
                        this.userImg = rtn.data.picture
                    }
                    if(_.isEmpty(rtn.data.mobile)){//手机号空则弹出绑定手机号
                        this.authModal = true
                    }
                }
            })
        },
        directives: {
            clickoutside: {//点击下拉框外的其它区域时关闭下拉框
                bind(el, binding, vnode) {
                    function documentHandler(e) {
                        if (el.contains(e.target)) {
                            return false
                        }
                        if (binding.expression) {
                            binding.value(e)
                        }
                    }
                    function KeyUp(e) {
                        if (e.keyCode === 27) {
                            if (binding.expression) {
                                binding.value(e)
                            }
                        }
                    }
                    el.__vueClickOutSize__ = documentHandler
                    el.__vueKeyup__ = KeyUp
                    document.addEventListener('keyup', KeyUp)
                    document.addEventListener('click', documentHandler)
                },
                unbind(el, binding) {
                    document.removeEventListener('click', el.__vueClickOutSize__)
                    delete el.__vueClickOutSize__
                    document.removeEventListener('keyup', el.__vueKeyup__)
                    delete el.__vueKeyup__
                }
            }
        },
        methods:{
            showDropBox(){
                this.showDrop = !this.showDrop
            },
            closeDropBox(){
                this.showDrop = false
            },
            phoneBanding(){
                if(this.phoneNum===''){
                    this.$Message.warning({ content: '手机号不能为空', duration: 3 })
                    return
                }
                if(this.shortCode===''){
                    this.$Message.warning({ content: '验证码不能为空', duration: 3 })
                    return
                }
                if(this.requestId===''){
                    this.$Message.warning({ content: '验证码无效', duration: 3 })
                    return
                }
                let param = {userId:this.userId,phone:this.phoneNum,msgCode:this.shortCode,requestId:this.requestId}
                console.log('param',param)
                api.bindPhone(param).then((rtn)=>{
                    if(rtn.code===0){
                        this.authModal = false
                        this.$Message.success({ content:'绑定成功', duration: 3 })
                        window.location.reload()

                    }else{
                        this.$Message.error({ content: rtn.msg, duration: 3 })
                    }
                })
            },
            clickHandle(name){
                if(name=='logout'){
                    api.logout().then((rtn)=>{
                        window.location.href = './main.html#/login'
                    })
                }
            }
        }
    }
</script>

<style lang="less" scoped>
    .header-bar{
        .logo{
            margin: 10px 45px;
            .img-logo{
                width: 30px;
                height: 48px;
            }
            .sp-logo{
                position: absolute;
                top:35px;
                left: 73px;
                color: #fff;
                font-size: 16px;
            }
        }
        .user-info{
            position: relative;
            z-index: 201;
            margin-top: 16px;
            margin-right: 45px;
            .user-img{
                float: left;
                .user-avatar{
                    width: 40px;
                    height: 40px;
                    border-radius: 50%;
                    cursor: pointer;
                }
                @keyframes dropBoxH {
                    from{height: 0px;}
                    to{height: 110px;}
                }
                .drop-info{
                    position:absolute;
                    left: -70px;
                    background: #fff;
                    width: 170px;
                    padding: 5px;
                    border-radius: 5px;
                    border: 1px solid #eee;
                    z-index: 1000;
                    overflow: hidden;
                    animation: dropBoxH 0.5s;
                    animation-fill-mode:forwards;
                    .row-item{
                        margin-left: 10px
                    }
                }
            }
            .user-sp{
                color: #fff;
                margin: 8px 0px 0px 3px;
                font-size: 14px;
            }
        }
    }
</style>
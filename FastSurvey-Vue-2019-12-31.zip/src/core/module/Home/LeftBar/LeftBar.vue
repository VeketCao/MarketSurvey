<template>
    <div class="left-bar">
        <Menu theme='dark' :open-names="['1']" :active-name="flag" @on-select="selectHandle">
            <Submenu name="1">
                <template slot="title">
                    <Icon type="md-appstore" />
                    我的应用
                </template>
                <MenuItem name="1-1">问卷调查</MenuItem>
                <MenuItem name="1-2">在线投票</MenuItem>
                <MenuItem name="1-3">在线抽奖</MenuItem> 
            </Submenu>
        </Menu>
    </div>
</template>

<script>
    export default {
        name: "LeftBar",
        data(){
            return{
                flag:'1-1'
            }
        },
        mounted(){
            if(this.$route.path === '/home/mine'){
                this.flag = '1-1'
            }else if(this.$route.path === '/home/vote'){
                this.flag = '1-2'
            }
        },
        methods:{
            selectHandle(name){
                console.log(name)
                if(name==='1-1'){
                    window.location.href = './main.html#/home/mine'
                }else if(name==='1-2'){
                    window.location.href = './main.html#/home/vote'
                }else if(name==='1-3'){
                    window.open('./lottery.html')
                }
            }
        }
    }
</script>

<style lang="less" scoped>
    .left-bar{
        width: 100%;
        .nav-ul{
            li{
                margin: 0px 25px;
            }
            li a{
                color: #666;
                padding: 5px 60px;
                line-height: 50px;
                font-size: 14px;
                cursor: pointer;
            }
            li a:hover{
                color: #008fff;
            }
            .active{
                color: #008fff;
                border-bottom: 2px solid #008fff;
            }
        }
    }
</style>
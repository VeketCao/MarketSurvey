<template>
    <div class="home-page">
        <div class="home-header">
            <HeaderBar></HeaderBar>
        </div>
        <div class="home-left">
            <div style="height: 68px"></div>
            <LeftBar></LeftBar>
        </div>
        <div class="home-main">
            <router-view></router-view>
        </div>
    </div>
</template>

<script>
    import HeaderBar from "./HeaderBar/HeaderBar";
    import LeftBar from "./LeftBar/LeftBar";
    export default {
        name: "Home",
        components:{
            HeaderBar,
            LeftBar
        }
    }
</script>

<style lang="less" scoped>
    .home-page{
        position: relative;
        overflow-x: hidden;
        overflow-y: auto;
        .home-header{
            position: relative;
            z-index: 1000;
            height: 68px;
            background-color: #222d32;
        }
        .home-left{
            position: absolute;
            top: 0px;
            left: 0;
            height: 100%;
            width: 240px;
            background-color: #515a6e;
        }
        .home-main{
            background-color: #fff;
            z-index: 800;
            transition: transform .3s ease-in-out,margin .3s ease-in-out;
            margin-left: 240px;
            min-height: 927px;
        }
    }
</style>
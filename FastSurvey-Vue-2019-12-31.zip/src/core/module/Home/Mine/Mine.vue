<template>
    <div class="mine">
        <div class="tool-bar">
            <Button type="primary"  @click="addHandle"><Icon type="md-add" size="18"/>创建问卷</Button>
            <Button  @click="importHandle" style="margin-left: 20px">导入</Button>
            <Dropdown @on-click="clickImportHandle" style="margin-left:20px">
                <span >
                    导入样例
                    <Icon type="ios-arrow-down"></Icon>
                </span>
                <DropdownMenu slot="list">
                    <DropdownItem name="look">查看导入样例</DropdownItem>
                    <DropdownItem name="down">下载导入样例</DropdownItem>
                </DropdownMenu>
            </Dropdown>
        </div>
        <div class="list-container">
            <Row>
                <Col span="4" style="margin-left:10px"><Input placeholder="问卷名称" v-model="searchParam.title"></Input></Col>
                <Col span="4" style="margin-left:20px">
                    <Select clearable v-model="searchParam.status" placeholder="状态">
                        <Option value="1">草稿</Option>
                        <Option value="2">发布</Option>
                        <Option value="3">结束</Option>
                    </Select>
                </Col>
                <Col span="4" style="margin-left:20px">
                    <Button type="primary" @click="queryHandle">查询</Button> 
                    <Button style="position:absolute;margin-left:5px" @click="resetHandle">重置</Button>
                </Col>
            </Row>
            <div class="table-assembly">
                <Table class="table-style" border :columns="cols" :data="items"></Table>
                <Page :total="total" @on-change="onPageChange"  size="small" show-elevator show-total/>
            </div>
        </div>
        <!--<input v-model="tf_link" id="tou_fang" style="position: absolute;top:-10px;left: 0px"/>-->
        <Modal v-model="showNewModal" class-name="vertical-center-modal" title="创建问卷" >
            <template v-if="showNewModal">
                <Row type="flex" class="item-row">
                    <Col span="4" style="margin: 8px 0px 0px 20px">问卷名称：</Col>
                    <Col span="14"><Input v-model="titleName"></Input></Col>
                </Row>
                <Row type="flex" class="item-row">
                    <Col span="4" style="margin: 8px 0px 0px 20px">问卷说明：</Col>
                    <Col span="14">
                        <Input v-model="desc" type="textarea" :autosize="{minRows: 2,maxRows: 5}"></Input>
                    </Col>
                </Row>
                <div slot="footer">
                    <Button @click="cancelHandle">取消</Button>
                    <Button type="primary" @click="addOkHandle">确定</Button>
                </div>
            </template>
        </Modal>
        <Modal v-model="importModal" style="">
            <p slot="header" style="color:#6063A8;font-size:15px;">
                <span>导入问卷</span>
            </p>
            <div class="view-content import-staff" >
                <div class="upload-assembly" >
                    <div class="upload-flex">
                        <div class="upload-flex-item">
                            <Upload type="drag" ref="upload" class="drag-upload" :action="uploadUrl" :format="format" :on-format-error="formatError"
                                    :show-upload-list="false" :on-success="uploadSuccess" :data="params" :before-upload="handleBeforeUpload">
                                <div style="padding: 35px 0">
                                    <Icon type="ios-cloud-upload" size="52"></Icon>
                                    <p class="upload-txt">点击或将文件拖拽到此处上传</p>
                                </div>
                            </Upload>
                        </div>
                    </div>
                </div>
            </div>
        </Modal>
        <Modal v-model="sampleModal" class-name="vertical-center-modal" width="650px" :footer-hide="true">
            <template v-if="sampleModal">
                <Input v-model="sampleValue" type="textarea" :rows="30" readonly></Input>
            </template>
        </Modal>
    </div>
</template>

<script>
    import api from '@/api/main'
    export default {
        name: "Mine",
        data(){
            return{
                searchParam:{
                    title:'',
                    status:null,
                    pageNum:0,
                    pageSize:10
                },
                sampleModal:false,
                sampleValue:'',
                params:{},
                uploadUrl:`${api.getBaseURl()}surveyMain/import`,
                importModal:false,
                format: ['txt'],
                tf_link:'',
                total:0,
                showNewModal:false,
                titleName:'',
                desc:'',
                pageNum:0,
                cols:[
                    {
                        title:'问卷名称',
                        key:'title'
                    },
                    {
                        title:'状态',
                        key:'status',
                        width:'125px',
                        render:(h, params) => {
                            if(params.row.status == 1){
                                return h('p', '草稿')
                            }else if(params.row.status == 2){
                                return h('p', '发布')
                            }else{
                                return h('p', '结束')
                            }
                        }
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 600,
                        align: 'left',
                        render: (h, params) => {
                            return h('div', [
                                h('Button', {
                                    props: {
                                        type: 'primary',
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px',
                                        display:`${params.row.status===1?'in-block':'none'}`
                                    },
                                    on: {
                                        click: () => {
                                            let url = `./main.html#/designer?id=${params.row.id}`
                                            window.open(url)
                                        }
                                    }
                                }, '设计'),
                                h('Button', {
                                    props: {
                                        type: 'primary',
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px',
                                        display:`${params.row.status===1?'in-block':'none'}`
                                    },
                                    on: {
                                        click: () => {
                                            api.publish({surveyId:params.row.id}).then((rtn)=>{
                                                if(rtn.code==0){
                                                    this.$Message.success({ content: '发布成功', duration: 3 })
                                                    this.refreshTable(this.pageNum)
                                                }else{
                                                    this.$Message.error({ content: rtn.msg, duration: 3 })
                                                }
                                            })
                                        }
                                    }
                                }, '发布'),
                                h('Button', {
                                    props: {
                                        type: 'primary',
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px',
                                        display:`${params.row.status==2?'in-block':'none'}`
                                    },
                                    on: {
                                        click: () => {
                                            api.stopPublish({surveyId:params.row.id}).then((rtn)=>{
                                                if(rtn.code==0){
                                                    this.$Message.success({ content: '停止成功', duration: 3 })
                                                    this.refreshTable(this.pageNum)
                                                }else{
                                                    this.$Message.error({ content: rtn.msg, duration: 3 })
                                                }
                                            })
                                        }
                                    }
                                }, '停止'),
                                h('Button', {
                                    props: {
                                        type: 'primary',
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px',
                                        display:`${params.row.status===2?'in-block':'none'}`
                                    },
                                    on: {
                                        click: () => {
                                            let url = `./main.html#/answer?id=${params.row.id}`
                                            window.open(url)
                                        }
                                    }
                                }, '答题'),
                                h('Button', {
                                    props: {
                                        type: 'primary',
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px',
                                        display:`${params.row.status===2?'in-block':'none'}`
                                    },
                                    on: {
                                        click: () => {
                                            let url = `./main.html#/link?id=${params.row.id}`
                                            window.open(url)
                                        }
                                    }
                                }, '投放'),
                                h('Button', {
                                    props: {
                                        type: 'error',
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px'
                                    },
                                    on: {
                                        click: () => {
                                            this.$Modal.confirm({
                                                title: '删除操作',
                                                content: '<p>确认要删除该问卷？</p>',
                                                onOk: () => {
                                                    api.deleteSurvey({surveyId:params.row.id}).then((rtn)=>{
                                                        if(rtn.code==0){
                                                            this.$Message.success({ content: '删除成功', duration: 3 })
                                                            this.refreshTable(this.pageNum)
                                                        }else{
                                                            this.$Message.error({ content: rtn.msg, duration: 3 })
                                                        }
                                                    })
                                                },
                                                onCancel: () => {
                                                }
                                            });

                                        }
                                    }
                                }, '删除'),
                                h('Button', {
                                    props: {
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px'
                                    },
                                    on: {
                                        click: () => {
                                            localStorage.setItem('title_name',params.row.title)
                                            let url = `./main.html#/home/setting?surveyId=${params.row.id}`
                                            window.open(url)
                                        }
                                    }
                                }, '设置'),
                                h('Button', {
                                    props: {
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px'
                                    },
                                    on: {
                                        click: () => {
                                            window.open(`${window.location.origin}/fastSurvey/surveyMain/export2text?surveyId=${params.row.id}`)
                                        }
                                    }
                                }, '导出'),
                                h('Button', {
                                    props: {
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px'
                                    },
                                    on: {
                                        click: () => {
                                            let url = `./main.html#/home/analysis?id=${params.row.id}`
                                            window.open(url)
                                        }
                                    }
                                }, '统计分析'),
                                h('Button', {
                                    props: {
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px'
                                    },
                                    on: {
                                        click: () => {
                                            localStorage.setItem('title_name',params.row.title)
                                            let url = `./main.html#/home/recovery_data?id=${params.row.id}`
                                            window.open(url)
                                        }
                                    }
                                }, '查看回收数据')
                            ]);
                        }
                    }
                ],
                items:[]
            }
        },
        mounted(){
            this.refreshTable(this.pageNum)
        },
        methods:{
            resetHandle(){
                this.searchParam.title = ''
                this.searchParam.status = null
                this.refreshTable(this.pageNum)
            },
            queryHandle(){
                this.refreshTable(this.pageNum)
            },
            clickImportHandle(name){
                if(name=='look'){
                    this.sampleModal = true
                    api.getImportExport().then((rtn)=>{
                        if(rtn.code===0){
                            this.sampleValue = rtn.data
                        }else {
                            this.$Message.warning({ content: rtn.msg, duration: 3 })
                        }
                    })
                }else if(name=='down'){
                    let eleLink = document.createElement('a');
                    eleLink.download = '导入样例';
                    eleLink.style.display = 'none';
                    eleLink.href = `${api.getBaseURl()}surveyMain/exportImportExample`;
                    document.body.appendChild(eleLink);
                    eleLink.click();
                    document.body.removeChild(eleLink);
                }
            },
            formatError() {
                this.$Message.warning({ content: '请上传.txt格式', duration: 3 })
            },
            importHandle(){
                this.importModal = true
                this.params={}
            },
            uploadSuccess(res) {
                if (res.code === 0) {
                    this.$Message.success({ content:'导入成功', duration: 3 })
                    this.refreshTable(this.pageNum)
                    this.importModal = false
                } else {
                    this.$Message.warning({ content: res.msg, duration: 3 })
                }
            },
            handleBeforeUpload: function () {
                //this.spinShow = true
            },
            onPageChange(pageNum) {
                this.pageNum = pageNum-1
                this.refreshTable(pageNum-1)
            },
            addHandle(){
                this.showNewModal = true
                this.titleName = ''
                this.desc=''
            },
            cancelHandle(){
                this.showNewModal = false
            },
            addOkHandle(){
                let temp = {
                    items:[],
                    title:'标题',
                    desc:'问卷说明XXXXXX',
                    mode:'designer'
                }
                temp.title = this.titleName;
                temp.desc = this.desc;
                if(this.titleName == ''){
                    this.$Message.warning({ content: '问卷名称不能为空', duration: 3 })
                    return
                }
                api.saveSurvey(temp).then((rtn)=>{
                    if(rtn.code==0){
                        this.$Message.success({ content: '创建成功', duration: 3 })
                        this.refreshTable(this.pageNum)
                    }else{
                        this.$Message.error({ content: rtn.msg, duration: 3 })
                    }
                })
                this.showNewModal = false
            },
            refreshTable(pageNum){//列表接口
                this.items=[];
                this.searchParam.pageNum = pageNum
                let tp = JSON.parse(JSON.stringify(this.searchParam))
                if(tp.status!==null)tp.status = parseInt(tp.status)
                api.querySurveyList(tp).then((rtn)=>{
                    if(rtn.code==0){
                        this.items = rtn.data.records || []
                        this.total = rtn.data.total
                    }else{
                        this.$Message.error({ content: rtn.msg, duration: 3 })
                    }
                })
            }
        }
    }
</script>

<style lang="less" scoped>
    .item-row{
        margin: 15px 0px 0px 0px;
    }
    .mine{
        min-width: 950px;
        .tool-bar{
            padding: 15px 30px;
            height: 60px;
            box-sizing: border-box;
            box-shadow: 0px 3px 8px 0px rgba(224, 229, 236, 0.4);
            .ui-btn{
                display: inline-block;
                margin: 10px 20px;
                width: 150px;
                padding: 0;
                height: 36px;
                background: #0095FF;
                border-radius: 2px;
                font-size: 16px;
                line-height: 36px;
                font-weight: 600;
                color: #fff !important;
                white-space: nowrap;
                text-align: center;
                border: none;
            }
        }
        .list-container{
            padding: 10px 20px;
            .list-header{
                margin: 10px 0px 0px 10px;
                line-height: 44px;
                color: #000000;
                font-size: 20px;
                font-weight: 600;
            }
        }
    }
</style>
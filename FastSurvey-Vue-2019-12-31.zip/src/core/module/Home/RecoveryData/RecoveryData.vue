<template>
    <div class="recovery-data">
        <div class="title-bar">
            <span class="header-sp">《{{titleName}}》问卷数据回收列表</span>
            <!--<div class="btn-bar">
                <Button @click="exportHandle">导出</Button>
            </div>-->
        </div>
        <div class="box beauty-scroll-bar">
            <div class="query-section">
                <div class="q-title" @click="showQueryHandle"><Icon type="md-search" size="20"/>自定义查询</div>
                <div v-if="showQuery" class="condition-box">
                    <Row v-for="(searchItem,i) in searchList" :key="i" class="row-item">
                        <Col span="9">
                            <Select v-model="searchItem.titleKey" placeholder="请选择题目" @on-change="tChangeHandle($event,i)">
                                <Option v-for="(item,j) in itemsList" :value="item.key" :key="j">{{item.opts.tNum}}.{{item.opts.title}}</Option>
                            </Select>
                        </Col>
                        <template v-if="searchItem.titleKey!==''">
                            <Col span="9" style="margin-left:5px">
                                <template v-if="searchItem.xxList.length>0">
                                    <Select v-model="searchItem.titleValue" placeholder="请选择选项">
                                        <Option v-for="(xxItem,k) in searchItem.xxList" :value="xxItem.name" :key="k">{{xxItem.name}}</Option>
                                    </Select>
                                </template>
                                <template v-else>
                                    <div style="padding: 5px 5px;float: left">
                                        <span >包含</span>
                                    </div>
                                    <Input v-model="searchItem.titleValue" style="position: absolute;width: 232px"></Input>
                                </template>
                            </Col>
                        </template>
                        <Col span="3" style="margin-left:5px">
                            <Select v-model="searchItem.type" placeholder="逻辑" style="width: 70px">
                                <Option value="AND">且</Option>
                                <Option value="OR">或</Option>
                            </Select>
                        </Col>
                        <Col span="1" style="margin-top:5px">
                            <a @click="removeHandle(i)"><Icon type="ios-trash-outline" size="24"/></a>
                        </Col>
                    </Row>
                    <div class="add" @click="addHandle">
                        <Icon type="ios-add-circle-outline" size="18" />新增查询条件
                    </div>
                    <div style="margin-top:10px;height: 20px;margin-left: 45%">
                        <Button type="primary" @click="queryHandle" :disabled="disableBtn">查询</Button>
                        <Button style="margin-left: 3px" @click="exportHandle">导出</Button>
                    </div>
                </div>
            </div>
            <div class="table-assembly rd-table">
                <Table class="table-style" border :columns="cols" :data="items" width="calc(100% - 230px)">
                    <template slot-scope="{row,index}" slot="look">
                        <a style="color: #a9a9a9" @click="lookHandle(row)"><Icon type="ios-eye-outline" size="24"/></a>
                    </template>
                    <template slot-scope="{ row }" :slot="'Attachment'+ num" v-for="num in 10">
                        <div v-for="(it,index) in row['Attachment'+num]" :key="index">
                            <a :href="it.attachmentUrl" target="_blank" ><Icon type="md-attach" size="18"/><span>{{it.attachmentName}}</span></a>
                        </div>
                    </template>
                </Table>
                <Page :total="total" @on-change="onPageChange"  size="small" show-elevator show-total/>
            </div>
        </div>
        <Modal v-model="showImgModal" class-name="vertical-center-modal" :width="dyWidth" :footer-hide="true">
            <template v-if="showImgModal">
                <img :src="showUrl" ref="showImg" @load="loadHandle">
            </template>
        </Modal>
    </div>
</template>

<script>
    import api from '@/api/main'
    export default {
        name: "RecoveryData",
        data(){
            return{
                titleName:localStorage.getItem('title_name'),
                showImgModal:false,
                dyWidth:500,
                showUrl:'',
                total:0,
                pageNum:0,
                pageSize:20,
                cols:[],
                items:[],
                showQuery:true,
                itemsList:[],
                searchList:[{
                    titleKey:'',
                    titleValue:'',
                    type:'AND',
                    xxList:[],
                }],
                disableBtn:false
            }
        },
        mounted(){
            this.renderQuerySection()
            this.refreshTable()
        },
        methods:{
            queryHandle(){
                this.disableBtn = true;
                this.refreshTable()
            },
            removeHandle(index){
                this.$nextTick(() => {
                    this.searchList.splice(index,1)
                })
            },
            addHandle(){
                if(this.searchList.length===10){
                    this.$Message.warning({ content: '最多允许10个查询条件', duration: 3 })
                    return
                }
                this.searchList.push({
                    titleKey:'',
                    titleValue:'',
                    type:'AND',
                    xxList:[],
                })
            },
            tChangeHandle(v,index){
                this.searchList[index].xxList = []
                this.itemsList.forEach((it)=>{
                    if(it.key === v){
                        if(!_.isEmpty(it.opts.list) && it.name !== 'MultiFillBlank'){
                            this.$set(this.searchList,index,{
                                ...this.searchList[index],
                                xxList:JSON.parse(JSON.stringify(it.opts.list)),
                            })
                        }
                    }
                })
            },
            showQueryHandle(){
                this.showQuery = !this.showQuery
            },
            getSearchParam(){
                let tp = {
                    surveyId:parseInt(this.$route.query.id),
                    pageSize: this.pageSize,
                    pageNum: this.pageNum,
                    conditions:[]
                }
                this.searchList.forEach((it)=>{
                    if(!_.isEmpty(it.titleKey)){
                        tp.conditions.push(_.omit(it,'xxList'))
                    }
                })
                return tp
            },
            renderQuerySection(){
                api.querySurvey({surveyId:parseInt(this.$route.query.id)}).then((rtn)=>{
                    if(rtn.code===0){
                        let pageConfig =  JSON.parse(rtn.data)
                        this.itemsList = _.filter(pageConfig.items||[],(it)=>{
                            return (it.name !=='Attachment' && it.name !=='MatrixRadio' && it.name !=='MatrixCheckbox' && it.name !=='SectionDesc' && it.name !=='Pagination' && it.name !=='Sort')
                        })
                    }else{
                        this.$Message.warning({ content: rtn.msg, duration: 3 })
                    }
                })
            },
            loadHandle(){
                console.log('loadHandle',this.$refs.showImg.width)
                this.dyWidth = this.$refs.showImg.width+30
            },
            attachmentClick(it){
                console.log('attachmentClick',it)
                /*if(it.attachmentFileExt ==='.jpg' || it.attachmentFileExt ==='.png' || it.attachmentFileExt ==='.git' || it.attachmentFileExt ==='.jpeg'){
                    this.showImgModal = true;
                    this.showUrl = it.attachmentUrl
                }*/
                /*let eleLink = document.createElement('a');
                eleLink.download = '附件';
                eleLink.style.display = 'none';
                eleLink.href = it.attachmentUrl;
                document.body.appendChild(eleLink);
                eleLink.click();
                document.body.removeChild(eleLink);*/
            },
            lookHandle(row){
                let url = `./main.html#/queryAnswer?id=${row.surveyAnswerId}`
                window.open(url)
            },
            exportHandle(){
                window.open(`${api.getBaseURl()}statistics/exportAnswerRecordList?surveyId=${this.$route.query.id}`)
            },
            refreshTable(){
                if(this.$route.query.id){
                    api.getAnswerRecordList(this.getSearchParam()).then((rtn)=>{
                        console.log('getAnswerRecordList',rtn)
                        this.disableBtn = false
                        if(rtn.code===0){
                            let tp=[{title:'查看',slot:'look'},{ title:'序号', key:'seq'}]
                            Array.prototype.push.apply(tp,rtn.data.titles)
                            tp[0].width=65
                            tp[1].width=65
                            tp[2].width=175
                            this.cols =tp
                            if(this.cols.length>9){
                                this.cols.forEach((col,index)=>{
                                    if(index>=3) col.width = 200
                                })
                            }
                            this.items = rtn.data.pages.records
                            this.items.forEach((it,i)=>{
                                it.seq=i+1
                            })
                            this.total = rtn.data.pages.total
                        }else {
                            this.$Message.warning({ content: rtn.msg, duration: 3 })
                        }
                    })
                }
            },
            onPageChange(pageNum){
                this.pageNum = pageNum-1
                this.refreshTable()
            }
        }
    }
</script>

<style lang="less" scoped>
.recovery-data{
    position: relative;
    height: 100%;
    .title-bar{
        display: inline-block;
        padding: 20px 20px;
        height: 60px;
        width: 100%;
        box-sizing: border-box;
        box-shadow: 0px 3px 8px 0px rgba(224, 229, 236, 0.4);
        .header-sp{
            font-size: 16px;
        }
        .btn-bar{
            margin: -5px 0px;
            float: right;
        }
    }
    .box{
        width: 100%;
        height: 700px;
        overflow: auto;
        .query-section{
            padding: 10px 30px;
            .q-title{
                cursor: pointer;
                font-size: 14px;
                font-weight: bold
            }
            .condition-box{
                margin-top: 10px;
                width: 760px;
                background-color: #f5f7fa;
                border: solid 1px #a6d7ff;
                padding: 24px 24px 22px;
                border-radius: 4px;
                position: relative;
                .row-item{
                    padding-bottom: 10px;
                }
                .add{
                    padding: 5px 280px;
                    color: #a9a8a8;
                    border: dashed 1px #d4d7d9;
                    cursor: pointer;
                }
                .add:hover{
                    color: #1ea0fa;
                    border: dashed 1px #1ea0fa;
                }
            }
        }
    }
    .rd-table{
        padding: 20px 20px;
        width: 100%;
    }
}
</style>
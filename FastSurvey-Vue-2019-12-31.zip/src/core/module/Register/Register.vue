<template>
    <div class="fullpage-wrapper">
        <LoginHeader></LoginHeader>
        <div class="fullpage-main"></div>
        <div class="validate-box">
            <fieldset class="validate-wrapper">
                <h1 class="validate-caption">用户注册</h1>
                <ul>
                    <li>
                        <label  class="icon user-icon"></label>
                        <input v-model="username" placeholder="账户，支持英文与数字，注册后不能修改" class="validate-input user-name" type="text"/>
                    </li>
                    <li>
                        <label  class="icon user-icon"></label>
                        <input v-model="name" placeholder="姓名，支持中英文" class="validate-input user-name" type="text"/>
                    </li>
                    <li>
                        <label class="icon password-icon"></label>
                        <input v-model="password" placeholder="密码，8~20位字母、数字、下划线" class="validate-input"  type="password" />
                    </li>
                    <li>
                        <label class="icon mobile-icon"></label>
                        <input v-model="phone" placeholder="手机号" class="validate-input"/>
                    </li>
                    <li >
                        <input class="validate-input" v-model="code" placeholder="手机验证码"/>
                        <Button style="position: absolute;left: 220px;top:7px" @click="getPhoneCodeClick" :disabled="disableBtn"><span>{{codeBtnSp}}</span></Button>
                    </li>
                </ul>
            </fieldset>
            <fieldset class="submit-wrapper" style="text-align: center; margin-top: 20px;">
                <Button class="submit-button" @click="addUser">创建用户</Button>
                <a class="log-on" href="/main.html#/login">已有账号，立即登录</a>
                <div class="third-party-login">

                </div>
            </fieldset>
        </div>
        <Modal v-model="showYzmBox" class-name="vertical-center-modal yzm-box" title="机器验证"  width="350px" :footer-hide="true">
            <template v-if="showYzmBox">
                <h2 class="yzm-header">机器验证</h2>
                <div class="yzm-img"><img style="height: 60px;cursor: pointer" :src="imgSrc" @click="getCaptcha"></div>
                <div class="yzm-ipt">
                    <Input v-model="imgCode" placeholder="请输入上方验证码" style="width: 200px" @on-change="imgCodeChange"></Input>
                </div>
                <div class="yzm-btn">
                    <Button @click="imgValidHandle" :disabled="imgYzmBtnDis">验证</Button>
                </div>
            </template>
        </Modal>
    </div>
</template>

<script>
    import api from '@/api/main'
    import LoginHeader from '../Login/LoginHeader/main'
    export default {
        name: "Register",
        data(){
            return{
                name:'',
                username:'',
                password:'',
                phone:'',
                code:'',
                requestId:'',
                wait:120,
                disableBtn:false,
                codeBtnSp:'发送手机验证码',
                timer:null,
                imgValid:false,
                showYzmBox:false,
                imgCode:'',
                imgRequestId:'',
                imgSrc:'',
                imgYzmBtnDis:true
            }
        },
        components:{
            LoginHeader
        },
        methods:{
            imgCodeChange(){
                if(this.imgCode.length === 4){
                    this.imgYzmBtnDis = false
                }else{
                    this.imgYzmBtnDis = true
                }
            },
            getCaptcha(){
                api.getCaptcha().then((rtn)=>{
                    if(rtn.code===0){
                        this.imgSrc=rtn.data.imageUrl
                        this.imgRequestId = rtn.data.imageRequestId
                    }
                })
            },
            imgValidHandle(){
                api.checkCaptcha({imgRequestId:this.imgRequestId,imgCode:this.imgCode}).then((rtn)=>{
                    console.log(rtn)
                    if(rtn.code===0){
                        this.showYzmBox = false
                        this.imgValid = true
                        this.getPhoneCodeClick()
                    }else{
                        this.getCaptcha()
                        this.$Message.warning({ content: rtn.msg, duration: 3 })
                    }
                })
            },
            timerStart(){
                if(this.wait===0){
                    this.codeBtnSp = '发送手机验证码'
                    this.wait = 300;
                    this.disableBtn = false;
                }else{
                    this.codeBtnSp = `${this.wait}秒后点击重新发`
                    this.wait=this.wait-1
                    this.disableBtn = true;
                    this.timer = setTimeout(()=>{this.timerStart()},1000);
                }
            },
            getPhoneCodeClick(){
                //if(this.disableBtn) return
                if(!this.checkMobil()) return
                if(!this.imgValid){
                    this.showYzmBox = true
                    this.getCaptcha()
                    return
                }
                this.disableBtn = true
                this.timerStart()
                api.getPhoneCode({phoneNum:this.phone,imgRequestId:this.imgRequestId,imgCode:this.imgCode}).then((rtn) => {
                    if(rtn.code===0){
                        this.$Message.success({ content: '短信验证码已成功发送至您手机,请查收。', duration: 3 })
                        this.requestId = rtn.requestId
                    }else{
                        this.$Message.warning({ content: rtn.msg, duration: 3 })
                    }
                })
            },
            checkPassWd(){
                let testPassword=/^(\w){8,20}$/;
                if (!testPassword.exec(this.password)) {
                    this.$Message.warning({ content: '密码只能输入8~20位字母、数字、下划线', duration: 3 })
                    return false
                }else  return true
            },
            checkMobil(){
                let testPhone=/^[1][3,4,5,7,8][0-9]{9}$/;
                if (!testPhone.exec(this.phone)) {
                    this.$Message.warning({ content: '手机号不正确', duration: 3 })
                    return false
                }else return true
            },
            addUser(){
                if(this.username===''){
                    this.$Message.warning({ content: '用户名不能为空', duration: 3 })
                    return;
                }
                if(this.name===''){
                    this.$Message.warning({ content: '姓名不能为空', duration: 3 })
                    return;
                }
                if(this.password===''){
                    this.$Message.warning({ content: '密码不能为空', duration: 3 })
                    return;
                }
                if(this.phone===''){
                    this.$Message.warning({ content: '手机号不能为空', duration: 3 })
                    return;
                }
                if(this.code===''){
                    this.$Message.warning({ content: '验证码不能为空', duration: 3 })
                    return;
                }
                if(this.requestId===''){
                    this.$Message.warning({ content: '验证码无效', duration: 3 })
                    return;
                }
                if(this.checkPassWd() && this.checkMobil()){
                    api.register({username:this.username,password:this.password,phone:this.phone,name:this.name,code:this.code,requestId:this.requestId}).then((rtn)=>{
                        if(rtn.code==0){
                            
                            window.location.href = './main.html#/login'
                        }else{
                            this.$Message.error({ content: rtn.msg, duration: 3 })
                        }
                    })
                }
            }
        }
    }
</script>

<style lang="less" scoped>
    .fullpage-wrapper{
        position: relative;
        width: 100%;
        height: 100%;
        .fullpage-main{
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            z-index: 1;
            background-image: url(../../../img/login_bk.jpg);
            background-repeat: no-repeat;
            background-size: cover;
            filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='//image.wjx.com/images/newimg/register-login/bacg.jpg',sizingMethod='scale');
            background-position: center center;
        }
        .validate-box{
            width: 480px;
            position: fixed;
            top: 40%;
            left: 50%;
            margin-top: -260px;
            margin-left: -240px;
            z-index: 2;
            border-radius: 14px;
            background-color: #fff;
            fieldset{
                border: 0px solid #c0c0c0;
                margin: 0;
                padding: 0;
            }
            .validate-wrapper{
                padding: 0 50px;
                .validate-caption{
                    font-size: 24px;
                    line-height: 24px;
                    font-weight: bold;
                    color: #fa9111;
                    padding: 40px 0;
                    text-align: left;
                }
                ul li{
                    position: relative;
                    width: 100%;
                    margin-bottom: 16px
                }
                .icon{
                    width: 20px;
                    height: 20px;
                    position: absolute;
                    left: 16px;
                    top: 12px;
                }
                .user-icon{
                    background: url(//image.wjx.com/images/register-login/user.png) no-repeat center;
                }
                .password-icon{
                    background: url(//image.wjx.com/images/register-login/password.png) no-repeat center;
                }
                .mobile-icon{
                    background: url(//image.wjx.com/images/register-login/phone.png) no-repeat center;
                }
                .get-code-btn{
                    position: absolute;
                    top: 9px;
                    left: 210px;
                    width: 130px;
                    height: 28px;
                    font-size: 12px;
                    color: #f7941d;
                    border-radius: 100px;
                    background-color: #fff;
                    border-color: #f7941d;
                    line-height: 2;
                }
                .disable-btn{
                    cursor: default;
                    color: #9d9d9d;
                    border-color: #9d9d9d;
                }
                .validate-input{
                    width: 100%;
                    height: 46px;
                    line-height: 1.4;
                    font-size: 14px;
                    padding: 10px 0 10px 46px;
                    /*border-radius: 100px;*/
                    border: 1px solid #e6e6e6;
                    background: #fff !important;
                }
                .validate-input:hover{
                    border-color: #fa9111;
                }
                .remember-box{
                    overflow: hidden;
                    font-size: 14px;
                    margin-top: 26px;
                    margin-bottom: 17px;
                    .automatic-box {
                        color: #666666;
                    }
                    .pull-left {
                        float: left !important;
                    }
                    .get-back {
                        color: #666666;
                        text-decoration: underline;
                    }
                    .pull-right {
                        float: right !important;
                    }
                }
            }
            .submit-wrapper {
                padding: 0 50px;
                .submit-button{
                    width: 100% !important;
                    height: 46px !important;
                    font-size: 20px !important;
                    /*border-radius: 100px !important;*/
                    background-color: #fa911e;
                    border: none !important;
                    color:#fff;
                }
                .submit-button:hover{
                    border-color: #fa9111;
                }
                .register-now{
                    font-size: 18px;
                    color: #fa911e;
                    margin: 16px 0 26px;
                    display: block;
                }
                .log-on{
                    font-size: 18px;
                    color: #075DB3;
                    margin: 16px 0 26px;
                    display: block;
                }
                .log-on:hover{
                    color: #f08200;
                }
                .third-party-login{
                    height: 20px;
                    width: 100%;
                }
            }

        }
    }
</style>
/**
 * Created by Veket on 2019/10/6.
 */
import VueRouter from 'vue-router';

import Answer from '../Answer/Answer.vue';
import AnswerMobile from '../Answer/AnswerMobile.vue';
import AnswerFinish from "../Answer/AnswerFinish";
import AnswerError from "../Answer/AnswerError";

Vue.use(VueRouter);
let routeArr = []
if (/(iPhone|iPad|iPod|iOS|Android)/i.test(navigator.userAgent)) { //移动端
    routeArr = [
        {
            path: '/',redirect:'/dj',
        },
        {
            path:'/dj',
            name:'AnswerMobile',
            component: AnswerMobile,
        },
        {
            path:'/finish',
            name:'answerFinish',
            component:AnswerFinish
        },
        {
            path:'/error',
            name:'answerError',
            component:AnswerError
        }
    ]
} else {
    routeArr = [
        {
            path: '/',redirect:'/dj',
        },
        {
            path:'/dj',
            name:'Answer',
            component: Answer,
        },
        {
            path:'/finish',
            name:'answerFinish',
            component:AnswerFinish
        },
        {
            path:'/error',
            name:'answerError',
            component:AnswerError
        }
    ]
}
const routesMap = routeArr;

const router = new VueRouter({
    mode: 'hash',
    base: __dirname,
    routes: routesMap
});

export default router
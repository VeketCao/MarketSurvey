<template>
    <div class="build-link">
        <div class="share-content">
            <Row class="row-item">
                <Col span="4">
                    <div id="qrcode" ref="qrCodeDiv" class="ewm-div">
                    </div>
                </Col>
                <Col>
                    <div class="ui-copy-text">
                        <input class="ui-input" id="share_link" v-model="shareLink" readonly></input>
                        <button class="ui-button" style="position: absolute;top:0px;right: 88px" @click="copyHandle">复制</button>
                        <button class="ui-button" style="position: absolute;top:0px;right: 0px" @click="openHandle">打开</button>
                    </div>
                    <div>
                        <button class="ui-button" style="width: 100px;margin-top: 20px" @click="downLoadHandle">下载二维码</button>
                    </div>
                </Col>
            </Row>
            <div class="hr"></div>
            <div class="section-title">网站嵌入</div>
            <Row>
                <Col>
                    <div class="ui-copy-text" style="width: 765px">
                        <input class="ui-input" style="width: 730px" id="web_in_link" v-model="webInLink" readonly></input>
                        <button class="ui-button" style="position: absolute;top:0px;right: 0px" @click="webInLinkCopy">复制</button>
                    </div>
                </Col>
            </Row>
        </div>
    </div>
</template>

<script>
    import QRCode from 'qrcodejs2'
    import api from '@/api/main'
    export default {
        name: "BuildLink",
        data(){
            return{
                shareLink:'',
                webInLink:''
            }
        },
        mounted() {
            let url = `https://${window.location.host}/tf.html#/dj?id=${this.$route.query.id}`
            api.slink({prefix:'wj',url:url}).then((rtn)=>{
                if(rtn.code===0){
                    this.shareLink = rtn.dlChain
                    this.webInLink = `<iframe height="1200" width="800" src="${this.shareLink}" frameborder="0" allowfullscreen></iframe>`
                    this.$nextTick(function () {
                        this.bindQRCode(this.shareLink);
                    })
                }else{
                    this.$Message.warning({ content: rtn.msg, duration: 3 })
                }
            })
        },
        methods:{
            webInLinkCopy(){
                let tp=document.getElementById("web_in_link");
                tp.select();
                document.execCommand("Copy");
                this.$Message.success({ content: '已复制好，可贴粘。', duration: 3 })
            },
            bindQRCode: function (link) {
                new QRCode(this.$refs.qrCodeDiv, {
                    text: link,
                    width: 90,
                    height: 90,
                    colorDark: "#333333", //二维码颜色
                    colorLight: "#ffffff", //二维码背景色
                    correctLevel: QRCode.CorrectLevel.L//容错率，L/M/H
                })
            },
            copyHandle(){
                let Url2=document.getElementById("share_link");
                Url2.select();
                document.execCommand("Copy");
                this.$Message.success({ content: '已复制好，可贴粘。', duration: 3 })
            },
            openHandle(){
                window.open(`tf.html#/dj?id=${this.$route.query.id}`)
            },
            downLoadHandle(){
                let qrcode = document.getElementById('qrcode');
                let img = qrcode.getElementsByTagName('img')[0];
                let link = document.createElement("a");
                link.setAttribute("href",img.getAttribute("src"));
                link.setAttribute("download",'qrcode.png');
                link.click();
            }
        }
    }
</script>

<style lang="less" scoped>
    .build-link{
        position: relative;
        margin: 0 auto;
        padding: 70px 20px 80px;
        -webkit-box-sizing: border-box;
        box-sizing: border-box;
        min-height: 100%;
        min-width: 950px;
        max-width: 970px;
        z-index: 1;
        .row-item{
            padding: 20px 20px;
        }
        .ewm-div{
            width: 110px;
            height: 110px;
            border: 1px solid #e1e7f2;
            padding: 10px 10px;
        }
        .share-content{
            padding: 30px 20px;
            background-color: #fff;
            border: 1px solid #e1e7f2;
            border-bottom-left-radius: 4px;
            border-bottom-right-radius: 4px;
            border-top-right-radius: 4px;
            .ui-copy-text{
                position: relative;
                box-shadow: 0px 3px 8px 0px rgba(224, 229, 236, 0.4);
                overflow: hidden;
                width: 560px;
                .ui-input{
                    width: 400px;
                    box-sizing: border-box;
                    background-color: #f6f6f6;
                    height: 45px;
                    line-height: 45px;
                    padding-left: 13px;
                    padding-right: 13px;
                    border: 1px solid #e1e7f2;
                    border-radius: 4px;
                    color: #333;
                }
            }
            .ui-button{
                height: 45px;
                line-height: 45px;
                width: 75px;
                padding: 0;
                text-align: center;
                background-color: #fff;
                border: 1px solid #e1e7f2;
                border-radius: 4px;
                -webkit-appearance: none;
                cursor: pointer;
                font-size: 14px;
            }
            .ui-button:hover{
                background-color: #eee;
            }
            .hr{
                border: 1px solid #e1e7f2;
                border-width: 0 0 1px 0;
                margin-top: 40px;
                margin-bottom: 40px;
                margin-right: 30px;
            }
            .section-title{
                font-size: 15px;
                font-weight: bold;
                margin: 15px 0;
                text-align: left;
                width: 100%;
            }
        }
    }
</style>
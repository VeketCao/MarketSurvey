<template>
    <div class="query-answer">
        <!--查询答卷-->
        <div class="content">
            <div class="box">
                <div class="page" v-if="pageConfig">
                    <div class="header-title">
                        <div class="t-name">{{pageConfig.title || '标题'}}</div>
                        <div class="t-des">{{pageConfig.desc || '问卷说明xxxx'}}</div>
                    </div>
                    <div class="item-list">
                        <template v-for="(it,index) in pageConfigPage.items">
                            <component :is="it.name" :data="it" :key="it.key" mode="query"></component>
                            <!--<div v-if="it.name!=='Pagination'" class="mask-layer"></div>-->
                        </template>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import api from '@/api/main'
    export default {
        name: "QueryAnswer",
        data(){
            return{
                pageNum:0,
                curIndex:0,
                loading:false,
                pageConfig:null,
                pageConfigPage:null
            }
        },
        mounted() {
            if(this.$route.query.id){
                api.querySurveyAnswer({surveyAnswerId:this.$route.query.id}).then((rtn)=>{
                    if(rtn.code===0){
                        this.pageConfig =  JSON.parse(rtn.data)
                        this.buildPageConfigPage()
                    }else{
                        this.$Message.warning({ content: rtn.msg, duration: 3 })
                    }
                })
            }
            Bus.$on('PaginationEvent',this.pageEventHandle)
        },
        methods:{
            pageEventHandle(num){
                console.log('pageConfig',this.pageConfig)
                console.log('pageConfigPage',this.pageConfigPage)
                this.pageConfigPage.items = []
                for(let j=this.curIndex;j<this.pageConfig.items.length;j++){
                    if(!(j==this.pageConfig.items.length-1 && this.pageConfig.items[j].name=='Pagination')){
                        this.pageConfigPage.items.push(this.pageConfig.items[j])
                        this.curIndex = j+1;
                        if(this.pageConfig.items[j].name=='Pagination'){
                            this.pageNum = this.pageConfig.items[j].opts.pageNum
                            break
                        }else {
                            this.pageNum = 0
                        }
                    }
                }
            },
            buildPageConfigPage(){
                this.pageConfigPage={
                    items:[],
                    opts:this.pageConfig.opts
                };
                for(let i=0;i<this.pageConfig.items.length;i++){
                    if(!((i==0||i==this.pageConfig.items.length-1) && this.pageConfig.items[i].name=='Pagination')){
                        this.pageConfigPage.items.push(this.pageConfig.items[i])
                        this.curIndex = i+1;
                        if(this.pageConfig.items[i].name=='Pagination'){
                            this.pageNum = this.pageConfig.items[i].opts.pageNum
                            break
                        }else {
                            this.pageNum = 0
                        }
                    }
                }
            },
            check(){
                let rtn = true;
                this.pageConfig.items.forEach((it)=>{
                    if(it.opts.require && _.isEmpty(it.opts.answer)){
                        rtn = false;
                        this.$Message.warning({ content: `第${it.opts.seq}题必答，请答完题再提交`, duration: 3 })
                    }
                })
                return rtn
            }
        },
        beforeDestroy() {
            Bus.$off('PaginationEvent',this.pageEventHandle)
        }
    }
</script>

<style lang="less" scoped>
    .mask-layer{
        height: 100%;
        width: calc(100% - 50px);
        position:absolute;
        top :0px;
        right: 0px;
        background-color: #0C1835;
        opacity:0;
        text-align:center;
        z-index:500;
    }
    .query-answer{
        background-color: #F3F6FA;
        background-image: url(../../../img/bg@2x.jpg);
        background-repeat: repeat-x;
        background-size: 1px 300px;
        overflow-y: auto;
        .tool-bar{
            position: fixed;
            top:0;
            z-index: 1;
            height: 70px;
            width: 100%;
            left: 0;
            background-color: #fff;
            box-shadow: 0px 1px 0px 0px rgba(232,232,232,1);
        }
        .content{
            width: 920px;
            background: url(../../../img/bk@2x.jpg) no-repeat top center;
            background-size: 910px 144px;
            padding-top: 120px;
            margin: 0 auto;
            min-height: 1000px;
            overflow-y: auto;
            .box{
                background: white;
                width: 920px;
                height: 800px;
                margin: 0 auto;
                box-shadow: 0px 1px 6px 0px rgba(205,220,245,1);
                overflow-y: auto;
                .page{
                    min-height: 600px;
                    .header-title{
                        width: 100%;
                        height: 100%;
                        margin-top: 30px;
                        .t-name{
                            text-align: center;
                            font-size: 24px;
                            font-weight: bold;
                            vertical-align: middle;
                            padding: 20px 0;
                            line-height: 30px;
                        }
                        .t-des{
                            height: 100%;
                            color: #555555;
                            text-align: left;
                            font-size: 14px;
                            padding: 0px 150px;
                            border: 0;
                            word-wrap: break-word;
                        }
                    }
                    .item-list{
                        width: 100%;
                        padding: 0px 49px;
                    }
                }
            }
            .footer-btn{
                width: 100%;
                height: 100px;
                text-align: center;
            }
        }
    }
</style>
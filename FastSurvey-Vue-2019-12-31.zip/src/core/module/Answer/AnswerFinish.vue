<template>
    <div class="answer-finish">
        <div class="content">
            <div class="box" >
                <div class="page">
                    您的答卷已经提交，感谢您的参与！
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "AnswerFinish"
    }
</script>

<style lang="less" scoped>
    @media screen and (min-width :768px){
        .answer-finish{
            background-color: #F3F6FA;
            background-image: url(../../../img/bg@2x.jpg);
            background-repeat: repeat-x;
            background-size: 1px 300px;
            .tool-bar{
                position: fixed;
                top:0;
                z-index: 1;
                height: 70px;
                width: 100%;
                left: 0;
                background-color: #fff;
                box-shadow: 0px 1px 0px 0px rgba(232,232,232,1);
            }
            .content{
                width: 920px;
                background: url(../../../img/bk@2x.jpg) no-repeat top center;
                background-size: 910px 144px;
                padding-top: 85px;
                margin: 0 auto;
                min-height: 1000px;
                overflow-y: auto;
                .box{
                    background: white;
                    width: 920px;
                    height: 350px;
                    margin: 0 auto;
                    box-shadow: 0px 1px 6px 0px rgba(205,220,245,1);
                    overflow-y: auto;
                    .page{
                        margin-top: 150px;
                        text-align: center;
                        font-weight: bold;
                        font-size: 16px;
                    }
                }
                .footer-btn{
                    width: 100%;
                    height: 100px;
                    text-align: center;
                }
            }
        }
    }
    @media screen and (max-width :768px){
        .answer-finish{
            background-color: #F3F6FA;
            background-image: url(../../../img/bg@2x.jpg);
            background-repeat: repeat-x;
            background-size: 1px 300px;
            .tool-bar{
                position: fixed;
                top:0;
                z-index: 1;
                height: 70px;
                width: 100%;
                left: 0;
                background-color: #fff;
                box-shadow: 0px 1px 0px 0px rgba(232,232,232,1);
            }
            .content{
                width: 380px;
                background: url(../../../img/bk@2x.jpg) no-repeat top center;
                background-size: 300px 144px;
                padding-top: 85px;
                margin: 0 auto;
                min-height: 1000px;
                overflow-y: auto;
                .box{
                    background: white;
                    width: 300px;
                    height: 250px;
                    margin: 0 auto;
                    box-shadow: 0px 1px 6px 0px rgba(205,220,245,1);
                    overflow-y: auto;
                    .page{
                        margin-top: 100px;
                        text-align: center;
                        font-weight: bold;
                        font-size: 16px;
                    }
                }
            }
        }
    }
</style>
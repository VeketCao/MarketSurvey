<template>
    <div class="answer-mobile" :style="pageHeight">
        <div class="box" :style="pageHeight" ref="wrapper">
            <div class="content">
                <div class="page" v-if="pageConfig">
                    <div class="header-title">
                        <div class="t-name">{{pageConfig.title || ''}}</div>
                        <div class="t-des">{{pageConfig.desc || ''}}</div>
                    </div>
                    <div class="item-list">
                        <template v-for="(it,index) in pageConfigPage.items">
                            <component :is="it.name" :data="it" :key="it.key" mode="edit"></component>
                        </template>
                    </div>
                </div>
                <div class="footer-btn" v-if="pageConfig">
                    <Button type="primary"  @click="commitHandle" :loading="loading">提交</Button>
                </div>
            </div>
        </div>
        <Modal title="答题提示" v-model="authModal" class-name="vertical-center-modal" :closable="false" :mask-closable="false" :footer-hide="true">
            <template v-if="setting.isTimeSet  && authMsg!==''">
                <p>{{authMsg}}</p>
            </template>
            <template v-if="setting.isPassSet && setting.passType ==='singlePass' && authMsg===''">
                <Row style="margin: 15px 100px">
                    <Col span="24"><Input type="password" v-model="pass" placeholder="请输入答题密码"></Input></Col>
                </Row>
                <Row style="margin: 25px 100px">
                    <Col span="12"><Button type="primary" @click="singlePassValid">验证</Button></Col>
                </Row>
            </template>
            <template v-if="setting.isPassSet && setting.passType ==='phonePass' && authMsg===''">
                <div>
                    <Row style="margin: 15px 100px">
                        <Col span="24"><Input v-model="phoneNum" placeholder="手机号" size="large"></Input></Col>
                    </Row>
                    <Row style="margin: 25px 100px">
                        <Col span="24">
                            <Input v-model="shortCode" placeholder="手机验证码" size="large"></Input>
                            <Button size="small" style="position: absolute;left: 160px;top:5px" :disabled="disableBtn"  @click="getPhoneCodeClick">{{codeBtnSp}}</Button>
                        </Col>
                    </Row>
                    <Row style="margin: 25px 100px">
                        <Col span="12"><Button type="primary" @click="phonePassValid">验证</Button></Col>
                    </Row>
                </div>
            </template>
        </Modal>
        <Modal v-model="showYzmBox" class-name="vertical-center-modal dtyz-box" title="机器验证"  width="350px" :footer-hide="true">
            <template v-if="showYzmBox">
                <h2 class="yzm-header">机器验证</h2>
                <div class="yzm-img"><img style="height: 60px;cursor: pointer" :src="imgSrc" @click="getCaptcha"></div>
                <div class="yzm-ipt">
                    <Input v-model="imgCode" placeholder="请输入上方验证码" style="width: 200px" @on-change="imgCodeChange"></Input>
                </div>
                <div class="yzm-btn">
                    <Button @click="imgValidHandle" :disabled="imgYzmBtnDis">验证</Button>
                </div>
            </template>
        </Modal>
    </div>
</template>

<script>
    import BScroll from 'better-scroll'
    import api from '@/api/main'
    import SettingValidMixin from "../Mixin/SettingValidMixin";
    export default {
        name: "Answer",
        mixins:[
            SettingValidMixin
        ],
        data(){
            return{
                pageNum:0,
                curIndex:0,
                loading:false,
                pageConfig:null,
                pageConfigPage:null,
                city: '',
                scroll: null
            }
        },
        computed: {
            pageHeight () {
                let height = this.height;
                let clientWidth = document.documentElement.clientHeight;
                height = clientWidth + 'px';
                return {
                    height: height
                }
            },
        },
        mounted() {
            Bus.$on('PaginationEvent',this.pageEventHandle)
            if(this.$route.query.id){
                api.queryAnswerSurvey({surveyId:this.$route.query.id}).then((rtn)=>{
                    if(rtn.code===0){
                        this.pageConfig =  JSON.parse(rtn.data)
                        this.buildPageConfigPage()
                    }else{
                        window.sessionStorage.setItem('errorMsg', rtn.msg)
                        this.$router.push('/error')
                        //this.$Message.warning({ content: rtn.msg, duration: 3 })
                    }
                })
            }

            this.$nextTick(() => {
                //$refs绑定元素
                if(!this.scroll){
                    this.scroll = new BScroll(this.$refs.wrapper, {
                        //开启点击事件 默认为false
                        click:true
                    })
                    // console.log(this.scroll)
                }else if(!this.$refs.wrapper){
                    return
                }
                else{
                    this.scroll.refresh()
                }
            })

            this.getAddressInfo()
        },
        methods:{
            pageEventHandle(num){
                this.pageConfigPage.items = []
                for(let j=this.curIndex;j<this.pageConfig.items.length;j++){
                    if(!(j==this.pageConfig.items.length-1 && this.pageConfig.items[j].name=='Pagination')){
                        this.pageConfigPage.items.push(this.pageConfig.items[j])
                        this.curIndex = j+1;
                        if(this.pageConfig.items[j].name=='Pagination'){
                            this.pageNum = this.pageConfig.items[j].opts.pageNum
                            break
                        }else {
                            this.pageNum = 0
                        }
                    }
                }

            },
            buildPageConfigPage(){
                this.pageConfigPage={
                    items:[],
                    opts:this.pageConfig.opts
                };
                for(let i=0;i<this.pageConfig.items.length;i++){
                    if(!((i==0||i==this.pageConfig.items.length-1) && this.pageConfig.items[i].name=='Pagination')){
                        this.pageConfigPage.items.push(this.pageConfig.items[i])
                        this.curIndex = i+1;
                        if(this.pageConfig.items[i].name=='Pagination'){
                            this.pageNum = this.pageConfig.items[i].opts.pageNum
                            break
                        }else {
                            this.pageNum = 0
                        }
                    }
                }
            },
            isPoneAvailable(tNum, tel) {
                var myreg = /^[1][3,4,5,6,7,8,9][0-9]{9}$/;
                if (!myreg.test(tel)) {
                    //this.$Message.warning({ content: `第${tNum}题，手机号码格式不对`, duration: 3 })
                    return false;
                } else {
                    return true;
                }
            },
            isEmailAvailable(tNum, email) {
                var myreg = /^[A-Za-z0-9]+([_\.][A-Za-z0-9]+)*@([A-Za-z0-9\-]+\.)+[A-Za-z]{2,6}$/;
                if (!myreg.test(email)) {
                    //this.$Message.warning({ content: `第${tNum}题，邮箱格式不对`, duration: 3 })
                    return false;
                } else {
                    return true;
                }
            },
//            check(){
//                let rtn = true;
//                console.log(this.pageConfig)
//                this.pageConfig.items.forEach((it)=>{
//                    if(it.opts.require && _.isEmpty(it.opts.answer)){
//                        rtn = false;
//                        this.$Message.warning({ content: `第${it.opts.tNum}题必答，请答完题再提交`, duration: 3 })
//                    }
//                    if(it.opts.type === 'tel' && it.opts.answer) {
//                        rtn = this.isPoneAvailable(it.opts.tNum, it.opts.answer)
//                    }
//                    if(it.opts.type === 'email' && it.opts.answer) {
//                        rtn = this.isEmailAvailable(it.opts.tNum, it.opts.answer)
//                    }
//                })
//                return rtn
//            },
            check(){
                let rtn = true;

                this.pageConfig.items.forEach((it, index)=>{
                    //it.opts.errorFlag = false
                    //it.opts.errorMsg = ''
                    it.isAnswer = true
                    if(it.opts.require && _.isEmpty(it.opts.answer)){
                        this.$set(it, 'errorFlag', true)
                        this.$set(it, 'errorMsg', '')
                        rtn = false;
                        //this.$Message.warning({ content: `第${it.opts.tNum}题必答，请答完题再提交`, duration: 3 })
                    }
//                    console.log(it, index)
//                    if(it.opts.require && it.opts.answer&&it.opts.answer.length === 0){
//                        this.$set(it, 'errorFlag', true)
//                        this.$set(it, 'errorMsg', '')
//                        rtn = false;
//                        //this.$Message.warning({ content: `第${it.opts.tNum}题必答，请答完题再提交`, duration: 3 })
//                    }
                    if(it.opts.type === 'tel' && it.opts.answer) {
                        if(!this.isPoneAvailable(it.opts.tNum, it.opts.answer)) {
                            this.$set(it, 'errorFlag', true)
                            this.$set(it, 'errorMsg', '手机号码格式不对')
                            rtn = false;
                        }
                    }
                    if(it.opts.type === 'email' && it.opts.answer) {
                        if(!this.isEmailAvailable(it.opts.tNum, it.opts.answer)) {
                            this.$set(it, 'errorFlag', true)
                            this.$set(it, 'errorMsg', '邮箱格式不对')
                            rtn = false;
                        }
                    }
                })
                return rtn
            },
            getOS() {
                var os;
                if (navigator.userAgent.indexOf('Android') > -1 || navigator.userAgent.indexOf('Linux') > -1) {
                    os = 'Android';
                } else if (navigator.userAgent.indexOf('iPhone') > -1||navigator.userAgent.indexOf('iPad') > -1) {
                    os = 'iOS';
                } else if (navigator.userAgent.indexOf('Windows Phone') > -1) {
                    os = 'WP';
                } else {
                    os = 'Others';
                }
                return os;
            },
            getInfoByCoordinate(point, callback) {
                const baiduMapAk='WwRWeUUKOpxuf4kn34xBtkdyPFPrNRpn'
                window.getLocationInfoCallback = (res) => {
                    callback(res)
                }
                if (document.getElementById('baidu') !== null) {
                    document.body.removeChild(document.getElementById('baidu'))
                }
                let script = document.createElement('script')
                script.id = 'baidu'
                script.src = `http://api.map.baidu.com/geocoder/v2/?callback=getLocationInfoCallback&location=${point.lat},${point.lng}&output=json&pois=1&ak=${baiduMapAk}`
                document.body.appendChild(script)
            },
            getAddressInfo() {
                var geoHandler = function(position)
                {
                    var geoMsg = "用户的所在的地理位置信息是：<br/>";
                    geoMsg += "timestamp属性为：" + position.timestamp + "<br/>";
                    // 获取Coordinates对象，该对象里包含了详细的地理位置信息
                    var coords = position.coords;
                    // 遍历Coordinates对象的所有属性
                    for(var prop in coords)
                    {
                        geoMsg += prop + "-->" + coords[prop] + "<br/>";
                    }
                    // 输出地理位置信息
                    console.log(geoMsg);
                    this.city = geoMsg
                }
                var errorHandler = function(error)
                {
                    // 为不同错误代码定义错误提示
                    var errMsg = {
                        1: '用户拒绝了位置服务',
                        2: '无法获取地址位置信息',
                        3: '获取地理位置信息超时'
                    };
                    // 弹出错误提示
                    //alert(errMsg[error.code]);
                }
                // 获取地理位置信息
                navigator.geolocation.getCurrentPosition(geoHandler
                    , errorHandler
                    , {
                        enableHighAccuracy:true,
                        maximumAge:1000
                    });
            },
            commitHandle(){
                console.log(JSON.stringify(this.pageConfig))
                if(!this.check()) return;
                this.loading = true;
                this.pageConfig.unitType = this.getOS();
                this.pageConfig.devieInfo = navigator.userAgent;
                this.pageConfig.city = this.city;
                this.pageConfig.answerPhone = sessionStorage.getItem('answerPhone');
                api.saveSurveyAnswer(this.pageConfig).then((rtn)=>{
                    this.loading = false;
                    if(rtn.code==0){
                        this.$Message.success({ content: '提交成功', duration: 3 })
                        this.$router.push('/finish')
                    }else{
                        this.$Message.error({ content: rtn.msg, duration: 3 })
                    }
                })
            }
        },
        beforeDestroy() {
            Bus.$off('PaginationEvent',this.pageEventHandle)
        }
    }
</script>

<style lang="less">
    .answer-mobile{
        width: 100%;
        height: 100%;
        .box{
            background: white;
            width: 100%;
            height: 100%;
            overflow-y: auto;
            -webkit-webkit-overflow-scrolling: touch;
            -moz-webkit-overflow-scrolling: touch;
            -ms-webkit-overflow-scrolling: touch;
            -o-webkit-overflow-scrolling: touch;
            -khtml-webkit-overflow-scrolling: touch;
            webkit-overflow-scrolling: touch;
            .page{
                //min-height: 600px;
                .header-title{
                    width: 100%;
                    //height: 100px;
                    .t-name{
                        text-align: center;
                        font-size: 24px;
                        font-weight: bold;
                        vertical-align: middle;
                        padding: 15px 0;
                        line-height: 30px;
                        color: #1ea0fa;
                    }
                    .t-des{
                        color: #555555;
                        text-align: left;
                        font-size: 14px;
                        padding: 0px 15px;
                        border: 0;
                    }
                }
                .item-list{
                    width: 100%;
                    padding: 5px 15px;
                }
                .t-header {
                    font-size: 16px !important;
                    font-weight: bold !important;
                }
                .ivu-radio-wrapper, .ivu-checkbox-wrapper, .ivu-input, .f-sp, .f-blank, .ivu-select-selected-value, .ivu-select-item, .name-sp{
                    font-size: 16px !important;
                }
            }
            .footer-btn{
                width: 100%;
                height: 100px;
                text-align: center;
                button {
                    width: 90%;
                }
            }
        }
    }
</style>
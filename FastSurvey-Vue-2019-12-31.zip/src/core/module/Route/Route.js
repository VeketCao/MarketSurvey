/**
 * Created by Veket on 2019/10/6.
 */
import VueRouter from 'vue-router';

import Home from '../Home/Home'
import Mine from "../Home/Mine/Mine";
import Login from '../Login/Login';
import Register from "../Register/Register";
import Designer from '../Designer/Designer.vue';
import Preview from '../Preview/Preview.vue';
import Answer from '../Answer/Answer.vue';
import BuildLink from '../BuildLink/BuildLink';
import Analysis from "../Analysis/Analysis";
import ResetPassword from "../ResetPassword/ResetPassword";
import QueryAnswer from "../Answer/QueryAnswer";
import RecoveryData from "../Home/RecoveryData/RecoveryData";
import AnswerFinish from "../Answer/AnswerFinish";
import Setting from "../Home/Setting/Setting";
import Vote from '../Vote/Vote.vue'

Vue.use(VueRouter);

const routesMap = [
    {
        path: '/',redirect:'/home',
    },
    {
        path:'/home',
        name:'home',
        redirect:'/home/mine',
        component:Home,
        children:[{
                path:'/home/mine',
                name:'mine',
                component:Mine
            },
            {
                path:'/home/analysis',
                name:'analysis',
                component:Analysis
            },
            {
                path:'/home/recovery_data',
                name:'recoveryData',
                component:RecoveryData
            },
            {
                path:'/home/setting',
                name:'setting',
                component:Setting
            },
            {
                path:'/home/vote',
                name:'vote',
                component: Vote,
            },
        ]
    },
    {
        path:'/designer',
        name:'designer',
        component: Designer,
    },
    {
        path:'/login',
        name:'login',
        component:Login
    },
    {
        path:'/register',
        name:'register',
        component: Register
    },
    {
        path:'/reset',
        name:'reset',
        component: ResetPassword
    },
    {
        path:'/p',
        name:'preview',
        component: Preview,
    },
    {
        path:'/answer',
        name:'answer',
        component: Answer,
    },
    {
        path:'/link',
        name:'buildLink',
        component:BuildLink
    },
    {
        path:'/queryAnswer',
        name:'queryAnswer',
        component:QueryAnswer
    },
    {
        path:'/finish',
        name:'answerFinish',
        component:AnswerFinish
    }

];

const router = new VueRouter({
    mode: 'hash',
    base: __dirname,
    routes: routesMap
});

/*router.beforeEach((to, from, next) => {
    let userInfo=AppUtil.getCookie('user_info');
    if(_.isEmpty(userInfo)){
        window.location.href = 'main.html#/login'
    }
    next()
});*/

export default router
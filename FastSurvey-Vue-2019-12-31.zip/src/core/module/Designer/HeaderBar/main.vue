<template>
    <header class="header">
        <a class="logo fl">
            <img src="../../../../img/logo.png" class="img-logo">
            <span class="sp-logo">Fast问卷</span>
        </a>
        <div class="tool-btn fr">
            <!--<Button size="small" @click="downSampleHandle" style="margin-right: 10px">导入样例</Button>-->
            <Dropdown @on-click="clickImportHandle" style="margin-right: 15px">
                <span style="color: #fff" >
                    导入样例
                    <Icon type="ios-arrow-down"></Icon>
                </span>
                <DropdownMenu slot="list">
                    <DropdownItem name="look">查看导入样例</DropdownItem>
                    <DropdownItem name="down">下载导入样例</DropdownItem>
                </DropdownMenu>
            </Dropdown>
            <Button size="small" @click="importHandle" style="margin-right: 10px">导入</Button>
            <Button size="small" @click="exportHandle" style="margin-right: 10px">导出</Button>
            <Button size="small" @click="previewHandle" style="margin-right: 10px">预览</Button>
            <Button size="small" type="primary" @click="$router.push('/home/mine')" >完成编辑</Button>
            <div class="user-info fr">
                <div class="user-img" v-clickoutside="closeDropBox">
                    <img :src="userImg" class="user-avatar" @click="showDropBox">
                    <div class="drop-info" v-if="showDrop">
                        <Row class="row-item">
                            <Col span="10">用户名:</Col>
                            <Col span="12">{{username}}</Col>
                        </Row>
                        <Row class="row-item">
                            <Col span="10">账号ID:</Col>
                            <Col span="12">{{userId}}</Col>
                        </Row>
                        <Row class="row-item">
                            <Col span="10">手机号:</Col>
                            <Col span="12">{{mobile}}</Col>
                        </Row>
                        <Row class="row-item">
                            <Col span="10">邮箱地址:</Col>
                            <Col span="12">{{email}}</Col>
                        </Row>
                        <Row class="row-item">
                            <Col span="10">微信：</Col>
                            <Col span="12">{{wx}}</Col>
                        </Row>
                    </div>
                </div>
                <Dropdown style="margin: 8px 0px 0px 3px" trigger="click" @on-click="clickHandle">
                <span class="user-sp" >
                    {{username}}
                    <Icon type="ios-arrow-down"></Icon>
                </span>
                    <DropdownMenu slot="list">
                        <DropdownItem name="logout">退出</DropdownItem>
                    </DropdownMenu>
                </Dropdown>
            </div>
        </div>
        <Modal v-model="importModal" style="">
            <p slot="header" style="color:#6063A8;font-size:15px;">
                <span>导入问卷</span>
            </p>
            <div class="view-content import-staff" >
                <div class="upload-assembly" >
                    <div class="upload-flex">
                        <div class="upload-flex-item">
                            <Upload type="drag" ref="upload" class="drag-upload" :action="uploadUrl" :format="format" :on-format-error="formatError"
                                    :show-upload-list="false" :on-success="uploadSuccess" :data="params" :before-upload="handleBeforeUpload">
                                <div style="padding: 35px 0">
                                    <Icon type="ios-cloud-upload" size="52"></Icon>
                                    <p class="upload-txt">点击或将文件拖拽到此处上传</p>
                                </div>
                            </Upload>
                        </div>
                    </div>
                </div>
            </div>
        </Modal>
        <Modal v-model="sampleModal" class-name="vertical-center-modal" width="650px" :footer-hide="true">
            <template v-if="sampleModal">
                <Input v-model="sampleValue" type="textarea" :rows="30" readonly></Input>
            </template>
        </Modal>
    </header>
</template>

<script>
    import api from '@/api/main'
    export default {
        name: "DesignerHeaderBar",
        props:['data'],
        data(){
          return{
              sampleModal:false,
              loading:false,
              params:{},
              uploadUrl:`${api.getBaseURl()}surveyMain/import`,
              importModal:false,
              format: ['txt'],
              sampleValue:'',
              username:'',
              userImg:'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif?imageView2/1/w/80/h/80',
              userId:'',
              showDrop:false,
              mobile:'',
              email:'',
              wx:''
          }
        },
        mounted(){
            api.getUserInfo().then((rtn)=>{
                console.log('getUserInfo',rtn)
                if(rtn.code===0){
                    this.username = rtn.data.name
                    this.userId = rtn.data.userId
                    this.mobile = rtn.data.mobile || ''
                    this.email = rtn.data.email || ''
                    this.wx = rtn.data.wechatUuid || ''

                    if(!_.isEmpty( rtn.data.picture)){
                        this.userImg = rtn.data.picture
                    }
                }
            })
        },
        directives: {
            clickoutside: {//点击下拉框外的其它区域时关闭下拉框
                bind(el, binding, vnode) {
                    function documentHandler(e) {
                        if (el.contains(e.target)) {
                            return false
                        }
                        if (binding.expression) {
                            binding.value(e)
                        }
                    }
                    function KeyUp(e) {
                        if (e.keyCode === 27) {
                            if (binding.expression) {
                                binding.value(e)
                            }
                        }
                    }
                    el.__vueClickOutSize__ = documentHandler
                    el.__vueKeyup__ = KeyUp
                    document.addEventListener('keyup', KeyUp)
                    document.addEventListener('click', documentHandler)
                },
                unbind(el, binding) {
                    document.removeEventListener('click', el.__vueClickOutSize__)
                    delete el.__vueClickOutSize__
                    document.removeEventListener('keyup', el.__vueKeyup__)
                    delete el.__vueKeyup__
                }
            }
        },
        methods:{
            showDropBox(){
                this.showDrop = !this.showDrop
            },
            closeDropBox(){
                this.showDrop = false
            },
            clickHandle(name){
                if(name=='logout'){
                    api.logout().then((rtn)=>{
                        window.location.href = './main.html#/login'
                    })
                }
            },
            clickImportHandle(name){
                if(name=='look'){
                    this.sampleModal = true
                    api.getImportExport().then((rtn)=>{
                        if(rtn.code===0){
                            this.sampleValue = rtn.data
                        }else {
                            this.$Message.warning({ content: rtn.msg, duration: 3 })
                        }
                    })
                }else if(name=='down'){
                    let eleLink = document.createElement('a');
                    eleLink.download = '导入样例';
                    eleLink.style.display = 'none';
                    eleLink.href = `${api.getBaseURl()}surveyMain/exportImportExample`;
                    document.body.appendChild(eleLink);
                    eleLink.click();
                    document.body.removeChild(eleLink);
                }
            },
            formatError() {
                this.$Message.warning({ content: '请上传.txt格式', duration: 3 })
            },
            previewHandle(){
                localStorage.setItem('pageConfig',JSON.stringify(this.data))
                window.open('main.html#/p')
            },
            importHandle(){
                this.importModal = true
                this.params={surveyId:this.$route.query.id}
            },
            uploadSuccess(res) {
                if (res.code === 0) {
                    this.importModal = false
                    window.location.reload()
                } else {
                    this.$Message.warning({ content: res.msg, duration: 3 })
                }
            },
            handleBeforeUpload: function () {
                //this.spinShow = true
            },
            exportHandle(){
                let eleLink = document.createElement('a');
                eleLink.download = '导出';
                eleLink.style.display = 'none';
                eleLink.href = `${window.location.origin}/fastSurvey/surveyMain/export2text?surveyId=${this.$route.query.id}`;
                document.body.appendChild(eleLink);
                eleLink.click();
                document.body.removeChild(eleLink);
                //window.open(`${window.location.origin}/fastSurvey/surveyMain/export2text?surveyId=${this.$route.query.id}`)
            }
        }
    }
</script>

<style scoped lang="less">
    .header {
        position: fixed;
        z-index: 203;
        top: 0;
        left: 0;
        width: 100%;
        min-width: 600px;
        height: 68px;
        background-color: #222d32;
        .logo{
            margin: 10px 45px;
            .img-logo{
                width: 30px;
                height: 48px;
            }
            .sp-logo{
                position: absolute;
                top:35px;
                left: 73px;
                color: #fff;
                font-size: 16px;
            }
        }
        .tool-btn {
            margin: 24px 35px 0 0;
            .btn {
                display: inline-block;
                height: 24px;
                line-height: 24px;
                padding: 0 12px;
                border-radius: 2px;
                font-size: 14px;
                cursor: pointer;
            }

            .btn-blue {
                border: 1px solid transparent;
                background-color: #0090ff;
                color: #fff;
            }

            .btn-white {
                margin-left: 5px;
                border: 1px solid #bababa;
                background-color: #fff;
            }

            .btn-blue span, .btn-white span {
                height: 24px;
                line-height: 24px;
            }

            .btn-blue:hover, .btn-blue:focus, .btn-white:hover, .btn-white:focus {
                text-decoration: none;
                outline: none;
            }
            .user-info{
                position: relative;
                z-index: 201;
                margin: -8px 0px 0px 15px;
                .user-img{
                    float: left;
                    .user-avatar{
                        width: 40px;
                        height: 40px;
                        border-radius: 50%;
                        cursor: pointer;
                    }
                    @keyframes dropBoxH {
                        from{height: 0px;}
                        to{height: 110px;}
                    }
                    .drop-info{
                        position:absolute;
                        left: -70px;
                        background: #fff;
                        width: 170px;
                        padding: 5px;
                        border-radius: 5px;
                        border: 1px solid #eee;
                        z-index: 1000;
                        overflow: hidden;
                        animation: dropBoxH 0.5s;
                        animation-fill-mode:forwards;
                        .row-item{
                            margin-left: 10px
                        }
                    }
                }
                .user-sp{
                    color: #fff;
                    margin: 8px 0px 0px 3px;
                    font-size: 14px;
                }
            }
        }

    }

</style>
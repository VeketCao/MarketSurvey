<template>
    <div class="page-item-view "
         v-if="element && element.key"
         :class="{active:curSelect.key==element.key}"
         @mouseenter="handleClick(index)"
    >
        <component :is="element.name" :data="element" mode="designer"></component>
        <div class="mask-layer" @click="selectItemClickHandle"></div>
        <div class="tool-bar">
            <div class="delete-btn">
                <a @click="deleteHandle(index)" title="删除"><Icon type="ios-trash-outline" size="25" /></a>
            </div>
            <div class="delete-btn" v-if="element.name !== 'SectionDesc'&&element.name !== 'Pagination'">
                <a @click="saveBank(index)" title="收藏"><Icon type="ios-heart-outline" size="25" /></a>
            </div>
        </div>
    </div>
</template>

<script>
    import api from '@/api/main'
    export default {
        name: "PageItem",
        props:['element','select','index','data'],
        data(){
            return{
                curSelect:this.select,
            }
        },
        mounted(){
        },
        methods:{
            selectItemClickHandle(){
                Bus.$emit('selectItemClick');
            },
            handleClick(){
                this.curSelect = this.data.items[this.index];
            },
            deleteHandle(index){
                if (this.data.items.length - 1 === index) {
                    if (index === 0) {
                        this.curSelect = {}
                    } else {
                        this.curSelect = this.data.items[index - 1]
                    }
                } else {
                    this.curSelect = this.data.items[index + 1]
                }

                this.$nextTick(() => {
                    api.deleteQuestion({questionId:this.data.items[index].key}).then((rtn)=>{ console.log(rtn) })
                    this.data.items.splice(index, 1)
                    let i=0;
                    let j=0;
                    let k=0;
                    this.data.items.forEach((it) => {
                        it.opts.seq = i++;
                        if(it.name != 'SectionDesc' && it.name != 'Pagination') it.opts.tNum = ++j
                        if(it.name == 'Pagination') it.opts.pageNum = ++k;
                    })
                })
            },
            saveBank(index) {
//                if (this.data.items.length - 1 === index) {
//                    if (index === 0) {
//                        this.curSelect = {}
//                    } else {
//                        this.curSelect = this.data.items[index - 1]
//                    }
//                } else {
//                    this.curSelect = this.data.items[index + 1]
//                }

                this.$nextTick(() => {
                    api.saveQuestionBank({questionId:this.data.items[index].key}).then((rtn)=>{
                        console.log(rtn)
                        if(rtn.code === 0) {
                            this.$parent.$parent.$parent.getQuestionBankList()
                            this.$Message.success({ content: '收藏成功', duration: 3, onClose: () => {} })
                        }
                    })
                })
            }
        },
        watch: {
            select (val) {
                this.curSelect = val
            },
            curSelect: {
                handler (val) {
                    this.$emit('update:select', val)
                },
                deep: true
            }
        }

    }
</script>

<style scoped lang="less">
    .mask-layer{
        height: 100%;
        width: calc(100% - 50px);
        position:absolute;
        top :0px;
        right: 0px;
        background-color: #0C1835;
        opacity:0;
        text-align:center;
        z-index:500;
    }
    .page-item-view{
        position: relative;
        //border: 1px dashed #999;
        /*background-color: rgba(236,245,255,.3);*/
        min-height: 50px;
        &.ghost{
            list-style: none;
            font-size: 0;
            display: block;
            position: relative;
            border: 2px solid red!important;
            width: 100%;
            height: 1px!important;
            min-height: 1px!important;
        }
        &.active{
            border: 2px solid #409eff;
           /* background-color: #b3d8ff;*/
            .tool-bar{
                display: block;
                position: absolute;
                width: 20px;
                /*top:0;*/
                left: 0;
                bottom: 0;
                /*background-color: #F4F6FC;*/
                .delete-btn{
                    position: relative;
                    float: left;
                    margin: 5px 0;
                    /*background-color: #409eff;*/
                    a{
                        padding: 0px 5px;
                        cursor: pointer;
                        i:hover {
                            color: #fff;
                            background: #409eff;
                        }
                    }
                }
            }
        }
        &:after{
            position: absolute;
            left: 0;
            right: 0;
            bottom: 0;
            top: 0;
            display: block;
            z-index: 1001;
        }

        &:hover{
            background: #ecf5ff;
            //border-left: 1px solid #ecf5ff;
        }

        &.active{
            //border-left: 1px solid #409EFF;
           /* background: #b3d8ff;*/
        }
        .tool-bar{
            display: none;
        }
    }

</style>
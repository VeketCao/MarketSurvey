<template>
    <div class="mid-page-container">
        <div class="page" ref="page">
            <div class="header-title">
                <div class="t-name">
                    <input placeholder="请输入问卷标题" v-model="data.title" style="width: 800px;text-align:center;font-size: 24px; line-height: 70px;height: 70px;font-weight: bold;" @change="changeHandle"></input>
                </div>
                <div class="t-des">
                    <textarea placeholder="请输入问卷描述" v-model="data.desc" style="width: 100%;border: 1px solid #fff;resize:none;word-wrap:break-word;font-size: 14px;color: #555555;" @change="changeHandle"></textarea>
                </div>
            </div>
            <draggable class="page-list"
                       :style="dyHeight"
                       v-model="data.items"
                       v-bind="{group:'g', ghostClass: 'ghost'}"
                       @end="refreshSeqAndTNumAfter"
                       @add="handleWidgetAdd">
                <template v-for="(it,index) in data.items">
                    <pageItem v-if="it" :key="it.key" :element="it" :index="index" :data="data" :select.sync="curSelect"></pageItem>
                </template>
            </draggable>
        </div>
    </div>
</template>

<script>
    import Draggable from 'vuedraggable'
    import PageItem from './PageItem/main'
    import api from '@/api/main'

    export default {
        name: "MidPage",
        props:['data','select','addItemAfter'],
        data(){
            return{
                curSelect: this.select,
                dyHeight:`height: calc(100% + 2000px)`,
            }
        },
        mounted(){
            Bus.$on('addItemClick', this.addItemClick);
            Bus.$on('queryPositionClick', this.dingWei);
            this.refreshHeight()
        },
        updated(){
            this.refreshHeight()
        },
        methods:{
            dingWei(seq){
                this.curSelect = this.data.items[seq];
                let itemViews = document.getElementsByClassName('page-item-view');
                let height = -330;
                for(let i=0;i<=seq;i++){
                    height+=itemViews[i].clientHeight
                }
                this.$refs.page.scrollTop=height;
            },
            changeHandle(){
                api.saveSurvey(this.data).then((rtn)=>{ console.log(rtn) })
            },
            refreshHeight(){
                if(this.data.items.length>6){
                    this.dyHeight = `height: calc(100% + ${this.data.items.length*250}px)`
                }
            },
            refreshSeqAndTNum(){
                let i=0;
                let j=0;
                let k=0;
                this.data.items.forEach((it) => {
                    it.opts.seq = i++;
                    if(it.name != 'SectionDesc' && it.name != 'Pagination') it.opts.tNum = ++j
                    if(it.name == 'Pagination') it.opts.pageNum = ++k;
                })
                this.refreshHeight()  
            },
            refreshSeqAndTNumAfter(){
                this.refreshSeqAndTNum()
                Bus.$emit('refreshSeqAfter');
            },
            refreshListIndex(it){//实例化后保证index唯一
                if(it.opts.list){
                    it.opts.list.forEach((item)=>{
                        item.index = AppUtil.getUUID();
                    })
                }
                if(it.opts.row){
                    it.opts.row.forEach((item)=>{
                        item.index = AppUtil.getUUID();
                    })
                }
                if(it.opts.col){
                    it.opts.col.forEach((item)=>{
                        item.index = AppUtil.getUUID();
                    })
                }
            },
            addItem(newIndex,it){
                const key = AppUtil.getUUID();
                let tempIt = JSON.parse(JSON.stringify(it));
                this.refreshListIndex(tempIt)
                this.$set(this.data.items,newIndex,{
                    ...tempIt,
                    key,
                })
                this.curSelect = this.data.items[newIndex];
                this.refreshSeqAndTNum()
                this.addItemAfter(newIndex)
            },
            addItemClick(it){
                const newIndex = this.data.items.length
                this.addItem(newIndex,it)
            },
            handleWidgetAdd(e){//添加实例化后id
                const newIndex = e.newIndex
                this.addItem(newIndex,this.data.items[newIndex])
            }
        },
        components:{
            Draggable,
            PageItem,
        },
        watch: {
            select (val) {
                this.curSelect = val
            },
            curSelect: {
                handler (val) {
                    this.$emit('update:select', val)
                },
                deep: true
            }
        },
        beforeDestroy() {
            Bus.$off('addItem', this.addItemClick);
            Bus.$off('queryPositionClick', this.dingWei);
        }
    }
</script>
<style scoped lang="less">
    .mid-page-container{
        //position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        //height: 100%;
        background-color: #f0f0f0;
        overflow: auto;
        z-index: 100;
        min-width: 760px;
        .page{
            width: 920px;
            max-width: 1200px;
            min-width: 730px;
            background-color: #fff;
            margin: auto;
            height: 100%;
            border: 1px solid #dadada;
            overflow-x: hidden;
            overflow-y: auto;
            &::-webkit-scrollbar {
                width: 0px;
                height: 0px;
            }
            .header-title{
                width: 100%;
                height: 100%;
                max-height: 180px;
                padding: 20px 0px;
                border-bottom: 1px dashed #999;
                .t-name{
                    text-align: center;
                    padding: 10px 0px;
                    input:hover{
                        border: 1px solid #eee;
                    }
                }
                .t-des{
                    text-align: left;
                    padding: 5px 100px;
                    border: 0;
                    height: 100%;
                    textarea:hover{
                        border: 1px solid #eee!important;
                    }
                }
            }
            .page-list{ 
                width: 100%;
                .column-layout-row{
                    position: relative;
                    width: 100%;
                    min-height: 60px;
                    padding: 5px;
                    border: 1px dashed goldenrod;
                    overflow: hidden;
                    .tool-bar{
                        display: none;
                    }
                    &.active{
                        border: 2px solid goldenrod;
                        .tool-bar{
                            display: block;
                            position: absolute;
                            width: 20px;
                            right: 0;
                            bottom: 0;
                            .right-btn{
                                position: relative;
                                float: right;
                                background-color: goldenrod;
                                a{
                                    padding: 0px 5px;
                                    cursor: pointer;
                                }
                            }
                        }
                    }
                    &.ghost{
                        &:after{
                            background: #fff;
                            position: absolute;
                            left: 0;
                            right: 0;
                            bottom: 0;
                            display: block;
                            z-index: 10;
                        }
                    }

                    .column-layout-cell{
                        position: relative;
                        display: inline;
                        border: 1px dashed #999;
                        width: 50%;
                        float: left;
                        &.width3{
                            width: 33.33%!important;
                        }
                        &.width4{
                            width: 25%!important;
                        }
                        .cell-list{
                            z-index: 100001;
                            width: 100%;
                            min-height: 50px;
                        }
                    }

                }
            }

        }
    }

</style>
<template>
    <div class="app-designer">
        <div class="designer-header">
            <header-bar :data="pageConfig"></header-bar>
        </div>
        <div class="designer-left">
            <div style="height: 68px"></div>
            <left-cate :data="pageConfig"></left-cate>
        </div>
        <div class="mid-container">
            <mid-page class="content-area" :data="pageConfig" :select.sync="curSelect" :addItemAfter="addItemAfter"></mid-page>
            <question-bank class="right-bank" :data="questionBankList"></question-bank>
        </div>
        <!--<Drawer title="试题属性配置"
                @on-close="cancelHandle"
                v-model="showOptEditor"
                width="720"
                :mask-closable="maskClosable"
                :styles="styles">
            <item-opts :show="showOptEditor" :data="tempEditorItem" :items="pageConfig.items"></item-opts>
            <div class="opts-drawer-footer">
                <Button style="margin-right: 8px" @click="cancelHandle">取消</Button>
                <Button type="primary" @click="optsEditorOk">确定</Button>
            </div>
        </Drawer>-->
        <div v-if="showOptEditor">
            <div class="mask-layer-t" @click="maskCloseHandle"></div>
            <div class="modal-wrap-self-t">
                <div class="modal-content">
                    <div class="modal-close" @click="cancelHandle">
                        <i class="ivu-icon ivu-icon-ios-close"></i>
                    </div>
                    <div class="modal-header">
                        <p style="color:rgb(96,99,168);font-size:16px;">
                            <span>试题属性配置</span>
                        </p>
                    </div>
                    <div class="modal-body">
                        <item-opts :show="showOptEditor" :data="tempEditorItem" :items="pageConfig.items"></item-opts>
                    </div>
                    <div class="opts-drawer-footer">
                        <Button style="margin-right: 8px" @click="cancelHandle">取消</Button>
                        <Button type="primary" @click="optsEditorOk">确定</Button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import HeaderBar from './HeaderBar/main'
    import LeftCate from './LeftCate/main'
    import MidPage from './MidPage/main'
    import ItemOpts from './ItemOpts/main'
    import PageOpts from './PageOpts/main'
    import QuestionBank from './QuestionBank/main'
    import api from '@/api/main'

    export default {
        name: "Designer",
        data(){
            return{
                pageConfig:{
                    items:[],
                    title:'',
                    desc:'',
                    mode:'designer'
                },
                showOptEditor:false,
                curSelect:{},
                styles: {
                    height: 'calc(100% - 55px)',
                    overflow: 'auto',
                    paddingBottom: '53px',
                    position: 'static'
                },
                tempEditorItem:null,
                newIndex:-1,
                questionBankList: []
            }
        },
        mounted(){
            this.refreshPageHandle();
            this.getQuestionBankList();
            Bus.$on('selectItemClick', this.selectItemClick);
            Bus.$on('refreshSeqAfter', this.refreshSeqAfter);
        },
        methods: {
            maskCloseHandle(){
                if((this.newIndex == -1)&&(JSON.stringify(this.curSelect.opts)==JSON.stringify(this.tempEditorItem.opts))){
                    this.showOptEditor = false
                }
            },
            refreshSeqAfter(){
                api.sortSurvey(this.pageConfig).then((rtn)=>{ console.log(rtn) })
            },
            addItemAfter(newIndex){
                this.newIndex =  newIndex
                this.tempEditorItem = JSON.parse(JSON.stringify(this.pageConfig.items[newIndex]))
                this.showOptEditor = true
            },
            cancelHandle(){
                this.showOptEditor = false
                if(this.newIndex != -1){
                    this.$nextTick(() => {
                        this.pageConfig.items.splice(this.newIndex, 1)
                    })
                }
            },
            optsEditorOk(){
                if(JSON.stringify(this.curSelect.opts)!=JSON.stringify(this.tempEditorItem.opts)){//说明编辑过
                    this.tempEditorItem.opts.isDirty = true
                }else{
                    this.tempEditorItem.opts.isDirty = false
                }
                if(this.newIndex != -1){
                    this.tempEditorItem.opts.isDirty = true
                }
                this.curSelect.opts = this.tempEditorItem.opts
                if(this.tempEditorItem.opts.isDirty){
                    api.saveSurvey(this.pageConfig).then((rtn)=>{ console.log(rtn) })
                }
                this.showOptEditor = false
            },
            selectItemClick(){
                this.newIndex = -1;
                this.tempEditorItem = JSON.parse(JSON.stringify(this.curSelect))
                this.showOptEditor = true
            },
            refreshPageHandle(){
                if(this.$route.query.id){
                    api.querySurvey({surveyId:this.$route.query.id}).then((rtn)=>{
                        this.pageConfig =  JSON.parse(rtn.data)
                    })
                }
            },
            getQuestionBankList() {
                api.queryQuestionBank().then((rtn)=>{
                    console.log(rtn)
                    if(rtn.code === 0) {
                        this.questionBankList = rtn.data
                    }
                })
            }
        },
        components:{
            HeaderBar,
            LeftCate,
            MidPage,
            ItemOpts,
            PageOpts,
            QuestionBank
        },
        beforeDestroy() {
            Bus.$off('selectItemClick', this.selectItemClick);
            Bus.$off('refreshSeqAfter', this.refreshSeqAfter);
        }
    }
</script>

<style scoped lang="less">
    .app-designer{
        position: relative;
        overflow-x: hidden;
        overflow-y: auto;
        min-width: 1100px;
        .designer-header{
            position: relative;
            z-index: 103;
            height: 68px;
            background-color: #222d32;
        }
        .designer-left{
            position: absolute;
            top: 0px;
            left: 0;
            height: 100%;
            width: 250px;
            background-color: #ecf0f5;
        }
        .mid-container{
            display: -webkit-box;
            display: -webkit-flex;
            display: -moz-box;
            display: -ms-flexbox;
            display: flex;
            margin-left: 250px;
            min-height: 927px;
            .content-area {
                flex: 1;
                -webkit-box-flex: 1;
                -moz-box-flex: 1;
                -ms-flex: 1;
            }
            .right-bank {
                width: 350px;
            }
        }

    }
    .opts-drawer-footer{
        width: 100%;
        position: absolute;
        bottom: 0;
        left: 0;
        border-top: 1px solid #e8e8e8;
        padding: 10px 16px;
        text-align: left;
        background: #fff;
    }

    @keyframes modalWrapSelfT {
        from{right: -650px;}
        to{right: 0px;}
    }
    @keyframes maskLayerT {
        from{opacity: 0;}
        to{opacity: 0.5;}
    }
    .mask-layer-t{
        height:100%;
        position:fixed;
        top :0px;
        left:0px;
        right: 0px;
        background-color: #0C1835;
        opacity:0.5;
        text-align:center;
        z-index:800;
        animation: maskLayerT 0.5s;
        animation-fill-mode:forwards;
    }
    .modal-wrap-self-t{
        height:100%;
        position:fixed;
        overflow: auto;
        top :0px;
        right: 0px;
        width: 720px;
        background-color: #fff;
        z-index:810;
        animation: modalWrapSelfT 0.5s;
        animation-fill-mode:forwards;
        .modal-content{
            position: relative;
            background-color: #fff;
            border: 0;
            border-radius: 6px;
            background-clip: padding-box;
            box-shadow: 0 4px 12px rgba(0,0,0,.15);
            box-sizing: border-box;
            -webkit-tap-highlight-color: transparent;
            height: 100%;
            .modal-close{
                z-index: 1;
                font-size: 12px;
                position: absolute;
                right: 8px;
                top: 8px;
                overflow: hidden;
                cursor: pointer;
                .ivu-icon-ios-close{
                    font-size: 31px;
                    color: #999;
                    transition: color .2s ease;
                    position: relative;
                    top: 1px;
                }
            }
            .modal-header{
                border-bottom: 1px solid #e8eaec;
                padding: 15px 16px 5px 16px;
                p{
                    display: inline-block;
                    width: 100%;
                    height: 20px;
                    line-height: 20px;
                    font-weight: 700;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
            }
            .modal-body{
                margin: 0px;
                padding: 0px 10px;
                height: calc(100% - 100px);
            }
            .modal-footer{
                border-top: 1px solid #e8eaec;
                padding: 12px 18px 12px 18px;
                text-align: center;
                bottom: 70px;
                position: absolute;
                right: 0px;
                left: 0px;
            }
        }
    }

</style>
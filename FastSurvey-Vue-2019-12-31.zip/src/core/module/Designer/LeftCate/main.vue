<template>
    <div class="left-cate">
        <div class="cate-list">
            <Tabs class="tab-switch" v-model="tabFlag" :animated="false">
                <TabPane label="题目控件" name="control">
                    <draggable tag='ul'
                               :list="basicComponents"
                               v-bind="{group:{ name:'g', pull:'clone',put:false},sort:false, ghostClass: 'ghost'}"
                               :move="allowMove"
                    >
                        <li class="cate-item" v-for="(item,index) in basicComponents" :key="index" :name="item.name">
                            <a @click="clickHandle(item)">
                                <template v-if="item.name==='SingleChoice'">
                                    <i class="radio"></i>
                                </template>
                                <template v-if="item.name==='MultiChoice'">
                                    <i class="checkbox"></i>
                                </template>
                                <template v-if="item.name==='FillBlank'">
                                    <i class="s-fill-blank"></i>
                                </template>
                                <template v-if="item.name==='MultiFillBlank'">
                                    <i class="m-fill-blank"></i>
                                </template>
                                <template v-if="item.name==='Sort'">
                                    <i class="i-sort"></i>
                                </template>
                                <template v-if="item.name==='ScoreRadio'">
                                    <i class="i-score-radio"></i>
                                </template>
                                <template v-if="item.name==='ScoreCheckbox'">
                                    <i class="i-score-check"></i>
                                </template>
                                <template v-if="item.name==='Scale'">
                                    <i class="i-scale"></i>
                                </template>
                                <template v-if="item.name==='MatrixRadio'">
                                    <i class="i-matrix-radio"></i>
                                </template>
                                <template v-if="item.name==='MatrixCheckbox'">
                                    <i class="i-matrix-check"></i>
                                </template>
                                <template v-if="item.name==='SelectQues'">
                                    <i class="i-select-ques"></i>
                                </template>
                                <template v-if="item.name==='SectionDesc'">
                                    <i class="i-section-desc"></i>
                                </template>
                                <template v-if="item.name==='Pagination'">
                                    <i class="i-page"></i>
                                </template>
                                <template v-if="item.name==='AnswerQuestion'">
                                    <i class="i-answer-ques"></i>
                                </template>
                                <template v-if="item.name==='Attachment'">
                                    <i class="i-attachment"></i>
                                </template>
                                <span>{{item.desc}}</span>
                            </a>
                        </li>
                    </draggable>
                </TabPane>
                <TabPane label="问卷大纲" name="outline">
                    <ul class="outline-content">
                        <li v-for="(item) in data.items">
                            <a class="dg-a" @click="queryPositionClick(item.opts.seq)">
                                <template v-if="item.name!=='Pagination'&&item.name!=='SectionDesc'">
                                    <span>{{item.opts.tNum}}、{{item.opts.title}}</span>
                                </template>
                            </a>
                        </li>
                    </ul>
                </TabPane>
            </Tabs>
            <!--<div class="title">题目控件</div>-->
        </div>
    </div>
</template>

<script>
    import Draggable from 'vuedraggable'
    import api from '@/api/main'

    export default {
        name: "LeftCate",
        props:['data'],
        data(){
            return{
                basicComponents:api.getBasicComponents(),
                tabFlag: 'control',
                dgSelectIndex:0
            }
        },
        mounted(){
            console.log(this.data.items)
        },
        methods:{
            queryPositionClick(seq){
                this.dgSelectIndex = seq
                Bus.$emit('queryPositionClick', seq);
            },
            clickHandle(it){
                Bus.$emit('addItemClick', it);
            },
            allowMove(){
                return true
            }
        },
        components:{
            Draggable,
        }
    }
</script>

<style lang="less">
    .left-cate{
        position: fixed;
        top: 68px;
        bottom: 0;
        left: 0;
        width: 250px;
        background-color: #fff;
        border-right: 1px solid #e0e0e0;
        .cate-list{
            padding: 5px 0px;
            width: 100%;
            height: 100%;
            position: relative;
            .title{
                font-size: 14px;
                line-height: 20px;
                margin: 20px 0px 10px 15px;
            }
            ul{
                position: relative;
                overflow: hidden;
                padding: 0px 0px 60px 10px;
                margin: 0;
            }
            .cate-item{
                position: relative;
                width: 96%;
                margin: 1%;
                line-height: 26px;
                border: 1px solid #e0e0e0;
                border-radius: 2px;
                background-color: #f4f6fc;
                cursor: move;
                transition: background ease-in-out 0.15s;
                float:left;
                text-overflow: ellipsis;
                white-space: nowrap;
                color: #333;
                font-size: 12px;
                &:hover{
                    color: #409EFF;
                    border: 1px dashed #409EFF;
                }
                &>a{
                    display: block;
                    cursor: move;
                    background: #F4F6FC;
                    border: 1px solid #F4F6FC;
                    /*text-align: center;*/
                    span{
                        display: inline-block;
                        vertical-align: middle;
                        color: #666;
                    }
                }
                .radio{
                    background: url(../../../../img/radio.png) no-repeat center;
                    width:20px;
                    height:20px;
                    background-size:cover;
                    float: left;
                    margin: 4px 5px 0px 5px;
                }
                .checkbox{
                    background: url(../../../../img/checkbox.png) no-repeat center;
                    width:20px;
                    height:20px;
                    background-size:cover;
                    float: left;
                    margin: 4px 5px 0px 5px;
                }
                .s-fill-blank{
                    background: url(../../../../img/s_fill_blank.png) no-repeat center;
                    width:20px;
                    height:20px;
                    background-size:cover;
                    float: left;
                    margin: 4px 5px 0px 5px;
                }
                .m-fill-blank{
                    background: url(../../../../img/m_fill_blank.png) no-repeat center;
                    width:20px;
                    height:20px;
                    background-size:cover;
                    float: left;
                    margin: 4px 5px 0px 5px;
                }
                .i-sort{
                    background: url(../../../../img/sort.png) no-repeat center;
                    width:20px;
                    height:20px;
                    background-size:cover;
                    float: left;
                    margin: 4px 5px 0px 5px;
                }
                .i-score-radio{
                    background: url(../../../../img/score_radio.png) no-repeat center;
                    width:20px;
                    height:20px;
                    background-size:cover;
                    float: left;
                    margin: 4px 5px 0px 5px;
                }
                .i-score-check{
                    background: url(../../../../img/score_check.png) no-repeat center;
                    width:20px;
                    height:20px;
                    background-size:cover;
                    float: left;
                    margin: 4px 5px 0px 5px;
                }
                .i-scale{
                    background: url(../../../../img/scale.png) no-repeat center;
                    width:20px;
                    height:20px;
                    background-size:cover;
                    float: left;
                    margin: 4px 5px 0px 5px;
                }
                .i-matrix-radio{
                    background: url(../../../../img/matrix_radio.png) no-repeat center;
                    width:20px;
                    height:20px;
                    background-size:cover;
                    float: left;
                    margin: 4px 5px 0px 5px;
                }
                .i-matrix-check{
                    background: url(../../../../img/matrix_check.png) no-repeat center;
                    width:20px;
                    height:20px;
                    background-size:cover;
                    float: left;
                    margin: 4px 5px 0px 5px;
                }
                .i-select-ques{
                    background: url(../../../../img/select.png) no-repeat center;
                    width:20px;
                    height:20px;
                    background-size:cover;
                    float: left;
                    margin: 4px 5px 0px 5px;
                }
                .i-section-desc{
                    background: url(../../../../img/section_desc.png) no-repeat center;
                    width:20px;
                    height:20px;
                    background-size:cover;
                    float: left;
                    margin: 4px 5px 0px 5px;
                }
                .i-page{
                    background: url(../../../../img/page.png) no-repeat center;
                    width:20px;
                    height:20px;
                    background-size:cover;
                    float: left;
                    margin: 4px 5px 0px 5px;
                }
                .i-answer-ques{
                    background: url(../../../../img/answer_ques.png) no-repeat center;
                    width:19px;
                    height:19px;
                    background-size:cover;
                    float: left;
                    margin: 5px 5px 0px 5px;
                }
                .i-attachment{
                    background: url(../../../../img/attachment.png) no-repeat center;
                    width:20px;
                    height:18px;
                    background-size:cover;
                    float: left;
                    margin: 5px 5px 0px 5px;
                }
            }
        }
    }
    // tab切换样式
    .tab-switch {
        height: 100%;
        overflow: inherit;
        .dg-a{
            display: block;
            span{
                display: inline-block;
                vertical-align: middle;
                color: #666;
            }
        }
        .active span{
            color: #409EFF;
        }
        .ivu-tabs-content {
            height: 100%;
            .ivu-tabs-tabpane {
                height: 100%;
            }
        }
        .ivu-tabs-bar {
            border-bottom: none;
        }
        .ivu-tabs-nav-scroll {
            display: -webkit-box;
            display: -webkit-flex;
            display: -moz-box;
            display: -ms-flexbox;
            display: flex;
            justify-content: center;
            //.ivu-tabs-nav {
            //    .ivu-tabs-ink-bar {
            //        display: none;
            //    }
            //    .ivu-tabs-tab {
            //
            //    }
            //}
        }
    }
    .outline-content {
        height: 100%;
        overflow: auto !important;
        li {
            padding: 5px 15px;
            &:hover {
                background: #DAE8F9;
            }
        }
    }
</style>
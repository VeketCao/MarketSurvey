<template>
    <div class="question-bank" :class="{'active-in': !showBank, 'active-out': showBank}">
        <!--<div class="out-in-mark" @click="outOrIn"><Icon type="ios-paper-outline" /><span>展开题库</span></div>-->
        <div style="font-size: 14px;padding: 10px 20px;color: #57a3f3;font-weight: bold"><span>题库</span></div>
        <div class="bank-main">
            <Collapse simple accordion>
                <Panel v-for="(item, index) in data">
                    {{item.categoryName}}
                    <p slot="content" v-if="item.questionBanks.length" v-for="itemList in item.questionBanks" :title="itemList.title" @click="clickHandle(itemList)"><span>{{itemList.title}}</span> <Icon v-if="item.categoryId===1" type="ios-close-circle" @click.stop="delBank(itemList)" /></p>
                </Panel>
                <!--<Panel name="2">-->
                    <!--人口属性-->
                    <!--<p slot="content"><span>职业</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>地域</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>国家地区</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>出生年份</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>收入</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>性别</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>学历</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>大学</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>专业</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>行业</span> <Icon type="md-information-circle" /></p>-->
                <!--</Panel>-->
                <!--<Panel name="3">-->
                    <!--用户联系方式-->
                    <!--<p slot="content"><span>手机号码</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>邮箱</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>QQ号码</span> <Icon type="md-information-circle" /></p>-->
                <!--</Panel>-->
                <!--<Panel name="4">-->
                    <!--上网行为-->
                    <!--<p slot="content"><span>电脑接入网络方式</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>电脑上网地点</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>国家地区</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>出生年份</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>收入</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>性别</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>学历</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>大学</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>专业</span> <Icon type="md-information-circle" /></p>-->
                    <!--<p slot="content"><span>行业</span> <Icon type="md-information-circle" /></p>-->
                <!--</Panel>-->
            </Collapse>
        </div>
    </div>
</template>

<script>
    import Draggable from 'vuedraggable'
    import api from '@/api/main'

    export default {
        name: "QuestionBank",
        props:['data'],
        data(){
            return{
                //value1: '1',
                showBank: false
                //basicComponents:api.getBasicComponents()
            }
        },
        mounted(){

        },
        methods:{
            clickHandle(it){
                //console.log(JSON.parse(it.content))
                //let item.desc = it.title
                Bus.$emit('addItemClick', JSON.parse(it.content));
            },
            allowMove(){
                return true
            },
            outOrIn() {
                this.showBank = !this.showBank
            },
            delBank(item) {
                console.log(item)
                this.$Modal.confirm({
                    title: '提示',
                    content: '您确认删除该题目吗？',
                    onOk: () => {
                        api.delQuestionBank({questionBankId:item.id}).then((rtn)=>{
                            console.log(rtn)
                            if(rtn.code === 0) {
                                this.$parent.getQuestionBankList()
                                this.$Message.success({ content: '删除成功', duration: 3, onClose: () => {} })
                            }
                        })
                    },
                    onCancel: () => {

                    }
                })
            }
        },
        components:{
            Draggable,
        }
    }
</script>

<style lang="less">
    .question-bank {
        position: relative;
        .out-in-mark {
            position: absolute;
            z-index: 1000;
            top: 0;
            left: -100px;
            width: 100px;
            height: 30px;
            border-radius: 30px 0 0 30px;
            line-height: 30px;
            text-align: center;
            cursor: pointer;
            background: #fff;
            .ivu-icon-ios-paper-outline {
                font-size: 14px;
            }
            span {
                padding-left: 5px;
            }
        }
        .bank-main {
            width: 100%;
            //overflow: hidden;
            //transform: translate3d(0, 0, 0);
            transition: width .5s ease;
            -moz-transition: width .5s ease; /* Firefox 4 */
            -webkit-transition: width .5s ease; /* Safari and Chrome */
            -o-transition: width .5s ease; /* Opera */
            .ivu-collapse>.ivu-collapse-item>.ivu-collapse-header>i {
                margin-right: 5px;
            }

            .ivu-collapse {
                .ivu-collapse-item {
                    font-size: 14px;
                    .ivu-collapse-content {
                        padding-top: 0;
                        padding-bottom: 0;
                        .ivu-collapse-content-box {
                            max-height: 500px;
                            overflow: auto;
                            padding-bottom: 0 !important;
                            p {
                                display: -webkit-box;
                                display: -webkit-flex;
                                display: -moz-box;
                                display: -ms-flexbox;
                                display: flex;
                                padding-left: 25px;
                                //padding-right: 56px;
                                height: 30px;
                                line-height: 30px;
                                font-size: 13px;
                                span {
                                    width: 260px;
                                    cursor: pointer;
                                    overflow: hidden;
                                    -ms-text-overflow: ellipsis;
                                    text-overflow: ellipsis;
                                    white-space: nowrap;
                                }
                                i {
                                    margin-left: 20px;
                                    line-height: 30px;
                                    font-size: 16px;
                                    color: #999;
                                }
                                i:hover {
                                    //color: #376599;
                                    color: #F95647;
                                }
                            }
                            p:hover {
                                background: #DAE8F9;
                            }
                        }
                        .ivu-collapse-content-box::-webkit-scrollbar {
                            display: none;
                        }
                    }
                }
            }
        }
    }
    .active-in {
        width: 0;
    }
    .active-out {
        width: 200px;
    }
</style>
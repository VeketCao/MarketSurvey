<template>
    <div v-if="show && data">
        <template v-if="data.name === 'SingleChoice'">
            <SingleChoiceOpt :data="data" :items="items"></SingleChoiceOpt>
        </template>
        <template v-if="data.name === 'MultiChoice'">
            <MultiChoiceOpt :data="data" :items="items"></MultiChoiceOpt>
        </template>
        <template v-if="data.name === 'FillBlank'">
            <FillBlankOpt :data="data" :items="items"></FillBlankOpt>
        </template>
        <template v-if="data.name ==='MultiFillBlank'">
            <MultiFillBlankOpt :data="data" :items="items"></MultiFillBlankOpt>
        </template>
        <template v-if="data.name ==='Sort'">
            <SortOpt :data="data" :items="items"></SortOpt>
        </template>
        <template v-if="data.name ==='ScoreRadio'">
            <ScoreRadioOpt :data="data" :items="items"></ScoreRadioOpt>
        </template>
        <template v-if="data.name ==='ScoreCheckbox'">
            <ScoreCheckboxOpt :data="data" :items="items"></ScoreCheckboxOpt>
        </template>
        <template v-if="data.name ==='Scale'">
            <ScaleOpt :data="data" :items="items"></ScaleOpt>
        </template>
        <template v-if="data.name ==='MatrixRadio'">
            <MatrixRadioOpt :data="data" :items="items"></MatrixRadioOpt>
        </template>
        <template v-if="data.name ==='MatrixCheckbox'">
            <MatrixCheckboxOpt :data="data" :items="items"></MatrixCheckboxOpt>
        </template>
        <template v-if="data.name ==='SelectQues'">
            <SelectQuesOpt :data="data" :items="items"></SelectQuesOpt>
        </template>
        <template v-if="data.name ==='SectionDesc'">
            <SectionDescOpt :data="data" :items="items"></SectionDescOpt>
        </template>
        <template v-if="data.name ==='Pagination'">
            <PaginationOpt :data="data" :items="items"></PaginationOpt>
        </template>
        <template v-if="data.name ==='AnswerQuestion'">
            <AnswerQuestionOpt :data="data" :items="items"></AnswerQuestionOpt>
        </template>
        <template v-if="data.name ==='Attachment'">
            <AttachmentOpt :data="data" :items="items"></AttachmentOpt>
        </template>
    </div>
</template>

<script>
    import SingleChoiceOpt from '../../../components/SingleChoice/SingleChoiceOpt'
    import MultiChoiceOpt from '../../../components/MultiChoice/MultiChoiceOpt'
    import FillBlankOpt from '../../../components/FillBlank/FillBlankOpt'
    import MultiFillBlankOpt from '../../../components/MultiFillBlank/MultiFillBlankOpt'
    import SortOpt from "../../../components/Sort/SortOpt";
    import ScoreRadioOpt from "../../../components/ScoreRadio/ScoreRadioOpt";
    import ScoreCheckboxOpt from "../../../components/ScoreCheckbox/ScoreCheckboxOpt";
    import ScaleOpt from "../../../components/Scale/ScaleOpt";
    import MatrixRadioOpt from "../../../components/MatrixRadio/MatrixRadioOpt";
    import MatrixCheckboxOpt from "../../../components/MatrixCheckbox/MatrixCheckboxOpt";
    import SelectQuesOpt from "../../../components/SelectQues/SelectQuesOpt";
    import SectionDescOpt from "../../../components/SectionDesc/SectionDescOpt";
    import PaginationOpt from "../../../components/Pagination/PaginationOpt";
    import AttachmentOpt from "../../../components/Attachment/AttachmentOpt";
    import AnswerQuestionOpt from "../../../components/AnswerQuestion/AnswerQuestionOpt";

    export default {
        name: 'ItemOpts',
        props:{
            show:{
                type: Boolean,
                default: true
            },
            data:{
                type: Object,
                default: null
            },
            items:{
                type: Array,
                default: []
            }
        },
        data(){
            return{

            }
        },
        components:{
            SingleChoiceOpt,
            MultiChoiceOpt,
            FillBlankOpt,
            MultiFillBlankOpt,
            SortOpt,
            ScoreRadioOpt,
            ScoreCheckboxOpt,
            ScaleOpt,
            MatrixRadioOpt,
            MatrixCheckboxOpt,
            SelectQuesOpt,
            SectionDescOpt,
            PaginationOpt,
            AnswerQuestionOpt,
            AttachmentOpt
        }
    }
</script>

<style lang="less" scoped>

</style>
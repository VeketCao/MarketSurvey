<template>
    <div id="app_container">
        <router-view></router-view>
    </div>
</template>
<script>
    export default {
        name: "App"
    }
</script>

<style scoped lang="less">
    body {
        margin: 0px;
        padding: 0px;
        font-family: Avenir,Helvetica,Arial,sans-serif;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        color: #2c3e50;
        min-width:1200px;
        height:100%;
        width: 100%;
        overflow: hidden;
    }
    #app_container {
        margin: 0px;
        padding: 0px;
        height: 100%;
        width: 100%;
    }
</style>
<template>
    <div class="matrix-radio-ay">
        <div class="title-header">
            <span class="title-sp1">第{{data.opts.tNum}}题:</span>
            <span class="title-sp2">{{data.opts.title}}</span>
            <span class="title-sp3">[{{data.desc}}]</span>
        </div>
        <div class="table-assembly ay-table">
            <Table class="table-style" border :columns="cols" :data="items">
            </Table>
        </div>
        <div class="tb-section">
            <div class="btn-bar">
                <a class="zhutu" :class="{active:tbType=='bar'}" @click="tbTypeClick('bar')">柱状图</a>
            </div>
            <div :id="'tb_bar_id_'+ data.key" class="tb_main" :class="{'tb-active':tbType=='bar'}"></div>
        </div>
    </div>
</template>

<script>
    import echarts from 'echarts/lib/echarts'
    import 'echarts/lib/chart/bar'
    import 'echarts/lib/chart/pie'
    import 'echarts/lib/component/tooltip'
    import 'echarts/lib/component/title'

    export default {
        name: "MatrixRadioAy",
        props:{
            data:{
                type: Object,
                default:null
            },
        },
        data(){
            return{
                tbType:'',
                cols:[{
                        title:'选项',
                        key:'name'
                    }
                ],
                items:[]
            }
        },
        mounted(){
            /*console.log('MatrixRadioAy',this.data)*/
            this.buildTable()
            this.buildTb()
        },
        methods:{
            buildTable(){
                this.data.opts.col.forEach((col,index)=>{
                    this.$set(this.cols,index+1,{
                        title:col.name,
                        key:col.id
                    })
                })
                this.data.opts.row.forEach((row)=>{
                    let itemRow = _.find(this.data.opts.statistics,(it)=>{
                        return it.itemRowId===row.id
                    })
                    let tp={}
                    itemRow.itemMatrixColStatisticsList.forEach((itemCol)=>{
                        tp[itemCol.id] = `${itemCol.subtotal}(${itemCol.percentage}%)`
                    })
                    this.$set(this.items,this.items.length,{
                        ...tp,
                        name:row.name
                    })
                })
            },
            tbTypeClick(type){
                this.tbType = type
            },
            buildTb(){
                let colors = ['#33a3dc','#61a0a8',  '#c4ccd3', '#546570','#d48265', '#91c7ae','#749f83',  '#ca8622', '#bda29a','#6e7074']
                let series =[]
                let source=[]
                this.data.opts.col.forEach((col,index)=>{
                    series.push({
                        type: 'bar',
                        label:{
                            normal:{
                                show:true,
                                position:'top'
                            }
                        }
                    })
                })
                this.data.opts.row.forEach((row)=>{
                    let itemRow = _.find(this.data.opts.statistics,(it)=>{
                        return it.itemRowId===row.id
                    })
                    let tp=[]
                    tp.push(row.name)
                    this.data.opts.col.forEach((col,index)=>{
                        let itemCol = _.find(itemRow.itemMatrixColStatisticsList,(itCol)=>{
                            return itCol.id === col.id
                        })
                        tp.push(itemCol.percentage)
                    })
                    source.push(tp)
                })
                echarts.init(document.getElementById('tb_bar_id_'+ this.data.key)).setOption({
                    dataset: {
                        source: source /*[
                            ['外观', 1, 2, 3,4,1],
                            ['功能', 3, 4, 5,2,1],
                        ]*/
                    },
                    xAxis:{type:'category'},
                    yAxis:{},
                    series:  series
                });
            }
        }
    }
</script>

<style lang="less" scoped>
.matrix-radio-ay{
    position: relative;
    .title-header{
        padding: 20px 30px 0px;
        .title-sp1{
            font-size: 16px;
            color: #676767;
            font-weight: bold;
            position: relative;
            margin-right: 6px;
        }
        .title-sp2{
            font-size: 15px;
            max-width: 709px;
            line-height: 24px;
        }
        .title-sp3{
            color: #999;
            margin-left: 10px;
        }
    }
    .ay-table{
        padding-left: 30px;
        width: 800px;
    }
    .tb-section{
        padding-left: 30px;
        .btn-bar{
            a{
                display: inline-block;
                min-width: 80px;
                padding: 0 6px 0 24px !important;
                height: 30px !important;
                line-height: 28px;
                background-color: #ffffff;
                border-radius: 4px;
                border: solid 1px #cccccc;
                color: #333;
                text-align: center;
            }
            a:hover{
                border: solid 1px #1ea0fa;
                color: #1ea0fa ;
            }
            .bingtu{
                BACKGROUND: url(//image.wjx.com/images/wjx/viewstat/pie-nor.png) no-repeat 5px 6px;
            }
            .zhutu{
                BACKGROUND: url(//image.wjx.com/images/wjx/viewstat/column-nor.png) no-repeat 5px 6px;
            }
            .donut{
                BACKGROUND: url(//image.wjx.com/images/wjx/viewstat/ring-nor.png) no-repeat 5px 6px;
            }
            .active{
                border: solid 1px #1ea0fa;
                color: #FFFFFF !important;
                background-color: #1ea0fa;
            }
        }
        .tb_main{
            position: relative;
            width: 800px;
            height: 300px;
            display: none;
        }
        .tb-active{
            display: block;
        }
    }
}
</style>
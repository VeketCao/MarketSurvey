<template>
    <div class="multi-fill-blank-ay">
        <div class="title-header">
            <span class="title-sp1">第{{data.opts.tNum}}题:</span>
            <span class="title-sp2">{{data.opts.title}}</span>
            <span class="title-sp3">[{{data.desc}}]</span>
        </div>
        <div class="table-assembly ay-table">
            <Table class="table-style" border :columns="cols" :data="items"></Table>
        </div>
        <Drawer title="详情"
                v-model="showDrawer"
                width="820"
                :mask-closable="true">
            <div class="table-assembly detail-table">
                <Table class="table-style" border :columns="detailCols" :data="detailItems"></Table>
                <Page :total="total" @on-change="onPageChange"  size="small"/>
            </div>
        </Drawer>
    </div>
</template>

<script>
    import api from '@/api/main'
    export default {
        name: "MultiFillBlankAy",
        props:{
            data:{
                type: Object,
                default:null
            },
            searchList:{
                type: Array,
                default:[]
            }
        },
        data(){
            return{
                itemIndex:-1,
                showDrawer:false,
                cols:[
                    {
                        title:'填空',
                        key:'name',
                    },
                    {
                        title: '详情',
                        key: 'action',
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h('Button', {
                                    props: {
                                        type: 'primary',
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '5px',
                                    },
                                    on: {
                                        click: () => {
                                            this.showDrawer = true
                                            this.itemIndex = params.row.index
                                            this.refreshDetailTable()
                                        }
                                    }
                                }, '详情'),
                            ]);
                        }
                    }
                ],
                items:[],
                pageNum:0,
                pageSize:10,
                total:0,
                detailCols:[
                    {
                        title:'序号',
                        key:'seq',
                        width:80
                    },
                    {
                        title:'提交答卷时间',
                        key:'answerTime'
                    },
                    {
                        title:'答案文本',
                        key:'result'
                    },
                    {
                        title:'来源',
                        key:'dataSource'
                    },
                    {
                        title: '操作',
                        key: 'action',
                        align: 'center',
                        width: '120px',
                        render:(h, params) => {
                            return h('div', [
                                h('a', {
                                    class: ['table-btn'],
                                    on: {
                                        click:() => {
                                            let url = `./main.html#/queryAnswer?id=${params.row.answerSurveyId}`
                                            window.open(url)
                                        }
                                    }
                                }, '查看答卷'),
                            ])
                        }
                    }
                ],
                detailItems:[]
            }
        },
        mounted() {
            console.log('MultiFillBlankAy',this.data)
            this.items = this.data.opts.list
        },
        methods:{
            getSearchParam(){
                let tp = {
                    surveyId:this.data.opts.surveyId,
                    questionId:this.data.key,
                    itemIndex:this.itemIndex,
                    pageSize: this.pageSize,
                    pageNum: this.pageNum,
                    conditions:[]
                }
                this.searchList.forEach((it)=>{
                    if(!_.isEmpty(it.titleKey)){
                        tp.conditions.push(_.omit(it,'xxList'))
                    }
                })
                return tp
            },
            refreshDetailTable(){
                if(this.itemIndex===-1) return
                api.getMultiFillBlankList(this.getSearchParam()).then((rtn)=>{
                    console.log('getMultiFillBlankList',rtn)
                    this.detailItems=rtn.data.records
                    this.detailItems.forEach((it,index)=>{
                        it.seq=index+1
                    })
                    this.total = rtn.data.total
                })
            },
            onPageChange(pageNum){
                this.pageNum = pageNum-1
                this.refreshDetailTable()
            }
        }
    }
</script>

<style lang="less" scoped>
.multi-fill-blank-ay{
    .title-header{
        padding: 20px 30px 0px;
        .title-sp1{
            font-size: 16px;
            color: #676767;
            font-weight: bold;
            position: relative;
            margin-right: 6px;
        }
        .title-sp2{
            font-size: 15px;
            max-width: 709px;
            line-height: 24px;
        }
        .title-sp3{
            color: #999;
            margin-left: 10px;
        }
    }
    .ay-table{
        padding-left: 30px;
        width: 800px;
    }
}
</style>
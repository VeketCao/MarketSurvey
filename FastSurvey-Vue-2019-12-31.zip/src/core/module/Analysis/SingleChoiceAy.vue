<template>
    <div class="single-choice-ay" v-if="data">
        <div class="title-header">
            <span class="title-sp1">第{{data.opts.tNum}}题:</span>
            <span class="title-sp2">{{data.opts.title}}</span>
            <span class="title-sp3">[{{data.desc}}]</span>
        </div>
        <div class="table-assembly ay-table">
            <Table class="table-style" border :columns="cols" :data="items">
                <template slot-scope="{row}" slot="percentage">
                    <Progress :percent="row.percentage" >
                        <span v-if="row.percentage==100">100%</span>
                    </Progress>
                </template>
            </Table>
        </div>
        <div class="tb-section">
            <div class="btn-bar">
                <a class="zhutu" :class="{active:tbType=='bar'}" @click="tbTypeClick('bar')">柱状图</a>
                <a class="bingtu" :class="{active:tbType=='pie'}"  @click="tbTypeClick('pie')">饼状图</a>
                <a class="donut" :class="{active:tbType=='radar'}"  @click="tbTypeClick('radar')">圆环图</a>
            </div>
            <div :id="'tb_bar_id_'+ data.key" class="tb_main" :class="{'tb-active':tbType=='bar'}"></div>
            <div :id="'tb_pie_id_'+ data.key" class="tb_main" :class="{'tb-active':tbType=='pie'}"></div>
            <div :id="'tb_radar_id_'+ data.key" class="tb_main" :class="{'tb-active':tbType=='radar'}"></div>
        </div>
    </div>
</template>

<script>
    import echarts from 'echarts/lib/echarts'
    import 'echarts/lib/chart/bar'
    import 'echarts/lib/chart/pie'
    import 'echarts/lib/component/tooltip'
    import 'echarts/lib/component/title'

    export default {
        name: "SingleChoiceAy",
        props:{
            data:{
                type: Object,
                default:null
            },
        },
        data(){
            return{
                tbType:'',
                cols:[{
                        title:'选项',
                        key:'name'
                    },
                    {
                        title:'小计',
                        key:'subtotal',
                        width:130
                    },
                    {
                        title:'比例',
                        slot:'percentage'
                    },
                ],
                items:[]
            }
        },
        mounted(){
            /*console.log('SingleChoiceAy',this.data)*/
            if(this.data.name=='Sort'){
                this.cols[1].title='平均综合得分'
            }
            if(this.data.name=='ScoreRadio' || this.data.name=='ScoreCheckbox' || this.data.name=='Scale'){
                this.cols.push({title:'总得分',key:'totalScore'})
            }

            this.items = this.data.opts.list
            this.buildTb()
        },
        methods:{
            tbTypeClick(type){
                this.tbType = type
                //this.buildTb(type)
            },
            buildTb(){
                let xData=[]
                let barYData=[]
                let peiData=[]
                this.data.opts.list.forEach((item) => {
                    xData.push(item.name)
                    barYData.push(item.percentage || 0)
                    peiData.push({name:item.name,value:item.percentage})
                })
                let colors = ['#33a3dc','#61a0a8',  '#c4ccd3', '#546570','#d48265', '#91c7ae','#749f83', '#bda29a','#6e7074','#33a3dc','#61a0a8',  '#c4ccd3', '#546570','#d48265', '#91c7ae','#749f83',  '#ca8622', '#bda29a','#6e7074','#ca8622']
                echarts.init(document.getElementById('tb_bar_id_'+ this.data.key)).setOption({
                    xAxis:{
                        data:xData,
                    },
                    yAxis:{
                    },
                    dataZoom: [
                        {
                            type: 'inside'
                        }
                    ],
                    series: {
                        type: 'bar',
                        label:{
                            normal:{
                                show:true,
                                position:'top'
                            }
                        },
                        data:barYData
                    }
                });
                echarts.init(document.getElementById('tb_pie_id_'+ this.data.key)).setOption({
                    series: {
                        type: 'pie',
                        data: peiData
                    }
                });
                echarts.init(document.getElementById('tb_radar_id_'+ this.data.key)).setOption({
                    series: {
                        type: 'pie',
                        radius:['35%','65%'],
                        data: peiData
                    }
                });
            }
        }

    }
</script>
<style>
    .table-assembly .table-style .ivu-progress-success .ivu-progress-bg {
        background-color: #2d8cf0;
    }
    .table-assembly .table-style .ivu-progress-success .ivu-progress-text {
        color: #2d8cf0;
    }
</style>
<style lang="less" scoped>
    .single-choice-ay{
        position: relative;
        .title-header{
            padding: 20px 30px 0px;
            .title-sp1{
                font-size: 16px;
                color: #676767;
                font-weight: bold;
                position: relative;
                margin-right: 6px;
            }
            .title-sp2{
                font-size: 15px;
                max-width: 709px;
                line-height: 24px;
            }
            .title-sp3{
                color: #999;
                margin-left: 10px;
            }
        }
        .ay-table{
            padding-left: 30px;
            width: 800px;
        }
        .tb-section{
           padding-left: 30px;
            .btn-bar{
                a{
                    display: inline-block;
                    min-width: 80px;
                    padding: 0 6px 0 24px !important;
                    height: 30px !important;
                    line-height: 28px;
                    background-color: #ffffff;
                    border-radius: 4px;
                    border: solid 1px #cccccc;
                    color: #333;
                    text-align: center;
                }
                a:hover{
                    border: solid 1px #1ea0fa;
                    color: #1ea0fa ;
                }
                .bingtu{
                    BACKGROUND: url(//image.wjx.com/images/wjx/viewstat/pie-nor.png) no-repeat 5px 6px;
                }
                .zhutu{
                    BACKGROUND: url(//image.wjx.com/images/wjx/viewstat/column-nor.png) no-repeat 5px 6px;
                }
                .donut{
                    BACKGROUND: url(//image.wjx.com/images/wjx/viewstat/ring-nor.png) no-repeat 5px 6px;
                }
                .active{
                    border: solid 1px #1ea0fa;
                    color: #FFFFFF !important;
                    background-color: #1ea0fa;
                }
            }
            .tb_main{
                position: relative;
                width: 800px;
                height: 300px;
                display: none;
            }
            .tb-active{
                display: block;
            }
        }
    }
</style>
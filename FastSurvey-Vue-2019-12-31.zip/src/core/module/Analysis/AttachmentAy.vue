<template>
    <div class="attachment-ay">
        <div class="title-header">
            <span class="title-sp1">第{{data.opts.tNum}}题:</span>
            <span class="title-sp2">{{data.opts.title}}</span>
            <span class="title-sp3">[{{data.desc}}]</span>
        </div>
        <div class="table-assembly ay-table">
            <Table class="table-style" border :columns="cols" :data="items">
                <template slot-scope="{row}" slot="attachmentId">
                    <a :href="row.attachmentUrl"><Icon type="md-attach" size="20"/><span>{{row.attachmentName}}</span></a>
                </template>
            </Table>
            <Page :total="total" @on-change="onPageChange"  size="small"/>
        </div>
    </div>
</template>

<script>
    import api from '@/api/main'
    export default {
        name: "AttachmentAy",
        props:{
            data:{
                type: Object,
                default:null
            },
            searchList:{
                type: Array,
                default:[]
            }
        },
        data(){
            return{
                total:0,
                pageNum:0,
                pageSize:10,
                cols:[{
                        title:'序号',
                        key:'seq',
                        width:80
                    },
                    {
                        title:'提交答卷时间',
                        key:'answerTime'
                    },
                    {
                        title:'查看附件',
                        slot:'attachmentId'
                    }
                ],
                items:[]
            }
        },
        mounted(){
            this.refreshTable()
        },
        methods:{
            getSearchParam(){
                let tp = {
                    surveyId:this.data.opts.surveyId,
                    questionId:this.data.key,
                    pageSize: this.pageSize,
                    pageNum: this.pageNum,
                    conditions:[]
                }
                this.searchList.forEach((it)=>{
                    if(!_.isEmpty(it.titleKey)){
                        tp.conditions.push(_.omit(it,'xxList'))
                    }
                })
                return tp
            },
            refreshTable(){
                api.getAttachmentList(this.getSearchParam()).then((rtn)=>{
                    console.log('getAttachmentList',rtn)
                    this.items=rtn.data.records
                    this.items.forEach((it,index)=>{
                        it.seq=index+1
                    })
                    this.total = rtn.data.total
                })
            },
            onPageChange(pageNum){
                this.pageNum = pageNum-1
                this.refreshTable()
            }
        }
    }
</script>

<style lang="less" scoped>
.attachment-ay{
    .title-header{
        padding: 20px 30px 0px;
        .title-sp1{
            font-size: 16px;
            color: #676767;
            font-weight: bold;
            position: relative;
            margin-right: 6px;
        }
        .title-sp2{
            font-size: 15px;
            max-width: 709px;
            line-height: 24px;
        }
        .title-sp3{
            color: #999;
            margin-left: 10px;
        }
    }
    .ay-table{
        padding-left: 30px;
        width: 800px;
    }
}
</style>
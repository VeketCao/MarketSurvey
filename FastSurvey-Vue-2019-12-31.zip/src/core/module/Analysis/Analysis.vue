<template>
    <div class="analysis" v-if="pageConfig">
        <div class="header-bar">
            <span class="header-sp">《{{pageConfig.title}}》统计分析报告</span>
        </div>
        <div class="analysis-section">
            <div class="query-section">
                <div class="q-title" @click="showQueryHandle"><Icon type="md-search" size="20"/>自定义查询</div>
                <div v-if="showQuery" class="condition-box">
                    <Row v-for="(searchItem,i) in searchList" :key="i" class="row-item">
                        <Col span="9">
                            <Select v-model="searchItem.titleKey" placeholder="请选择题目" @on-change="tChangeHandle($event,i)">
                                <Option v-for="(item,j) in itemsList" :value="item.key" :key="j">{{item.opts.tNum}}.{{item.opts.title}}</Option>
                            </Select>
                        </Col>
                        <template v-if="searchItem.titleKey!==''">
                            <Col span="9" style="margin-left:5px">
                                <template v-if="searchItem.xxList.length>0">
                                    <Select v-model="searchItem.titleValue" placeholder="请选择选项">
                                        <Option v-for="(xxItem,k) in searchItem.xxList" :value="xxItem.name" :key="k">{{xxItem.name}}</Option>
                                    </Select>
                                </template>
                                <template v-else>
                                    <div style="padding: 5px 5px;float: left">
                                        <span >包含</span>
                                    </div>
                                    <Input v-model="searchItem.titleValue" style="position: absolute;width: 232px"></Input>
                                </template>
                            </Col>
                        </template>
                        <Col span="3" style="margin-left:5px">
                            <Select v-model="searchItem.type" placeholder="逻辑" style="width: 70px">
                                <Option value="AND">且</Option>
                                <Option value="OR">或</Option>
                            </Select>
                        </Col>
                        <Col span="1" style="margin-top:5px">
                            <a @click="removeHandle(i)"><Icon type="ios-trash-outline" size="24"/></a>
                        </Col>
                    </Row>
                    <div class="add" @click="addHandle">
                        <Icon type="ios-add-circle-outline" size="18" />新增查询条件
                    </div>
                    <div style="margin-top:10px;height: 20px;margin-left: 45%">
                        <Button type="primary" @click="queryHandle" :disabled="disableBtn">查询</Button>
                    </div>
                </div>
            </div>
            <div class="ay-item" v-for="item in pageConfig.items" v-if="showItems">
                <template v-if="item.name==='Sort' ||item.name==='SelectQues' || item.name==='SingleChoice' || item.name==='MultiChoice' || item.name==='ScoreRadio' || item.name==='ScoreCheckbox' ||item.name==='Scale'">
                    <SingleChoiceAy :data="item"></SingleChoiceAy>
                </template>
                <template v-if="item.name==='MatrixRadio' || item.name==='MatrixCheckbox'">
                    <MatrixRadioAy :data="item"></MatrixRadioAy>
                </template>
                <template v-if="item.name==='FillBlank' || item.name==='AnswerQuestion'">
                    <FillBlankAy :data="item" :searchList="searchList"></FillBlankAy>
                </template>
                <template v-if="item.name==='MultiFillBlank'">
                    <MultiFillBlankAy :data="item" :searchList="searchList"></MultiFillBlankAy>
                </template>
                <template v-if="item.name==='Attachment'">
                    <AttachmentAy :data="item" :searchList="searchList"></AttachmentAy>
                </template>
            </div>
        </div>
    </div>
</template>

<script>
    import SingleChoiceAy from "./SingleChoiceAy";
    import MatrixRadioAy from "./MatrixRadioAy";
    import FillBlankAy from "./FillBlankAy";
    import MultiFillBlankAy from "./MultiFillBlankAy";
    import api from '@/api/main'
    import AttachmentAy from "./AttachmentAy";
    export default {
        name: 'Analysis',
        data(){
            return{
                pageConfig:null,
                showQuery:true,
                itemsList:[],
                searchList:[{
                    titleKey:'',
                    titleValue:'',
                    type:'AND',
                    xxList:[],
                }],
                showItems:false,
                disableBtn:false
            }
        },
        mounted() {
            this.queryStatistics()
        },
        components:{
            SingleChoiceAy,
            MatrixRadioAy,
            FillBlankAy,
            MultiFillBlankAy,
            AttachmentAy
        },
        methods:{
            queryHandle(){
                this.disableBtn = true;
                this.queryStatistics()
            },
            removeHandle(index){
                this.$nextTick(() => {
                    this.searchList.splice(index,1)
                })
            },
            addHandle(){
                if(this.searchList.length===10){
                    this.$Message.warning({ content: '最多允许10个查询条件', duration: 3 })
                    return
                }
                this.searchList.push({
                    titleKey:'',
                    titleValue:'',
                    type:'AND',
                    xxList:[],
                })
            },
            tChangeHandle(v,index){
                this.searchList[index].xxList = []
                this.itemsList.forEach((it)=>{
                    if(it.key === v){
                        if(!_.isEmpty(it.opts.list) && it.name !== 'MultiFillBlank'){
                            this.$set(this.searchList,index,{
                                ...this.searchList[index],
                                xxList:JSON.parse(JSON.stringify(it.opts.list)),
                            })
                        }
                    }
                })
            },
            showQueryHandle(){
                this.showQuery = !this.showQuery
            },
            getSearchParam(){
                let tp = {
                  surveyId:parseInt(this.$route.query.id),
                  conditions:[]
                }
                this.searchList.forEach((it)=>{
                  if(!_.isEmpty(it.titleKey)){
                      tp.conditions.push(_.omit(it,'xxList'))
                  }
                })
                return tp
            },
            queryStatistics(){
                if(this.$route.query.id){
                    this.showItems = false
                    api.queryStatistics(this.getSearchParam()).then((rtn)=>{
                        if(rtn.code===0){
                            this.pageConfig =  JSON.parse(rtn.data)
                            console.log('queryStatistics',this.pageConfig)
                            this.disableBtn = false
                            if(!_.isEmpty(this.pageConfig.items)) this.showItems = true
                            this.itemsList = _.filter(this.pageConfig.items||[],(it)=>{
                                return (it.name !=='Attachment' && it.name !=='MatrixRadio' && it.name !=='MatrixCheckbox' && it.name !=='SectionDesc' && it.name !=='Pagination' && it.name !=='Sort')
                            })
                        }else{
                            this.$Message.warning({ content: rtn.msg, duration: 3 })
                        }
                    })
                }
            }
        }
    }
</script>

<style lang="less" scoped>
.analysis{
    position: relative;
    height: 100%;
    .header-bar{
        padding: 20px 30px;
        height: 60px;
        box-sizing: border-box;
        box-shadow: 0px 3px 8px 0px rgba(224, 229, 236, 0.4);
        .header-sp{
            font-size: 16px;
        }
    }
    .analysis-section{
        position: relative;
        height: 760px;
        overflow-y: auto;
        .ay-item{
           /* float: left;
            width: 50%;*/
            min-width: 660px;;
        }
        .query-section{
            padding: 10px 30px;
            .q-title{
                cursor: pointer;
                font-size: 14px;
                font-weight: bold
            }
            .condition-box{
                margin-top: 10px;
                width: 760px;
                background-color: #f5f7fa;
                border: solid 1px #a6d7ff;
                padding: 24px 24px 22px;
                border-radius: 4px;
                position: relative;
                .row-item{
                    padding-bottom: 10px;
                }
                .add{
                    padding: 5px 280px;
                    color: #a9a8a8;
                    border: dashed 1px #d4d7d9;
                    cursor: pointer;
                }
                .add:hover{
                    color: #1ea0fa;
                    border: dashed 1px #1ea0fa;
                }
            }
        }
    }
    
}
</style>
<template>
  <div class="vote">
      功能建设中...
  </div>
</template>

<script>
   export default {
       name: "Vote",
       data() {
           return {

           }
       }
   }
</script>

<style lang="less" scoped>
   .vote{
       padding: 20px 20px;
   }
</style>

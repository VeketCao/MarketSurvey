<template>
    <div class="sort" v-if="data && (mode=='designer' || data.opts.logic.tmgl.length==0 ||toShow)">
        <div class="t-header">
            <span style="color: red" v-if="data.opts.require">*</span>
            <span>{{data.opts.tNum}}.</span>
            <span style="margin-left: 5px">{{data.opts.title || '题标题'}}</span>
            <span >【{{data.desc}}】</span>
        </div>
        <div class="t-desc" v-if="data.opts.desc">{{data.opts.desc}}</div>
        <draggable class="sort-list"
                   v-model="data.opts.list"
                   @end="refreshSeq"
                   v-bind="{group:gp, ghostClass: 'ghost'}">
            <div class="sort-cell"   v-for="(item,key) in data.opts.list" :key="key">
                <span class="seq-sp">{{item.seq}}</span><span class="name-sp">{{item.name}}</span>
            </div>
        </draggable>
        <div class="item-mask-layer" v-if="mode==='query'"></div>
    </div>
</template>

<script>
    import TmglMixin from '../Mixin/TmglMixin'
    import Draggable from 'vuedraggable'
    export default {
        name: "Sort",
        mixins:[
            TmglMixin
        ],
        props:{
            data:{
                type: Object,
                default:null
            },
            mode:{
                type:String,
                default: ''
            }
        },
        data(){
            return{
                gp: 's'+ AppUtil.getUUID()
            }
        },
        mounted(){
            if(this.data.opts.answer.length>0){
                let tpList = JSON.parse(JSON.stringify(this.data.opts.list))
                this.data.opts.list = []
                this.data.opts.answer.forEach((v,i)=>{
                    let tp = _.find(tpList,(it)=>{
                        return v===it.index
                    })
                    this.$set(this.data.opts.list,i,{
                        ...tp,
                        seq:i+1
                    })
                })
            }
        },
        components:{
            Draggable
        },
        methods:{
            refreshSeq(){
                this.data.opts.answer=[]
                this.data.opts.list.forEach((it,i) => {
                    it.seq = i+1
                    this.data.opts.answer.push(it.index)
                })
            }
        }
    }
</script>

<style scoped lang="less">

    /*pc*/
    @media screen and (min-width :768px){
        .sort{
            position: relative;
            width: 100%;
            min-height: 120px;
            padding: 20px 100px;
            .t-header{
                font-size: 15px;
                color: #444444;
                font-weight: bold;
            }
            .t-desc{
                padding:3px 0px 0px 22px;
                color: #666666;
                line-height: 18px;
                font-size: 13px;
                clear: both;
                word-break: break-all;
            }
            .sort-list{
                margin: 15px 0px 0px 15px;
                width: 400px;
                border-radius: 4px;
                border: 1px solid #dcdee2;
                .sort-cell{
                    padding: 10px 15px;
                    border: 1px solid #dcdee2;
                    min-height: 30px;
                    overflow: hidden;
                    cursor: move;
                    .seq-sp{
                        padding: 2px 7px;
                        border: 1px solid #409eff;
                        border-radius: 50%;
                        background-color: #409eff;
                        font-size: 13px;
                        color: #444444;
                        font-weight: bold;
                    }
                    .name-sp{
                        padding: 0px 0px 0px 10px;
                    }
                }
                .ghost{
                    list-style: none;
                    font-size: 0;
                    display: block;
                    position: relative;
                    border: 1px solid #409eff;
                    width: 100%;
                }
            }
        }
    }

    /*手机*/
    @media screen and (max-width :768px){
        .sort{
            position: relative;
            width: 100%;
            padding: 10px 0;
            .t-header{
                font-size: 14px;
                color: #444444;
            }
            .t-desc{
                padding:0px 0px 0px 22px;
                color: #666666;
                line-height: 25px;
                font-size: 12px;
                clear: both;
                word-break: break-all;
            }
            .sort-list{
                margin: 15px 0px 0px 15px;
                width: calc(100% - 50px);
                border-radius: 4px;
                border: 1px solid #dcdee2;
                .sort-cell{
                    padding: 10px 15px;
                    border: 1px solid #dcdee2;
                    min-height: 30px;
                    cursor: move;
                    .seq-sp{
                        padding: 2px 7px;
                        border: 1px solid #409eff;
                        border-radius: 50%;
                        background-color: #409eff;
                        font-size: 13px;
                        color: #444444;
                        font-weight: bold;
                    }
                    .name-sp{
                        padding: 0px 0px 0px 10px;
                    }
                }
                .ghost{
                    list-style: none;
                    font-size: 0;
                    display: block;
                    position: relative;
                    border: 1px solid #409eff;
                    width: 100%;
                }
            }
        }
    }
</style>
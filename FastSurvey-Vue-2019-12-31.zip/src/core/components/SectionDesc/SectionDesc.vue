<template>
    <div class="section-desc" v-if="data && (mode=='designer' || data.opts.logic.tmgl.length==0 ||toShow)">
        <span class="desc-sp">{{data.opts.desc}}</span>
    </div>
</template>

<script>
    import TmglMixin from '../Mixin/TmglMixin'
    export default {
        name: "SectionDesc",
        mixins:[
            TmglMixin
        ],
        props:{
            data:{
                type: Object,
                default:null
            },
            mode:{
                type:String,
                default: ''
            }
        },
    }
</script>

<style lang="less" scoped>

    /*pc*/
    @media screen and (min-width :768px){
        .section-desc{
            position: relative;
            width: 100%;
            min-height: 80px;
            padding: 10px 100px;
            .desc-sp{
                font-size: 14px;
                word-break:break-all
            }
        }
    }

    /*手机*/
    @media screen and (max-width :768px){
        .section-desc{
            position: relative;
            width: 100%;
            padding: 10px 0;
            .desc-sp{
                font-size: 14px;
                word-break:break-all
            }
        }
    }
</style>
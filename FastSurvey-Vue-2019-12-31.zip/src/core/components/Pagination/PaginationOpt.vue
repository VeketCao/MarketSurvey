<template>
    <div class="pg-opt">
        <Row type="flex" class="item-row">
            <Col span="4" style="margin: 0px 0px 0px 20px">类型：</Col>
            <Col span="14"><span>{{data.desc}}</span></Col>
        </Row>
    </div>
</template>

<script>
    export default {
        name: "PaginationOpt",
        props:{
            data:{
                type: Object,
                default:null
            },
            items:{
                type: Array,
                default: []
            }
        },
    }
</script>

<style lang="less" scoped>
    .pg-opt{
        width: 100%;
        height: 100%;
        .item-row{
            margin: 15px 0px 0px 0px;
        }
    }
</style>
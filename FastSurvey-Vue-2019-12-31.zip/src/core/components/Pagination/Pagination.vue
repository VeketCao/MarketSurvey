<template>
    <div class="pg" v-if="data && (mode=='designer' || data.opts.logic.tmgl.length==0 ||toShow)">
        <div class="bt-container">
            <Button style="margin-top: 20px" @click="pageHandle">下一页</Button>
        </div>
    </div>
</template>

<script>
    import TmglMixin from '../Mixin/TmglMixin'
    export default {
        name: "Pagination",
        mixins:[
            TmglMixin
        ],
        props:{
            data:{
                type: Object,
                default:null
            },
            mode:{
                type:String,
                default: ''
            }
        },
        methods:{
            pageHandle(){
                Bus.$emit('PaginationEvent',{pageNum:this.data.opts.pageNum})
            }
        }
    }
</script>

<style lang="less" scoped>
    .pg{
        position: relative;
        width: 100%;
        min-height: 80px;
        .bt-container{
            position: absolute;
            left: 45%;
            /*width: 100%;*/
        }
    }
</style>
<template>
    <div class="attachment" v-if="data && (mode=='designer' || data.opts.logic.tmgl.length==0 ||toShow)">
        <div class="t-header">
            <span style="color: red" v-if="data.opts.require">*</span>
            <span>{{data.opts.tNum}}.</span>
            <span style="margin-left: 5px">{{data.opts.title || '题标题'}}</span>
            <span >【{{data.desc}}】</span>
        </div>
        <div class="t-desc" v-if="data.opts.desc">{{data.opts.desc}}</div>
        <div class="t-upload" v-if="mode!=='query'">
            <Upload
                    multiple
                    type="drag"
                    :ref="data.key"
                    :max-size="10240"
                    :on-success="handleSuccess"
                    :on-exceeded-size="handleMaxSize"
                    :format="['jpg','jpeg','png','git']"
                    :on-format-error="handleFormatError"
                    :on-remove="removeHandle"
                    :before-upload="handleBeforeUpload"
                    :action="actionUrl">
                <div style="padding: 10px 0">
                    <Icon type="ios-cloud-upload" size="52" style="color: #3399ff"></Icon>
                    <p>点击添加文件或将文件拖至此处(文件大小限制10M)</p>
                </div>
            </Upload>
        </div>
        <div class="error-tip" v-if="data.isAnswer&&data.errorFlag">{{data.errorMsg || '请上传文件'}}</div>
        <div v-if="mode==='query' && data.opts.answer" style="margin:20px 10px;min-height: 30px">
            <div v-for="(it,i) in data.opts.answer" :key="i" style="margin: 5px 0px;">
                <a :href="it.attachmentUrl" target="_blank" style="float: left;margin: 0px 10px">
                    <img :src="it.thumbnailUrl" style="width: 80px;height: 80px;border-radius: 4px"/>
                </a>
            </div>
        </div>
        <Modal v-model="showImgModal" class-name="vertical-center-modal" width="620px" :footer-hide="true">
            <template v-if="showImgModal">
                <img :src="showUrl" style="width: 600px;height: 600px;padding: 15px 12px 5px 0px">
            </template>
        </Modal>
    </div>
</template>

<script>
    import TmglMixin from '../Mixin/TmglMixin'
    export default {
        name: "Attachment",
        mixins:[
            TmglMixin
        ],
        props:{
            data:{
                type: Object,
                default:null
            },
            mode:{
                type:String,
                default: ''
            }
        },
        data(){
          return{
              showImgModal:false,
              showUrl:'',
              actionUrl:`${window.location.origin}/v1/attachment/upload`
          }
        },
        watch: {
            'data.opts.answer' (val) {
                if(val&&val.length) {
                    this.$set(this.data, 'errorFlag', false)
                    this.$set(this.data, 'errorMsg', '')
                } else {
                    if(this.data.opts.require) {
                        this.$set(this.data, 'errorFlag', true)
                        this.$set(this.data, 'errorMsg', '')
                    }
                }
            }
        },
        mounted(){
        },
        methods:{
            attachmentClick(it){
                console.log('attachmentClick',it)
                if(it.attachmentFileExt ==='.jpg' || it.attachmentFileExt ==='.png' || it.attachmentFileExt ==='.git' || it.attachmentFileExt ==='.jpeg'){
                    this.showImgModal = true;
                    this.showUrl = it.attachmentUrl
                }else{
                    let eleLink = document.createElement('a');
                    eleLink.download = '附件';
                    eleLink.style.display = 'none';
                    eleLink.href = it.attachmentUrl;
                    document.body.appendChild(eleLink);
                    eleLink.click();
                    document.body.removeChild(eleLink);
                }
            },
            handleFormatError (file) {
                this.$Notice.warning({
                    title: '上传图片格式错误',
                    desc: '文件：' + file.name + ' 格式错误, 清上传 jpg、png、jpeg、git.'
                });
            },
            handleBeforeUpload(file){
                const check =  this.$refs[this.data.key].fileList.length < this.data.opts.maxNum
                if (!check) {
                    this.$Message.warning({ content: `最多只能上传${this.data.opts.maxNum}张图片。`, duration: 5 })
                }
                return check
            },
            removeHandle(file, fileList){
                this.data.opts.answer = []
                fileList.forEach((it)=>{
                    this.data.opts.answer.push(it.response.data)
                })
            },
            handleSuccess(res, file){
                console.log('handleSuccess',res)
                if(res.code===0){
                    this.data.opts.answer.push(res.data)
                }else{
                    this.$Message.warning({ content: res.msg, duration: 3 })
                }

            },
            handleMaxSize (file) {
                this.$Message.warning({ content: '上传文件超过10M限制', duration: 3 })
            },
        }
    }
</script>

<style lang="less" scoped>
    /*pc*/
    @media screen and (min-width :768px){
        .attachment{
            position: relative;
            width: 100%;
            min-height: 120px;
            padding: 30px 100px;
            .t-header{
                font-size: 15px;
                color: #444444;
                font-weight: bold;
            }
            .t-desc{
                padding:0px 0px 0px 22px;
                color: #666666;
                line-height: 18px;
                font-size: 13px;
                clear: both;
                word-break: break-all;
            }
            .t-upload{
                margin: 15px 21px 0px 21px;

            }
            .error-tip {
                margin: 0 0 0 21px;
                padding: 5px;
                color: red;
                border-radius: 4px;
                background: #ffe5e0;
            }
        }
    }

    /*手机*/
    @media screen and (max-width :768px){
        .attachment{
            position: relative;
            width: 100%;
            padding: 10px 0;
            .t-header{
                font-size: 14px;
                color: #444444;
            }
            .t-desc{
                padding:0px 0px 0px 22px;
                color: #666666;
                line-height: 25px;
                font-size: 12px;
                clear: both;
                word-break: break-all;
            }
            .t-upload{
                margin: 0 0px 0px 21px;
            }
            .error-tip {
                margin: 0 0 0 21px;
                padding: 5px;
                color: red;
                border-radius: 4px;
                background: #ffe5e0;
            }
        }
    }

</style>
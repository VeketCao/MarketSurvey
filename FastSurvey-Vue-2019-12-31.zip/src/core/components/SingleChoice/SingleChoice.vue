<template>
    <div class="single-choice" v-if="data && (mode=='designer' || data.opts.logic.tmgl.length==0 ||toShow)">
         <div class="t-header">
             <span style="color: red" v-if="data.opts.require">*</span>
             <span>{{data.opts.tNum}}.</span>
             <span style="margin-left: 5px">{{data.opts.title || '题标题'}}</span>
             <span >【{{data.desc}}】</span>
         </div>
         <div class="t-desc" v-if="data.opts.desc">{{data.opts.desc}}</div>
         <div class="t-list">
             <RadioGroup v-model="data.opts.answer" :vertical="data.opts.vertical" @on-change="changeHandle">
                 <Radio v-for="(item,index) in data.opts.list" :label="item.index" :key="index" style="height: 40px">
                     <span>{{item.name}}</span><input v-if="item.isRemark" v-model="item.remark" class="i-remark" />
                     <span style="color: red" v-if="item.isRemark && item.require">*</span>
                     <div v-if="item.desc" class="s-desc" :class="{descwz:data.opts.vertical}">{{item.desc}}</div>
                 </Radio>
             </RadioGroup>
         </div>
        <div class="item-mask-layer" v-if="mode==='query'"></div>
        <div class="error-tip" v-if="data.isAnswer&&data.errorFlag">{{data.errorMsg || '请选择选项'}}</div>
    </div>
</template>

<script>
    import TmglMixin from '../Mixin/TmglMixin'
    export default {
        name: "SingleChoice",
        mixins:[
            TmglMixin
        ],
        props:{
            data:{
                type: Object,
                default:null
            },
            mode:{
                type:String,
                default: ''
            }
        },
        watch: {
            'data.opts.answer' (val) {
                if(val) {
                    this.$set(this.data, 'errorFlag', false)
                    this.$set(this.data, 'errorMsg', '')
                }
            }
        },
        methods:{
            changeHandle(it){
                Bus.$emit('tmglEvent',{key:this.data.key,v:this.data.opts.answer})
            }
        }
    }
</script>

<style scoped lang="less">

    /*pc*/
    @media screen and (min-width :768px){
        .single-choice{
            position: relative;
            width: 100%;
            min-height: 120px;
            padding: 25px 100px;
            .t-header{
                font-size: 15px;
                color: #444444;
                font-weight: bold;
            }
            .t-desc{
                padding:3px 0px 0px 22px;
                color: #666666;
                line-height: 18px;
                font-size: 13px;
                clear: both;
                word-break: break-all;
            }
            .t-list{
                padding: 15px 0px 0px 19px;
                .i-remark{
                    border: solid 1px transparent;
                    border-bottom: solid 1px #cdcdcd;
                    background-color: white;
                    height: 20px;
                }
                .s-desc{
                    color: #999999;
                    font-size: 8px;
                    margin: 2px 0px 0px 20px;
                }
                .descwz{
                    margin: -8px 0px 0px 20px!important;
                }
            }
            .error-tip {
                margin: 0 0 0 21px;
                padding: 5px;
                color: red;
                border-radius: 4px;
                background: #ffe5e0;
            }
        }
    }

    /*手机*/
    @media screen and (max-width :768px){
        .single-choice{
            position: relative;
            width: 100%;
            padding: 10px 0;
            .t-header{
                font-size: 14px;
                color: #444444;
            }
            .t-desc{
                padding:3px 0px 0px 22px;
                color: #666666;
                line-height: 25px;
                font-size: 12px;
                clear: both;
                word-break: break-all;
            }
            .t-list{
                padding: 15px 0px 0px 19px;
                .i-remark{
                    border: solid 1px transparent;
                    border-bottom: solid 1px #cdcdcd;
                    background-color: white;
                    height: 20px;
                }
                .s-desc{
                    color: #999999;
                    font-size: 8px;
                    margin: 2px 0px 0px 20px;
                }
                .descwz{
                    margin: -8px 0px 0px 20px!important;
                }
            }
            .error-tip {
                margin: 0 0 0 21px;
                padding: 5px;
                color: red;
                border-radius: 4px;
                background: #ffe5e0;
            }
        }
    }
</style>
import SingleChoice from './SingleChoice/SingleChoice'
import MultiChoice from './MultiChoice/MultiChoice'
import FillBlank from './FillBlank/FillBlank'
import MultiFillBlank from "./MultiFillBlank/MultiFillBlank";
import Sort from "./Sort/Sort";
import ScoreRadio from "./ScoreRadio/ScoreRadio";
import ScoreCheckbox from "./ScoreCheckbox/ScoreCheckbox";
import Scale from "./Scale/Scale";
import MatrixRadio from "./MatrixRadio/MatrixRadio";
import MatrixCheckbox from "./MatrixCheckbox/MatrixCheckbox";
import SelectQues from "./SelectQues/SelectQues";
import SectionDesc from "./SectionDesc/SectionDesc";
import Pagination from "./Pagination/Pagination";
import AnswerQuestion from "./AnswerQuestion/AnswerQuestion";
import Attachment from "./Attachment/Attachment";

Vue.component('SingleChoice',SingleChoice);
Vue.component('MultiChoice',MultiChoice);
Vue.component('FillBlank',FillBlank);
Vue.component('MultiFillBlank',MultiFillBlank);
Vue.component('Sort',Sort);
Vue.component('ScoreRadio',ScoreRadio);
Vue.component('ScoreCheckbox',ScoreCheckbox);
Vue.component('Scale',Scale);
Vue.component('MatrixRadio',MatrixRadio);
Vue.component('MatrixCheckbox',MatrixCheckbox);
Vue.component('SelectQues',SelectQues);
Vue.component('SectionDesc',SectionDesc);
Vue.component('Pagination',Pagination);
Vue.component('AnswerQuestion',AnswerQuestion);
Vue.component('Attachment',Attachment);
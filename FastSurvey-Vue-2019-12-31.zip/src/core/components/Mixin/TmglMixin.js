export default {
    data(){
        return{
            toShow:false
        }
    },
    mounted() {
        if(this.data && this.data.opts.logic.tmgl.length>0){
            Bus.$on('tmglEvent',this.toShowHandle)
        }
    },
    methods:{
        toShowHandle(p){
            if(p.key == this.data.opts.logic.tmgl[0].gltmKey){
                if(_.isArray(p.v)){
                    if(_.intersection(this.data.opts.logic.tmgl[0].glxxIndex,p.v).length>0){
                        this.toShow = true
                    }else{
                        this.toShow = false
                    }
                }else{
                    if(this.data.opts.logic.tmgl[0].glxxIndex.indexOf(p.v)!=-1){
                        this.toShow = true
                    }else{
                        this.toShow = false
                    }
                }
            }
        }
    },
    beforeDestroy() {
        if(this.data && this.data.opts.logic.tmgl.length>0){
            Bus.$off('tmglEvent',this.toShowHandle)
        }
    }
}
export default {
    data(){
        return{
            showLogicSet:true,
            xtList:[],
            tmTemp:{logicKey:AppUtil.getUUID(),gltmKey:'',glxxIndex:[]},
            t1:50,
            t2:200
        }
    },
    mounted(){
        this.topicSet()
        this.t1change(this.data.opts.title)
    },
    methods:{
        t1change(name){
            this.t1 = 50-name.length
        },
        t2change(name){
            this.t2 = 200-name.length
        },
        topicSet(){
            if(this.items.length == 1 || this.data.opts.tNum==1){
                this.showLogicSet = false
                return
            }
            let tempList = _.filter(this.items,(it)=>{
                return (it.opts.tNum < this.data.opts.tNum) && (it.name==='SingleChoice' || it.name==='MultiChoice' || it.name==='ScoreRadio' || it.name==='ScoreCheckbox')
            })

            this.xtList = JSON.parse(JSON.stringify(tempList))

            if(this.xtList.length == 0){
                this.showLogicSet = false
                return
            }
            this.xtList.forEach((item)=>{
                item.opts.list.forEach((it)=>{
                    it.isgl = false
                })
            })
            if(this.data.opts.logic.tmgl.length>0){
                this.tmTemp= JSON.parse(JSON.stringify(this.data.opts.logic.tmgl[0]))
            }else{
                this.tmTemp= {logicKey:AppUtil.getUUID(),gltmKey:'',glxxIndex:[]}
            }
            if(this.tmTemp.glxxIndex.length>0){
                this.tmTemp.glxxIndex.forEach((glIndex)=>{
                    this.xtList.forEach((item)=>{
                        item.opts.list.forEach((it)=>{
                            if(glIndex == it.index) it.isgl = true
                        })
                    })
                })
            }
            this.showLogicModal = true
        },
        topicSetOkHandle(){
            if(this.tmTemp.gltmKey){
                this.data.opts.logic.tmgl = []
                this.tmTemp.glxxIndex=[]
                this.xtList.forEach((it)=>{
                    if(it.key == this.tmTemp.gltmKey){
                        it.opts.list.forEach((xxItem)=>{
                            if(xxItem.isgl){
                                this.tmTemp.glxxIndex.push(xxItem.index)
                            }
                        })
                    }
                })
                if(this.tmTemp.glxxIndex.length>0){
                    this.data.opts.logic.tmgl.push(JSON.parse(JSON.stringify(this.tmTemp)) )
                }else{
                    this.data.opts.logic.tmgl=[]
                }
            }
            this.showLogicModal = false
        }
    }
}
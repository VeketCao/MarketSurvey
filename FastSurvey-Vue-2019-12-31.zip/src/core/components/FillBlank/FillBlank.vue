<template>
    <div class="fill-blank" v-if="data && (mode=='designer' || data.opts.logic.tmgl.length==0 ||toShow)">
        <div class="t-header">
            <span style="color: red" v-if="data.opts.require">*</span>
            <span>{{data.opts.tNum}}.</span>
            <span style="margin-left: 5px">{{data.opts.title || '题标题'}}</span>
            <span >【{{data.desc}}】</span>
        </div>
        <div class="t-desc" v-if="data.opts.desc">{{data.opts.desc}}</div>
        <div class="t-input" :class="{'ipt-underline':data.opts.underline}">
            <Input :style="'width:'+ data.opts.width +'px;'" :type="data.opts.type" v-model="data.opts.answer" :rows="parseInt(data.opts.rows)"></Input>
        </div>
        <div class="item-mask-layer" v-if="mode==='query'"></div>
        <div class="error-tip" v-if="data.isAnswer&&data.errorFlag">{{data.errorMsg || '请输入内容'}}</div>
    </div>
</template>

<script>
    import TmglMixin from '../Mixin/TmglMixin'
    export default {
        name: 'FillBlank',
        mixins:[
            TmglMixin
        ],
        props:{
            data:{
                type: Object,
                default:null
            },
            mode:{
                type:String,
                default: ''
            }
        },
        watch: {
            'data.opts.answer' (val) {
                if(val) {
                    this.$set(this.data, 'errorFlag', false)
                    this.$set(this.data, 'errorMsg', '')
                    if(this.data.opts.type === 'tel') {
                        if(!this.isPoneAvailable(this.data.opts.tNum, this.data.opts.answer)) {
                            this.$set(this.data, 'errorFlag', true)
                            this.$set(this.data, 'errorMsg', '手机号码格式不对')
                        }
                    }
                    if(this.data.opts.type === 'email') {
                        if(!this.isEmailAvailable(this.data.opts.tNum, this.data.opts.answer)) {
                            this.$set(this.data, 'errorFlag', true)
                            this.$set(this.data, 'errorMsg', '邮箱格式不对')
                        }
                    }
                } else {
                    if(this.data.opts.require) {
                        this.$set(this.data, 'errorFlag', true)
                        this.$set(this.data, 'errorMsg', '')
                    }
                }
            }
        },
        methods:{
            isPoneAvailable(tNum, tel) {
                var myreg = /^[1][3,4,5,6,7,8,9][0-9]{9}$/;
                if (!myreg.test(tel)) {
                    //this.$Message.warning({ content: `第${tNum}题，手机号码格式不对`, duration: 3 })
                    return false;
                } else {
                    return true;
                }
            },
            isEmailAvailable(tNum, email) {
                var myreg = /^[A-Za-z0-9]+([_\.][A-Za-z0-9]+)*@([A-Za-z0-9\-]+\.)+[A-Za-z]{2,6}$/;
                if (!myreg.test(email)) {
                    //this.$Message.warning({ content: `第${tNum}题，邮箱格式不对`, duration: 3 })
                    return false;
                } else {
                    return true;
                }
            },
        }
    }
</script>
<style lang="less">
    .ipt-underline{
        .ivu-input{
            border-top: unset;
            border-left: unset;
            border-right: unset;
            border-bottom: 1px solid #dcdee2!important;
        }
    }
</style>

<style scoped lang="less">
    /*pc*/
    @media screen and (min-width :768px){
        .fill-blank{
            position: relative;
            width: 100%;
            min-height: 120px;
            padding: 30px 100px;
            .t-header{
                font-size: 15px;
                color: #444444;
                font-weight: bold;
            }
            .t-desc{
                padding:0px 0px 0px 22px;
                color: #666666;
                line-height: 18px;
                font-size: 13px;
                clear: both;
                word-break: break-all;
            }
            .t-input{
                margin: 15px 0px 0px 21px;
            }
            .error-tip {
                margin: 10px 0 0 21px;
                padding: 5px;
                color: red;
                border-radius: 4px;
                background: #ffe5e0;
            }
        }
    }

    /*手机*/
    @media screen and (max-width :768px){
        .fill-blank{
            position: relative;
            width: 100%;
            padding: 10px 0;
            .t-header{
                font-size: 14px;
                color: #444444;
            }
            .t-desc{
                padding:0px 0px 0px 22px;
                color: #666666;
                line-height: 25px;
                font-size: 12px;
                clear: both;
                word-break: break-all;
            }
            .t-input{
                margin: 0 0px 0px 21px;
                .ivu-input-wrapper {
                    width: 100% !important;
                }
            }
            .error-tip {
                margin: 10px 0 0 21px;
                padding: 5px;
                color: red;
                border-radius: 4px;
                background: #ffe5e0;
            }
        }
    }
</style>
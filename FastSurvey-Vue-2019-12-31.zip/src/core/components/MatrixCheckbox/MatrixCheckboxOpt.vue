<template>
    <div class="matrix-checkbox-opt">
        <Row type="flex" class="item-row">
            <Col span="4" style="margin: 0px 0px 0px 20px">类型：</Col>
            <Col span="14"><span>{{data.desc}}</span></Col>
        </Row>
        <Row type="flex" class="item-row">
            <Col span="4" style="margin: 8px 0px 0px 20px">标题：</Col>
            <Col span="14"><Input v-model="data.opts.title" :maxlength="50" @on-change="t1change(data.opts.title)"></Input></Col>
            <Col span="2" style="margin-top:10px"><span>({{t1}}字)</span></Col>
        </Row>
        <Row type="flex" class="item-row">
            <Col span="4" style="margin: 8px 0px 0px 20px">题说明：</Col>
            <Col span="14">
                <Input v-model="data.opts.desc" :maxlength="200" type="textarea" :autosize="{minRows: 2,maxRows: 5}" @on-change="t2change(data.opts.desc)"></Input>
            </Col>
            <Col span="2" style="margin-top:30px"><span>({{t2}}字)</span></Col>
        </Row>
        <Row type="flex" class="item-row">
            <Col span="8" style="margin-left: 21px;"><Checkbox v-model="data.opts.require">必答</Checkbox></Col>
        </Row>
        <div class="row-list-set">
            <Row type="flex" class="item-row list-set-header">
                <Col span="8" style="margin-left: 25px;">行标题</Col>
            </Row>
            <Row type="flex" class="cell" v-for="(it,index) in data.opts.row" :key="index">
                <Col span="9" style="margin-left: 15px"><Input :maxlength="30" size="small" v-model="it.name"></Input></Col>
                <Col span="1" style="margin-left: 15px">
                    <Icon type="ios-arrow-round-down" size="18"  @click="moveRowHandle(index)" style="cursor: pointer"/>
                </Col>
                <Col span="1">
                    <Icon type="ios-remove-circle-outline" size="18"  @click="removeRowHandle(index)" style="cursor: pointer;margin-left: 12px"/>
                </Col>
            </Row>
            <Row type="flex" class="add">
                <Col span="6" style="margin: 5px 0px 5px 15px;"><a @click="addRowHandle"><Icon type="ios-add-circle-outline" size="18" />新增行</a></Col>
            </Row>
        </div>
        <div class="col-list-set">
            <Row type="flex" class="item-row list-set-header">
                <Col span="8" style="margin-left: 25px;">列选项文字</Col>
            </Row>
            <Row type="flex" class="cell" v-for="(it,index) in data.opts.col" :key="index">
                <Col span="9" style="margin-left: 15px"><Input size="small" v-model="it.name" @on-blur='changeHandle(index)'></Input></Col>
                <Col span="1" style="margin-left: 15px">
                    <Icon type="ios-arrow-round-down" size="18"  @click="moveColHandle(index)" style="cursor: pointer"/>
                </Col>
                <Col span="1">
                    <Icon type="ios-remove-circle-outline" size="18"  @click="removeColHandle(index)" style="cursor: pointer;margin-left: 12px"/>
                </Col>
            </Row>
            <Row type="flex" class="add">
                <Col span="6" style="margin: 5px 0px 5px 15px;"><a @click="addColHandle"><Icon type="ios-add-circle-outline" size="18" />新增列选项</a></Col>
            </Row>
        </div>
        <div class="logic-set" v-if="showLogicSet">
            <Row type="flex" class="logic-row">
                <Col span="6">逻辑设置：</Col>
                <!--<Col span="8" v-if="data.opts.logic.tmgl.length==0"><a @click="topicSet">题目关联</a></Col>
                <Col span="8" v-if="data.opts.logic.tmgl.length>0"><a @click="topicSet">编辑题目关联</a></Col>-->
            </Row>
        </div>
        <div class="gl-set" v-if="showLogicSet">
            <Row type="flex" style="margin: 0px 0px 10px 10px">
                <Col span="4" class="gl-title">当前题目：</Col>
                <Col span="16" style="margin-top: 2px"><span>{{data.opts.tNum +'.'+ data.opts.title}}</span></Col>
            </Row>
            <Row type="flex" style="margin: 0px 0px 10px 10px">
                <Col span="4" class="gl-title">关联题目：</Col>
                <Col span="18">
                    <Select placeholder="请选择关联的题目"  not-found-text="无数据" size="small" v-model="tmTemp.gltmKey">
                        <Option v-for="item in xtList" :value="item.key">{{item.opts.tNum}}.{{item.opts.title}}</Option>
                    </Select>
                </Col>
                <Row v-if="tmTemp.gltmKey" class="tmts">
                    <Col class="tm-title">选择下面的选项中的任意一个时，“当前题目”才出现</Col>
                    <template v-for="(xtItem,j) in xtList">
                        <Row v-if="xtItem.key==tmTemp.gltmKey" v-for="it in xtItem.opts.list" style="margin: 10px 0px">
                            <Checkbox v-model="it.isgl" @on-change="topicSetOkHandle">{{it.name}}</Checkbox>
                        </Row>
                    </template>
                </Row>
            </Row>
        </div>
    </div>
</template>

<script>
    import logicSetOptMixin from '../Mixin/logicSetOptMixin'
    export default {
        name: "MatrixCheckboxOpt",
        mixins:[
            logicSetOptMixin
        ],
        props:{
            data:{
                type: Object,
                default:null
            },
            items:{
                type: Array,
                default: []
            }
        },
        methods:{
            changeHandle(index){ 
                if(this.data.opts.list[index].name==='其它'){
                    this.data.opts.list[index].isRemark = true
                }
            },
            moveColHandle(index){
                if(this.data.opts.col.length==1) return;
                let temp = JSON.parse(JSON.stringify(this.data.opts.col[index]))
                if(this.data.opts.col.length-1===index){//最后一项跟第一项交换
                    this.$set(this.data.opts.col,index,{
                        ...JSON.parse(JSON.stringify(this.data.opts.col[0]))
                    })
                    this.$set(this.data.opts.col,0,{
                        ...temp
                    })
                }else{
                    this.$set(this.data.opts.col,index,{
                        ...JSON.parse(JSON.stringify(this.data.opts.col[index+1]))
                    })
                    this.$set(this.data.opts.col,index+1,{
                        ...temp
                    })
                }
            },
            removeColHandle(index){//删除选项
                if(this.data.opts.col.length===1){
                    this.$Message.warning({ content: '选项至少要保留一项', duration: 3 })
                    return
                }
                this.$nextTick(() => {
                    this.data.opts.col.splice(index,1)
                })
            },
            addColHandle(){//新增选项
                if(this.data.opts.col.length>=8){
                    this.$Message.warning({ content: '列选项不能超过8个', duration: 3 })
                    return
                }
                let tp = {index:AppUtil.getUUID(),name:`列选项${this.data.opts.col.length+1}`}
                this.data.opts.col.push(tp)
            },
            moveRowHandle(index){
                if(this.data.opts.row.length==1) return;
                let temp = JSON.parse(JSON.stringify(this.data.opts.row[index]))
                if(this.data.opts.row.length-1==index){//最后一项跟第一项交换
                    this.$set(this.data.opts.row,index,{
                        ...JSON.parse(JSON.stringify(this.data.opts.row[0]))
                    })
                    this.$set(this.data.opts.row,0,{
                        ...temp
                    })
                }else{
                    this.$set(this.data.opts.row,index,{
                        ...JSON.parse(JSON.stringify(this.data.opts.row[index+1]))
                    })
                    this.$set(this.data.opts.row,index+1,{
                        ...temp
                    })
                }
            },
            removeRowHandle(index){
                if(this.data.opts.row.length==1){
                    this.$Message.warning({ content: '选项至少要保留一项', duration: 3 })
                    return
                }
                this.$nextTick(() => {
                    this.data.opts.row.splice(index, 1)
                })
            },
            addRowHandle(){
                if(this.data.opts.row.length>=5){
                    this.$Message.warning({ content: '行标题不能超过5个', duration: 3 })
                    return
                }
                this.data.opts.row.push({index:AppUtil.getUUID(),name:`行标题${this.data.opts.row.length+1}`})
            }
        }
    }
</script>

<style lang="less" scoped>
    .matrix-checkbox-opt{
        width: 100%;
        height: 100%;
        .item-row{
            margin: 15px 0px 0px 0px;
        }
        .col-list-set{
            width: 100%;
            margin-top: 10px;
            .list-set-header{
                background: #FAFAFA;
                padding: 5px 0px;
            }
            .cell{
                margin-top: 5px;
                .cell-rq{
                    position: absolute;
                    left: 23px;
                    top: 0px;
                }
            }
            .add{
            }
        }
        .row-list-set{
            width: 100%;
            margin-top: 30px;
            .list-set-header{
                background: #FAFAFA;
                padding: 5px 0px;
            }
            .cell{
                margin-top: 5px;
                .cell-rq{
                    position: absolute;
                    left: 23px;
                    top: 0px;
                }
            }
            .add{
            }
        }
        .logic-set{
            width: 100%;
            margin-top: 30px;
            .logic-row{
                background-color: #F4F4F4;
                margin: 5px 5px;
                padding: 5px 5px;
            }
        }
    }
    .gl-set{
        .gl-title{
            color: #333;
            font-size: 14px;
        }
        .tmts{
            margin:15px 0px 10px 115px;
            .tm-title{
                color: #333;
                font-size: 14px;
            }
        }
    }
</style>
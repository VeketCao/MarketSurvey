<template>
    <div class="matrix-checkbox" v-if="data && (mode=='designer' || data.opts.logic.tmgl.length==0 ||toShow)">
        <div class="t-header">
            <span style="color: red" v-if="data.opts.require">*</span>
            <span>{{data.opts.tNum}}.</span>
            <span style="margin-left: 5px">{{data.opts.title || '题标题'}}</span>
            <span >【{{data.desc}}】</span>
        </div>
        <div class="t-desc" v-if="data.opts.desc">{{data.opts.desc}}</div>
        <div class="mr-grid">
            <div class="rows-left">
                <div v-for="(rowIt,key) in data.opts.row" :key="key" class="row-title" :title="rowIt.name">{{rowIt.name}}</div>
            </div>
            <div class="cols-right">
                <div v-for="(rowItem,index) in data.opts.row" :key="index" class="col-row">
                    <CheckboxGroup v-model="data.opts.answer[index]">
                        <Checkbox v-for="(cell,j) in data.opts.col"  :label="cell.id"  :key="j" style="width: 60px">
                            <span class="title-header" :title="cell.name">{{index==0?cell.name:''}}</span>
                        </Checkbox>
                    </CheckboxGroup>
                </div>
            </div>
        </div>
        <div class="item-mask-layer" v-if="mode==='query'"></div>
        <div class="error-tip" v-if="data.isAnswer&&data.errorFlag">{{data.errorMsg || '请选择选项'}}</div>
    </div>
</template>

<script>
    import TmglMixin from '../Mixin/TmglMixin'
    export default {
        name: "MatrixCheckbox",
        mixins:[
            TmglMixin
        ],
        props:{
            data:{
                type: Object,
                default:null
            },
            mode:{
                type:String,
                default: ''
            }
        },
        watch: {
            'data.opts.answer' (val) {
                if(val&&val.length === this.data.opts.row.length) {
                    this.$set(this.data, 'errorFlag', false)
                    this.$set(this.data, 'errorMsg', '')
                    val.forEach((item, index)=>{
                        if(item.length === 0 && this.data.opts.require) {
                            this.$set(this.data, 'errorFlag', true)
                            this.$set(this.data, 'errorMsg', '')
                        }
                    })
                }
            }
        },
        created() {
//            if(_.isEmpty(this.data.opts.answer)) this.data.opts.answer=[[],[]] todo 先注释，影响校验逻辑
        }
    }
</script>
<style lang="less">
    .col-row .ivu-checkbox-wrapper{
        text-align: center!important;
    }
</style>
<style lang="less" scoped>
    /*pc*/
    @media screen and (min-width :768px){
        .matrix-checkbox{
            position: relative;
            width: 100%;
            min-height: 120px;
            padding: 30px 100px;
            overflow: hidden;
            .t-header{
                font-size: 15px;
                color: #444444;
                font-weight: bold;
            }
            .t-desc{
                padding:3px 0px 0px 22px;
                color: #666666;
                line-height: 18px;
                font-size: 13px;
                clear: both;
                word-break: break-all;
            }
            .mr-grid{
                position: relative;
                margin: 10px 17px;
                width: 100%;
                min-height: 80px;
                min-width: 1100px;
                .rows-left{
                    padding-top: 28px;
                    float: left;
                    min-width: 80px;
                    max-width: 150px;
                    min-height: 80px;
                    .row-title{
                        padding: 4px 5px;
                        font-size: 15px;
                        color: #333333;
                        font-weight: bold;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                    }
                }
                .cols-right{
                    padding-top: 25px;
                    /*float: left;*/
                    min-height: 100px;
                    .col-row{
                        padding: 5px 0px;
                        .title-header{
                            position: absolute;
                            top: -30px;
                            left: -6px;
                            font-size: 15px;
                            color: #333333;
                            width: 75px;
                            overflow: hidden;
                            text-overflow: ellipsis;
                            white-space: nowrap;
                        }
                    }
                }
            }
            .mr-table{
                position: relative;
                margin: 10px 20px;
                width: calc(100% - 100px);
                min-height: 100px;
            }
            .error-tip {
                margin: 0 0 0 21px;
                padding: 5px;
                color: red;
                border-radius: 4px;
                background: #ffe5e0;
            }
        }
    }

    /*手机*/
    @media screen and (max-width :768px){
        .matrix-checkbox{
            position: relative;
            width: 100%;
            overflow: hidden;
            padding: 10px 0;
            .t-header{
                font-size: 14px;
                color: #444444;
            }
            .t-desc{
                padding:0px 0px 0px 22px;
                color: #666666;
                line-height: 25px;
                font-size: 12px;
                clear: both;
                word-break: break-all;
            }
            .mr-grid{
                position: relative;
                margin: 10px 17px;
                width: 100%;
                min-height: 80px;
                display: -webkit-box;
                display: -webkit-flex;
                display: -moz-box;
                display: -ms-flexbox;
                display: flex;
                .rows-left{
                    padding-top: 28px;
                    .row-title{
                        padding: 4px 5px;
                        font-size: 12px;
                        color: #333333;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                    }
                }
                .cols-right{
                    padding-top: 25px;
                    min-height: 100px;
                    .col-row{
                        padding: 5px 0px;
                        .title-header{
                            position: absolute;
                            top: -30px;
                            left: -6px;
                            font-size: 12px;
                            color: #333333;
                            width: 75px;
                            overflow: hidden;
                            text-overflow: ellipsis;
                            white-space: nowrap;
                        }
                    }
                }
            }
            .mr-table{
                position: relative;
                margin: 10px 20px;
                width: calc(100% - 100px);
                min-height: 100px;
            }
            .error-tip {
                margin: 0 0 0 21px;
                padding: 5px;
                color: red;
                border-radius: 4px;
                background: #ffe5e0;
            }
        }
    }
</style>
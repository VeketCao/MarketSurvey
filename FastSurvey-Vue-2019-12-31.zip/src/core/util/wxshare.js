import wx from 'weixin-js-sdk'

export function wxChatShare(p) {

    wx.config({
        debug: false,
        appId: p.appId,
        timestamp: p.timestamp, // 必填，生成签名的时间戳
        nonceStr: p.noncestr, // 必填，生成签名的随机串
        signature: p.signature, // 必填，签名
        jsApiList: [ // 用的方法都要加进来
            'onMenuShareTimeline', // 分享到朋友圈接口
            'onMenuShareAppMessage', //  分享到朋友接口
            'onMenuShareQQ', // 分享到QQ接口
            'onMenuShareWeibo' // 分享到微博接口
        ]
    })

    wx.ready(function () {
        var shareData = {
            "imgUrl": 'https://www.fastwj.net/static/images/logo_v3.png', // 分享显示的缩略图地址
            "link": 'https://www.fastwj.net/tf.html#/dj?id='+p.id, // 分享地址
            "desc": p.desc || '大家一起来参与吧', // 分享描述
            "title": p.title || '标题', // 分享标题
            success: function () {
            }
        };
        wx.onMenuShareTimeline(shareData);
        wx.onMenuShareAppMessage(shareData);
        wx.onMenuShareQQ(shareData);
        wx.onMenuShareWeibo(shareData);
    });

    wx.error(function (res) {
        console.log("好像出错了！！");
    });

}
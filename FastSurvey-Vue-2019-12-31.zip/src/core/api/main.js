/**接口**/

import axios from 'axios';

axios.defaults.validateStatus=(status)=>{
    if(status === 401) {
        if(__DEV__){
            window.location.href = './main.html#/login'
        }
        if(__PROD__){
            window.location.href = './#/login'
        }
        return false;
    }else return true;
}

let baseURl = `https://www.fastwj.net/fastSurvey/`
if(window.location.host.indexOf('localhost')!=-1){
    baseURl = 'http://192.168.0.37/fastSurvey/'
}
const _http =  axios.create({
    baseURL:baseURl,
    withCredentials: true,
    timeout: 50000,
    headers: { 'content-type': 'application/json' }
});


/**定义接口**/
export default {
    getBaseURl(){
        return baseURl
    },
    wxLogin(){
        return axios.get(`http://www.fastwj.net/fastSurvey/third/login/wechat`).then(res => res.data)
    },
    validResetInfo(p){
        return axios.get(`${baseURl}/message/checkMsgCode?requestId=${p.requestId}&phone=${p.phone}&msgCode=${p.code}`).then(res => res.data)
    },
    getPhoneCode(p){
        return axios.get(`${baseURl}/message/sendSms?phone=86${p.phoneNum}&imageRequestId=${p.imgRequestId}&code=${p.imgCode}`).then(res => res.data)
    },
    getCaptcha(){
        return axios.get(`${window.location.origin}/v1/captcha/getCaptcha`).then(res => res.data)
    },
    checkCaptcha(p){
        return axios.get(`${window.location.origin}/v1/captcha/checkCaptcha?imageRequestId=${p.imgRequestId}&code=${p.imgCode}`).then(res => res.data)
    },
    slink(p){
        return axios.post(`https://www.fastwj.net/v1/chain/save`,p).then(res => res.data)
    },
    getBasicComponents(){

        return [
            {
                name:'SingleChoice',
                desc:'单选题',
                opts:{
                    seq:0,
                    tNum:0,
                    title:'题标题',
                    desc:'',
                    require:true,
                    isDirty:false,
                    list:[
                        {index:AppUtil.getUUID(),name:'选项1',desc:'',isRemark:false,remark:'',require:false,isDefault:false,isgl:false},
                        {index:AppUtil.getUUID(),name:'选项2',desc:'',isRemark:false,remark:'',require:false,isDefault:false,isgl:false}
                    ],
                    vertical:true,
                    answer:'',
                    logic:{
                        tmgl:[]
                    }
                }
            },
            {
                name:'MultiChoice',
                desc:'多选题',
                opts:{
                    seq:0,
                    tNum:0,
                    title:'题标题',
                    desc:'',
                    require:true,
                    isDirty:false,
                    list:[
                        {index:AppUtil.getUUID(),name:'选项1',desc:'',isRemark:false,remark:'',require:false,isDefault:false,isgl:false},
                        {index:AppUtil.getUUID(),name:'选项2',desc:'',isRemark:false,remark:'',require:false,isDefault:false,isgl:false}
                    ],
                    vertical:true,
                    answer:[],
                    logic:{
                        tmgl:[]
                    }
                }
            },
            {
                name:'AnswerQuestion',
                desc:'问答题',
                opts:{
                    seq:0,
                    tNum:0,
                    title:'题标题',
                    desc:'',
                    type:'textarea',
                    require:true,
                    isDirty:false,
                    underline:false,
                    answer:'',
                    width:400,
                    rows:5,
                    logic:{
                        tmgl:[]
                    }
                }
            },
            {
                name:'SelectQues',
                desc:'下拉题',
                opts:{
                    seq:0,
                    tNum:0,
                    title:'题标题',
                    desc:'',
                    require:true,
                    isDirty:false,
                    answer:'',
                    list:[
                        {index:AppUtil.getUUID(),name:'选项1',isDefault:false},
                        {index:AppUtil.getUUID(),name:'选项2',isDefault:false}
                    ],
                    logic:{
                        tmgl:[]
                    }
                }
            },
            {
                name:'FillBlank',
                desc:'单项填空题',
                opts:{
                    seq:0,
                    tNum:0,
                    title:'题标题',
                    desc:'',
                    type:'text',
                    require:true,
                    isDirty:false,
                    underline:false,
                    answer:'',
                    width:400,
                    rows:5,
                    logic:{
                        tmgl:[]
                    }
                }
            },
            {
                name:'MultiFillBlank',
                desc:'多项填空题',
                opts:{
                    seq:0,
                    tNum:0,
                    title:'题标题',
                    vertical:true,
                    isDirty:false,
                    answer:[],
                    list:[
                        {index:AppUtil.getUUID(),name:'标题1',value:'',desc:'',width: 150},
                        {index:AppUtil.getUUID(),name:'标题2',value:'',desc:'',width: 150},
                        {index:AppUtil.getUUID(),name:'标题3',value:'',desc:'',width: 150}
                    ],
                    logic:{
                        tmgl:[]
                    }
                }
            },
            {
                name:'Sort',
                desc:'排序题',
                opts:{
                    seq:0,
                    tNum:0,
                    title:'题标题',
                    desc:'',
                    require:true,
                    isDirty:false,
                    answer:[],
                    list:[
                        {index:AppUtil.getUUID(),seq:1,name:'选项1'},
                        {index:AppUtil.getUUID(),seq:2,name:'选项2'},
                        {index:AppUtil.getUUID(),seq:3,name:'选项3'},
                    ],
                    logic:{
                        tmgl:[]
                    }
                }
            },
            {
                name:'ScoreRadio',
                desc:'评分单选题',
                opts:{
                    seq:0,
                    tNum:0,
                    title:'题标题',
                    desc:'',
                    require:true,
                    isDirty:false,
                    list:[
                        {index:AppUtil.getUUID(),name:'选项1',desc:'',isRemark:false,remark:'',require:false,score:1,isgl:false},
                        {index:AppUtil.getUUID(),name:'选项2',desc:'',isRemark:false,remark:'',require:false,score:2,isgl:false}
                    ],
                    vertical:true,
                    answer:'',
                    logic:{
                        tmgl:[]
                    }
                }
            },
            {
                name:'ScoreCheckbox',
                desc:'评分多选题',
                opts:{
                    seq:0,
                    tNum:0,
                    title:'题标题',
                    desc:'',
                    require:true,
                    isDirty:false,
                    list:[
                        {index:AppUtil.getUUID(),name:'选项1',desc:'',isRemark:false,remark:'',require:false,score:1,isgl:false},
                        {index:AppUtil.getUUID(),name:'选项2',desc:'',isRemark:false,remark:'',require:false,score:2,isgl:false}
                    ],
                    vertical:true,
                    answer:[],
                    logic:{
                        tmgl:[]
                    }
                }
            },
            {
                name:'Scale',
                desc:'量表题',
                opts:{
                    seq:0,
                    tNum:0,
                    title:'题标题',
                    desc:'',
                    require:true,
                    isDirty:false,
                    style:1,
                    list:[
                        {index:AppUtil.getUUID(),name:'很不满意',score:1},
                        {index:AppUtil.getUUID(),name:'不满意',score:2},
                        {index:AppUtil.getUUID(),name:'一般',score:3},
                        {index:AppUtil.getUUID(),name:'满意',score:4},
                        {index:AppUtil.getUUID(),name:'很满意',score:5}
                    ],
                    answer:'',
                    logic:{
                        tmgl:[]
                    }
                }
            },
            {
                name:'MatrixRadio',
                desc:'矩阵单选题',
                opts:{
                    seq:0,
                    tNum:0,
                    title:'题标题',
                    desc:'',
                    require:true,
                    isDirty:false,
                    row:[
                        {index:AppUtil.getUUID(),name:'外观'},
                        {index:AppUtil.getUUID(),name:'功能'}
                        ],
                    col:[
                        {index:AppUtil.getUUID(),name:'很不满意'},
                        {index:AppUtil.getUUID(),name:'不满意'},
                        {index:AppUtil.getUUID(),name:'一般'},
                        {index:AppUtil.getUUID(),name:'满意'},
                        {index:AppUtil.getUUID(),name:'很满意'}
                        ],
                    answer:['',''],
                    logic:{
                        tmgl:[]
                    }
                }
            },
            {
                name:'MatrixCheckbox',
                desc:'矩阵多选题',
                opts:{
                    seq:0,
                    tNum:0,
                    title:'请评议下面的搜索引擎',
                    desc:'',
                    require:true,
                    isDirty:false,
                    row:[
                        {index:AppUtil.getUUID(),name:'百度'},
                        {index:AppUtil.getUUID(),name:'Google'}
                    ],
                    col:[
                        {index:AppUtil.getUUID(),name:'速度快'},
                        {index:AppUtil.getUUID(),name:'准确率高'},
                        {index:AppUtil.getUUID(),name:'信息量多'},
                        {index:AppUtil.getUUID(),name:'界面更美观'}
                    ],
                    answer:[[],[]],
                    logic:{
                        tmgl:[]
                    }
                }
            },
            {
                name:'Attachment',
                desc:'附件题',
                opts:{
                    seq:0,
                    tNum:0,
                    title:'题标题',
                    desc:'',
                    maxNum:2,
                    answer:[],
                    isDirty:false,
                    require:true,
                    logic:{
                        tmgl:[]
                    }
                }
            },
            {
                name:'SectionDesc',
                desc:'段落说明',
                opts:{
                    seq:0,
                    tNum:0,
                    title:'',
                    isDirty:false,
                    require:false,
                    desc:'段落说明文字',
                    answer:'',
                    logic:{
                        tmgl:[]
                    }
                }
            },
            {
                name:'Pagination',
                desc:'分页',
                opts:{
                    seq:0,
                    tNum:0,
                    pageNum:1,
                    title:'',
                    desc:'',
                    answer:'',
                    isDirty:false,
                    require:false,
                    logic:{
                        tmgl:[]
                    }
                }
            },
        ]
    },
    saveSurvey(p){
        return _http.post('surveyMain/save',p).then(res => res.data)
    },
    publish(p){
        return _http.post('surveyMain/publish',p).then(res => res.data)
    },
    stopPublish(p){
        return _http.post('surveyMain/stopPublish',p).then(res => res.data)
    },
    login(p){
        return _http.post('login',p).then(res => res.data)
    },
    loginByPhoneCode(p){
        return _http.post('loginByPhoneCode',p).then(res => res.data)
    },
    logout(p){
        return _http.get('logout',p).then(res => res.data)
    },
    register(p){
        return _http.post('register',p).then(res => res.data)
    },
    sortSurvey(p){
        return _http.post('surveyMain/sort',p).then(res => res.data)
    },
    deleteSurvey(p){
        return _http.post('surveyMain/delete',p).then(res => res.data)
    },
    deleteQuestion(p){
        return _http.post('surveyMain/question/delete',p).then(res => res.data)
    },
    querySurvey(p){
        return _http.get('surveyMain/getSurveyById',{ params: p }).then(res => res.data)
    },
    queryAnswerSurvey(p){
        return _http.get('surveyAnswer/getSurveyById',{ params: p }).then(res => res.data)
    },
    querySurveyList(p){
        return _http.post('surveyMain/list',p).then(res => res.data)
    },
    saveSurveyAnswer(p){
        return _http.post('surveyAnswer/save',p).then(res => res.data)
    },
    querySurveyAnswer(p){
        return _http.get('surveyAnswer/getSurveyAnswerById',{ params: p }).then(res => res.data)
    },
    queryQuestionBank(p){
        return _http.get('questionBank/list',{ params: p }).then(res => res.data)
    },
    saveQuestionBank(p){
        return _http.post('questionBank/addBank',p).then(res => res.data)
    },
    delQuestionBank(p){
        return _http.post('questionBank/delete',p).then(res => res.data)
    },
    modifyPassword(p){
        return _http.post('modifyPassword',p).then(res => res.data)
    },
    queryStatistics(p){
        return _http.post('statistics/getSurveyById',p).then(res => res.data)
    },
    getFillBlankList(p){
        return _http.post('statistics/getFillBlankList',p).then(res => res.data)
    },
    getMultiFillBlankList(p){
        return _http.post('statistics/getMultiFillBlankList',p).then(res => res.data)
    },
    getImportExport(p){
        return _http.get('surveyMain/getImportExport',{ params: p }).then(res => res.data)
    },
    getAnswerRecordList(p){
        return _http.post('statistics/getAnswerRecordList',p).then(res => res.data)
    },
    getAttachmentList(p){
        return _http.post('statistics/getAttachmentList',p).then(res => res.data)
    },
    getAnswerList(p){
        return _http.post('statistics/getAnswerList',p).then(res => res.data)
    },
    setSetting(p){
        return _http.post('surveyMain/setSetting',p).then(res => res.data)
    },
    getSettingBySurveyId(p){
        return _http.get('surveyMain/getSettingBySurveyId',{ params: p }).then(res => res.data)
    },
    getUserInfo(p){
        return _http.get('getUserInfo',{ params: p }).then(res => res.data)
    },
    bindPhone(p){
        return _http.post('sys/user/bindPhone',p).then(res => res.data)
    },
    
}
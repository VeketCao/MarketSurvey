
/**定义接口**/
export default {
    getAllUsers(){
        return [
            {
              "phone": "No.2038",
              "name": "星野冥一"
            },
            {
              "phone": "No.0282",
              "name": "Mr.Q"
            },
            {
              "phone": "No.3392",
              "name": "一般人类"
            },
            {
              "phone": "No.8080",
              "name": "萝莉捕捉者"
            },
            {
              "phone": "No.3855",
              "name": "四代猫愿"
            },
            {
              "phone": "No.6389",
              "name": "人形大魔王"
            },
            {
              "phone": "No.4440",
              "name": "痴言心醉"
            },
            {
              "phone": "No.3170",
              "name": "渣瓜一隻"
            },
            {
              "phone": "No.1688",
              "name": "住之江圭太"
            },
            {
              "phone": "No.0018",
              "name": "九条鱼卡"
            },
            {
              "phone": "No.0318",
              "name": "nightor"
            },
            {
              "phone": "No.7712",
              "name": "井下落石"
            },
            {
              "phone": "No.6561",
              "name": "埃尔o妮娅"
            },
            {
              "phone": "No.1260",
              "name": "Sapha"
            },
            {
              "phone": "No.6280",
              "name": "西行寺蓝蓝路"
            },
            {
              "phone": "No.8517",
              "name": "堀江由衣"
            },
            {
              "phone": "No.2335",
              "name": "十万巫女"
            },
            {
              "phone": "No.2681",
              "name": "Halu"
            },
            {
              "phone": "No.4024",
              "name": "lupin"
            },
            {
              "phone": "No.0463",
              "name": "太阳主宰"
            },
            {
              "phone": "No.2423",
              "name": "alkd"
            },
            {
              "phone": "No.5357",
              "name": "Allenz"
            },
            {
              "phone": "No.8751",
              "name": "达也的背影"
            },
            {
              "phone": "No.0737",
              "name": "神隐少女"
            },
            {
              "phone": "No.5959",
              "name": "尐疯寳児不尐了"
            },
            {
              "phone": "No.8909",
              "name": "⌒袶醽之子↓"
            },
            {
              "phone": "No.8441",
              "name": "我家的二喵"
            },
            {
              "phone": "No.1746",
              "name": "维他酱酱"
            },
            {
              "phone": "No.2856",
              "name": "dodo"
            },
            {
              "phone": "No.6703",
              "name": "米哟哟的咧"
            },
            {
              "phone": "No.9092",
              "name": "一根呆毛"
            },
            {
              "phone": "No.3539",
              "name": "Nadia"
            },
            {
              "phone": "No.7180",
              "name": "hunter"
            },
            {
              "phone": "No.3679",
              "name": "名将FG"
            },
            {
              "phone": "No.5131",
              "name": "线性近似"
            },
            {
              "phone": "No.4146",
              "name": "LOCKOFF"
            },
            {
              "phone": "No.2812",
              "name": "jessie"
            },
            {
              "phone": "No.6918",
              "name": "unoo"
            },
            {
              "phone": "No.3776",
              "name": "上升气流君"
            },
            {
              "phone": "No.9873",
              "name": "匿名希望"
            },
            {
              "phone": "No.1240",
              "name": "下载好慢"
            },
            {
              "phone": "No.4839",
              "name": "敢来一炮么"
            },
            {
              "phone": "No.0832",
              "name": "高町奈叶"
            },
            {
              "phone": "No.5205",
              "name": "我来打酱油"
            },
            {
              "phone": "No.4787",
              "name": "JackDee"
            },
            {
              "phone": "No.2957",
              "name": "加藤雪冬"
            },
            {
              "phone": "No.1294",
              "name": "轻抿一口菊花茶"
            },
            {
              "phone": "No.2104",
              "name": "捕猎Xloli"
            },
            {
              "phone": "No.3113",
              "name": "南山有瓜"
            },
            {
              "phone": "No.6784",
              "name": "白龙跃居紫玉星"
            },
            {
              "phone": "No.5513",
              "name": "达玛婆婆"
            },
            {
              "phone": "No.7891",
              "name": "我可不敢和你争"
            },
            {
              "phone": "No.7607",
              "name": "伊吹风子"
            },
            {
              "phone": "No.9754",
              "name": "亲爱的翠翠"
            },
            {
              "phone": "No.0933",
              "name": "クオリア"
            },
            {
              "phone": "No.1989",
              "name": "深水阳菜"
            },
            {
              "phone": "No.3730",
              "name": "骑车的牛"
            },
            {
              "phone": "No.7281",
              "name": "karma"
            },
            {
              "phone": "No.2933",
              "name": "元首的笔"
            },
            {
              "phone": "No.7132",
              "name": "瞌睡の默默"
            },
            {
              "phone": "No.3869",
              "name": "灰过灰过"
            },
            {
              "phone": "No.6211",
              "name": "水无灯里"
            },
            {
              "phone": "No.2067",
              "name": "川添珠姬"
            },
            {
              "phone": "No.7349",
              "name": "水桥帕露西"
            },
            {
              "phone": "No.0828",
              "name": "Loki"
            },
            {
              "phone": "No.3081",
              "name": "不识院苍月"
            },
            {
              "phone": "No.6784",
              "name": "空闲蝙蝠"
            },
            {
              "phone": "No.6257",
              "name": "愉悦的小蛇君"
            },
            {
              "phone": "No.4402",
              "name": "月光下的追忆"
            },
          ]
    }

}